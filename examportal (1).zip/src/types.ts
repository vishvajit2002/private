export interface Question {
  id: string | number;
  text: string;
  options: string[];
  correct: number;
  marks: number;
}

export interface ExamData {
  id: string; // unique ID for the test (e.g., 'test_1')
  title: string;
  duration: number; // in minutes
  questions: Question[];
}

export interface Candidate {
  id: string; // composite e.g., testId + "_" + rollNumber or rollNumber
  testId: string; // maps to ExamData's id
  name: string;
  rollNumber: string;
  accessCode: string; // unique access ID
  registeredAt: string;
  
  // Dynamic Exam State
  status: 'idle' | 'precheck' | 'testing' | 'submitted' | 'terminated';
  score: number;
  violations: number;
  progress: number; // number of answered questions
  answers: Record<string | number, number>; // questionId -> optionIndex
  submitTime: string | null;
  startedAt: string | null;
  liveFeed?: string;
}

export interface ViolationLog {
  id: string;
  testId: string; // maps to ExamData's id
  candidateId: string;
  candidateName: string;
  rollNumber: string;
  timestamp: string;
  message: string;
  type: 'tab_switch' | 'force_terminated' | 'precheck_pass';
}
