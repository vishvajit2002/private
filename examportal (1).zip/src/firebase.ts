import { initializeApp, getApp, getApps } from 'firebase/app';
import { getFirestore, doc, getDocFromServer, Firestore } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';

let db: Firestore | null = null;
let isFirebaseReady = false;

if (firebaseConfig && firebaseConfig.apiKey) {
  try {
    const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
    db = getFirestore(app, firebaseConfig.firestoreDatabaseId || '(default)');
    isFirebaseReady = true;

    // Validate connection on boot as mandated by guidelines
    const testConnection = async () => {
      if (!db) return;
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if (error instanceof Error && error.message.includes('the client is offline')) {
          console.warn("Firebase client appears to be offline. Verify credentials or model connection.");
        }
      }
    };
    testConnection();
  } catch (err) {
    console.error("Error initializing Firebase App:", err);
  }
} else {
  console.log("Firebase config not found or unconfigured. App running in offline local persistence mode.");
}

export { db, isFirebaseReady };
export default firebaseConfig;
