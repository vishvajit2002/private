export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export let lastFirestoreError: FirestoreErrorInfo | null = null;
let firestoreErrorListeners: ((err: FirestoreErrorInfo) => void)[] = [];

export function subscribeFirestoreErrors(listener: (err: FirestoreErrorInfo) => void) {
  firestoreErrorListeners.push(listener);
  if (lastFirestoreError) {
    listener(lastFirestoreError);
  }
  return () => {
    firestoreErrorListeners = firestoreErrorListeners.filter(l => l !== listener);
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errorMessage = error instanceof Error ? error.message : String(error);
  const errInfo: FirestoreErrorInfo = {
    error: errorMessage,
    authInfo: {
      userId: null,
      email: null,
      emailVerified: null,
      isAnonymous: null,
      tenantId: null,
      providerInfo: []
    },
    operationType,
    path
  };
  
  console.error('Firestore Error Dynamic Catch: ', JSON.stringify(errInfo));
  lastFirestoreError = errInfo;
  firestoreErrorListeners.forEach(listener => {
    try {
      listener(errInfo);
    } catch (e) {
      console.error('Error in firestore listener callback:', e);
    }
  });
}

