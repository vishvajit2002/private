import { ExamData, Candidate, ViolationLog } from './types';

export const ADMIN_CREDENTIALS = {
  username: 'admin@school.com',
  password: 'admin', // standard Aristo admin default
};

export const DEFAULT_EXAMS: ExamData[] = [
  {
    id: 'test_1',
    title: 'Science & Environment Olympiad - Term 1',
    duration: 10, // 10 minutes
    questions: [
      {
        id: 'sc-1',
        text: 'Which pigment gives plants their green coloration and assists in photosynthesis?',
        options: ['Carotenoid', 'Chlorophyll', 'Anthocyanin', 'Hemoglobin'],
        correct: 1,
        marks: 2,
      },
      {
        id: 'sc-2',
        text: 'What gas is primarily consumed by plants during respiration in the absence of light?',
        options: ['Carbon Dioxide', 'Nitrogen', 'Oxygen', 'Argon'],
        correct: 2,
        marks: 2,
      },
      {
        id: 'sc-3',
        text: 'Which planet is known as the Red Planet?',
        options: ['Venus', 'Mars', 'Jupiter', 'Saturn'],
        correct: 1,
        marks: 2,
      },
    ],
  },
  {
    id: 'test_2',
    title: 'Advanced Computer Programming Concepts - Quiz 2',
    duration: 15, // 15 minutes
    questions: [
      {
        id: 'py-1',
        text: 'Which data structure utilizes LIFO (Last In, First Out) ordering?',
        options: ['Queue', 'Stack', 'Array List', 'Linked List'],
        correct: 1,
        marks: 2,
      },
      {
        id: 'py-2',
        text: 'What is the time complexity of a standard binary search algorithm on a sorted array?',
        options: ['O(n)', 'O(n²)', 'O(log n)', 'O(1)'],
        correct: 2,
        marks: 3,
      },
      {
        id: 'py-3',
        text: 'Which of the following is NOT a reserved keyword in Python?',
        options: ['pass', 'yield', 'eval', 'assert'],
        correct: 2,
        marks: 2,
      },
    ],
  },
  {
    id: 'test_3',
    title: 'Aristo Junior Mathematics Challenge',
    duration: 8, // 8 minutes
    questions: [
      {
        id: 'ma-1',
        text: 'Solve for x: 3x - 7 = 14',
        options: ['x = 5', 'x = 6', 'x = 7', 'x = 8'],
        correct: 2,
        marks: 2,
      },
      {
        id: 'ma-2',
        text: 'What is the value of 2 to the power of 8?',
        options: ['128', '256', '512', '1024'],
        correct: 1,
        marks: 2,
      },
    ],
  },
];

export const DEFAULT_CANDIDATES: Candidate[] = [
  // Test 1 Candidates
  {
    id: 'test_1_APS001',
    testId: 'test_1',
    name: 'Aravind Swamy',
    rollNumber: 'APS001',
    accessCode: 'APS101',
    registeredAt: '2026-06-07T12:00:00Z',
    status: 'idle',
    score: 0,
    violations: 0,
    progress: 0,
    answers: {},
    submitTime: null,
    startedAt: null,
  },
  {
    id: 'test_1_APS002',
    testId: 'test_1',
    name: 'Diya Nair',
    rollNumber: 'APS002',
    accessCode: 'APS102',
    registeredAt: '2026-06-07T12:05:00Z',
    status: 'idle',
    score: 0,
    violations: 0,
    progress: 0,
    answers: {},
    submitTime: null,
    startedAt: null,
  },
  // Test 2 Candidates
  {
    id: 'test_2_APS003',
    testId: 'test_2',
    name: 'Siddharth Roy',
    rollNumber: 'APS003',
    accessCode: 'APS103',
    registeredAt: '2026-06-07T12:10:00Z',
    status: 'idle',
    score: 0,
    violations: 0,
    progress: 0,
    answers: {},
    submitTime: null,
    startedAt: null,
  },
  {
    id: 'test_2_APS004',
    testId: 'test_2',
    name: 'Meera Krishnan',
    rollNumber: 'APS004',
    accessCode: 'APS104',
    registeredAt: '2026-06-07T12:15:00Z',
    status: 'idle',
    score: 0,
    violations: 0,
    progress: 0,
    answers: {},
    submitTime: null,
    startedAt: null,
  },
];

// Helper functions for LocalStorage persistence
export const loadExams = (): ExamData[] => {
  const saved = localStorage.getItem('examportal_exams');
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch {
      return DEFAULT_EXAMS;
    }
  }
  return DEFAULT_EXAMS;
};

export const saveExams = (exams: ExamData[]) => {
  localStorage.setItem('examportal_exams', JSON.stringify(exams));
};

export const loadCandidates = (): Candidate[] => {
  const saved = localStorage.getItem('examportal_candidates');
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch {
      return DEFAULT_CANDIDATES;
    }
  }
  return DEFAULT_CANDIDATES;
};

export const saveCandidates = (candidates: Candidate[]) => {
  localStorage.setItem('examportal_candidates', JSON.stringify(candidates));
};

export const loadLogs = (): ViolationLog[] => {
  const saved = localStorage.getItem('examportal_logs');
  return saved ? JSON.parse(saved) : [];
};

export const saveLogs = (logs: ViolationLog[]) => {
  localStorage.setItem('examportal_logs', JSON.stringify(logs));
};
