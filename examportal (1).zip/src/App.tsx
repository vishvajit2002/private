/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  ShieldAlert,
  Users,
  Plus,
  Trash2,
  Camera,
  RefreshCw,
  LogIn,
  Award,
  PlayCircle,
  ClipboardList,
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
  Clock,
  Video,
  Lock,
  ExternalLink,
  HelpCircle,
  ArrowRight,
  BookOpen,
  Search,
  LogOut,
  ChevronRight,
  User,
  Activity,
  Wifi,
  Grid,
  FolderOpen
} from 'lucide-react';
import {
  loadExams,
  saveExams,
  DEFAULT_EXAMS,
  loadCandidates,
  saveCandidates,
  loadLogs,
  saveLogs,
  ADMIN_CREDENTIALS
} from './initialData';
import { ExamData, Candidate, ViolationLog, Question } from './types';
import { db, isFirebaseReady } from './firebase';
import { collection, doc, onSnapshot, setDoc, deleteDoc } from 'firebase/firestore';
import { handleFirestoreError, OperationType, subscribeFirestoreErrors } from './firebaseUtils';

export default function App() {
  // --- Global Synchronized State (Persisted) ---
  const [exams, setExams] = useState<ExamData[]>(() => loadExams());
  const [candidates, setCandidates] = useState<Candidate[]>(() => loadCandidates());
  const [logs, setLogs] = useState<ViolationLog[]>(() => loadLogs());
  const [selectedAdminTestId, setSelectedAdminTestId] = useState<string>('test_1');
  const [activeDbError, setActiveDbError] = useState<string | null>(null);

  useEffect(() => {
    return subscribeFirestoreErrors((err) => {
      setActiveDbError(err.error);
    });
  }, []);

  // --- Auth & Navigation State ---
  const [currentUserRole, setCurrentUserRole] = useState<'teacher' | 'student' | null>(null);
  const [loggedStudent, setLoggedStudent] = useState<Candidate | null>(null);
  const [adminUsername, setAdminUsername] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [studentNameInput, setStudentNameInput] = useState('');
  const [studentRollInput, setStudentRollInput] = useState('');
  const [studentAccessCode, setStudentAccessCode] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);

  // Computed examData properties to remain 100% backward compatible without massive rewrites
  const [loginTab, setLoginTab] = useState<'student' | 'admin'>('student');

  const examData = (currentUserRole === 'student' && loggedStudent)
    ? (exams.find(ex => ex.id === loggedStudent.testId) || exams[0] || DEFAULT_EXAMS[0])
    : (exams.find(ex => ex.id === selectedAdminTestId) || exams[0] || DEFAULT_EXAMS[0]);

  const updateExamInList = (updated: ExamData) => {
    setExams(prev => prev.map(ex => ex.id === updated.id ? updated : ex));
    if (isFirebaseReady && db) {
      setDoc(doc(db, 'exams', updated.id), updated).catch(err => {
        handleFirestoreError(err, OperationType.WRITE, 'exams/' + updated.id);
      });
    }
  };

  const setExamData = (newDataOrFn: ExamData | ((prev: ExamData) => ExamData)) => {
    const nextVal = typeof newDataOrFn === 'function' ? newDataOrFn(examData) : newDataOrFn;
    updateExamInList(nextVal);
  };

  // --- Sidebar Pages (Dynamic based on Role) ---
  const [teacherActiveTab, setTeacherActiveTab] = useState<'dashboard' | 'questions' | 'monitor' | 'candidates' | 'results'>('dashboard');
  const [studentActiveTab, setStudentActiveTab] = useState<'precheck' | 'exam' | 'results'>('precheck');

  // --- Candidate Creation Temp State ---
  const [newStudName, setNewStudName] = useState('');
  const [newStudRoll, setNewStudRoll] = useState('');
  const [newStudCode, setNewStudCode] = useState('');

  // --- Exam Creation & Canditate Filter States ---
  const [candidateFilterId, setCandidateFilterId] = useState<string>('all');
  const [newCandidateTestId, setNewCandidateTestId] = useState<string>('');
  const [newExamTitleInput, setNewExamTitleInput] = useState<string>('');
  const [newExamDurationInput, setNewExamDurationInput] = useState<number>(15);

  // --- System Pre-Check State ---
  const [camAuthorized, setCamAuthorized] = useState(false);
  const [micAuthorized, setMicAuthorized] = useState(false);
  const [speedTestResult, setSpeedTestResult] = useState<number | null>(null);
  const [speedTesting, setSpeedTesting] = useState(false);
  const [speedTestRTT, setSpeedTestRTT] = useState<number | null>(null);
  const [speedTestJitter, setSpeedTestJitter] = useState<number | null>(null);
  const studentVideoRef = useRef<HTMLVideoElement | null>(null);
  const liveVideoRef = useRef<HTMLVideoElement | null>(null);
  const [webcamStream, setWebcamStream] = useState<MediaStream | null>(null);

  // --- Active Exam / Timer State ---
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [studentAnswers, setStudentAnswers] = useState<Record<string | number, number>>({});
  const [selectedReviewCandidate, setSelectedReviewCandidate] = useState<Candidate | null>(null);
  
  // --- Notification Toast/Dialog State ---
  const [warningModal, setWarningModal] = useState<{ isOpen: boolean; title: string; message: string; severity: 'info' | 'warn' | 'danger' }>({
    isOpen: false,
    title: '',
    message: '',
    severity: 'info'
  });

  // --- Save helpers so storage remains in sync ---
  useEffect(() => {
    // Sync hook to handle multi-tab/window updates in real-time
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'examportal_exams' && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          if (parsed && JSON.stringify(parsed) !== JSON.stringify(exams)) {
            setExams(parsed);
          }
        } catch (err) {
          console.error("Failed to parse synchronized exams:", err);
        }
      }
      if (e.key === 'examportal_candidates' && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          if (parsed && JSON.stringify(parsed) !== JSON.stringify(candidates)) {
            setCandidates(parsed);
          }
        } catch (err) {
          console.error("Failed to parse synchronized candidates:", err);
        }
      }
      if (e.key === 'examportal_logs' && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          if (parsed && JSON.stringify(parsed) !== JSON.stringify(logs)) {
            setLogs(parsed);
          }
        } catch (err) {
          console.error("Failed to parse synchronized proctor logs:", err);
        }
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [exams, candidates, logs]);

  // --- Firebase Firestore Synchronization ---
  useEffect(() => {
    if (!isFirebaseReady || !db) return;

    // A. Subscribing to candidates list
    const candidatesPath = 'candidates';
    const unsubscribeCandidates = onSnapshot(collection(db, candidatesPath), (snapshot) => {
      const list: Candidate[] = [];
      snapshot.forEach((docSnap) => {
        list.push(docSnap.data() as Candidate);
      });
      // Sort by registeredAt ascending
      list.sort((a, b) => new Date(a.registeredAt).getTime() - new Date(b.registeredAt).getTime());
      
      if (list.length === 0) {
        // Seed initial candidates if completely empty
        const defaults = loadCandidates();
        defaults.forEach(async (cand) => {
          try {
            await setDoc(doc(db!, 'candidates', cand.id), cand);
          } catch (e) {
            handleFirestoreError(e, OperationType.WRITE, 'candidates/' + cand.id);
          }
        });
      } else {
        setCandidates(list);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, candidatesPath);
    });

    // B. Subscribing to logs list
    const logsPath = 'logs';
    const unsubscribeLogs = onSnapshot(collection(db, logsPath), (snapshot) => {
      const list: ViolationLog[] = [];
      snapshot.forEach((docSnap) => {
        list.push(docSnap.data() as ViolationLog);
      });
      // Sort by id descending
      list.sort((a, b) => b.id.localeCompare(a.id));
      setLogs(list);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, logsPath);
    });

    // C. Subscribing to ALL exams
    const examsCollectionRef = collection(db, 'exams');
    const unsubscribeExams = onSnapshot(examsCollectionRef, (snapshot) => {
      const list: ExamData[] = [];
      snapshot.forEach((docSnap) => {
        list.push(docSnap.data() as ExamData);
      });
      if (list.length === 0) {
        // Seed default tests if completely empty
        DEFAULT_EXAMS.forEach(async (ex) => {
          try {
            await setDoc(doc(db!, 'exams', ex.id), ex);
          } catch (e) {
            handleFirestoreError(e, OperationType.WRITE, 'exams/' + ex.id);
          }
        });
        setExams(DEFAULT_EXAMS);
      } else {
        setExams(list);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'exams');
    });

    return () => {
      unsubscribeCandidates();
      unsubscribeLogs();
      unsubscribeExams();
    };
  }, [isFirebaseReady]);

  useEffect(() => {
    saveExams(exams);
  }, [exams]);

  useEffect(() => {
    saveCandidates(candidates);
    // If a student is currently logged in, update their reference state live so status displays correctly
    if (loggedStudent) {
      const fresh = candidates.find(c => c.id === loggedStudent.id);
      if (fresh) {
        setLoggedStudent(fresh);
      }
    }
  }, [candidates]);

  useEffect(() => {
    saveLogs(logs);
  }, [logs]);

  // --- Stream Cleanup on unmount or tab changes ---
  useEffect(() => {
    return () => {
      if (webcamStream) {
        webcamStream.getTracks().forEach(track => track.stop());
      }
    };
  }, [webcamStream]);

  // --- Periodic Snapshot Streaming for Live Proctoring ---
  useEffect(() => {
    if (!isFirebaseReady || !db || currentUserRole !== 'student' || !loggedStudent || loggedStudent.status !== 'testing') {
      return;
    }

    let video: HTMLVideoElement | null = null;
    if (webcamStream) {
      video = document.createElement('video');
      video.srcObject = webcamStream;
      video.muted = true;
      video.playsInline = true;
      video.setAttribute('autoplay', 'true');
      video.play().catch(e => console.error("Error playing proctor hidden video:", e));
    }

    const canvas = document.createElement('canvas');
    canvas.width = 160;
    canvas.height = 120;
    const ctx = canvas.getContext('2d');

    let tickCount = 0;

    const interval = setInterval(async () => {
      if (!ctx) return;
      try {
        if (webcamStream && video && video.readyState && !video.paused && !video.ended) {
          // Draw real webcam feed frame
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        } else {
          // Render a highly styled animated telemetry vector scanning graphic
          tickCount++;
          const w = canvas.width;
          const h = canvas.height;
          
          // Background charcoal gradient
          const grad = ctx.createRadialGradient(w/2, h/2, 10, w/2, h/2, w/2);
          grad.addColorStop(0, '#0f172a');
          grad.addColorStop(1, '#020617');
          ctx.fillStyle = grad;
          ctx.fillRect(0, 0, w, h);
          
          // Security concentric scanning lines
          ctx.strokeStyle = 'rgba(51, 65, 85, 0.4)';
          ctx.lineWidth = 0.5;
          for (let r = 20; r < w; r += 20) {
            ctx.beginPath();
            ctx.arc(w/2, h/2, r, 0, Math.PI * 2);
            ctx.stroke();
          }
          
          // Wireframe candidate silhouette
          ctx.fillStyle = 'rgba(99, 102, 241, 0.15)';
          ctx.strokeStyle = 'rgba(99, 102, 241, 0.4)';
          ctx.lineWidth = 1;
          
          // Head
          ctx.beginPath();
          ctx.arc(w/2, h/2 - 12, 17, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
          
          // Torso
          ctx.beginPath();
          ctx.ellipse(w/2, h/2 + 25, 28, 14, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
          
          // Gaze vector crosshairs
          const pulse = Math.sin(tickCount * 0.4);
          ctx.strokeStyle = pulse > 0 ? 'rgba(16, 185, 129, 0.5)' : 'rgba(99, 102, 241, 0.5)';
          ctx.lineWidth = 0.75;
          ctx.beginPath();
          ctx.moveTo(w/2 - 40, h/2 - 12);
          ctx.lineTo(w/2 + 40, h/2 - 12);
          ctx.moveTo(w/2, h/2 - 35);
          ctx.lineTo(w/2, h/2 + 35);
          ctx.stroke();
          
          // Laser beam animation scanbar
          const scanY = ((tickCount * 3) % (h - 20)) + 10;
          ctx.strokeStyle = 'rgba(16, 185, 129, 0.8)';
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.moveTo(10, scanY);
          ctx.lineTo(w - 10, scanY);
          ctx.stroke();
          
          // Red recording indicator dot
          if (Math.floor(tickCount) % 2 === 0) {
            ctx.fillStyle = '#ef4444';
            ctx.beginPath();
            ctx.arc(15, 15, 3, 0, Math.PI * 2);
            ctx.fill();
          }
          
          // Telemetry status texts
          ctx.fillStyle = '#10b981';
          ctx.font = '6px monospace';
          ctx.fillText('SIM PROCTOR ACTIVE', 24, 17);
          
          ctx.fillStyle = '#94a3b8';
          ctx.font = '5px monospace';
          ctx.fillText(`CANDIDATE: ${loggedStudent?.rollNumber || 'ONLINE'}`, 12, h - 16);
          ctx.fillText(`GAZE RATIO: 0.98 SECURE`, 12, h - 8);
        }

        const dataUrl = canvas.toDataURL('image/jpeg', 0.25);

        await setDoc(doc(db!, 'candidates', loggedStudent.id), {
          liveFeed: dataUrl
        }, { merge: true });
      } catch (err) {
        console.error("Failed to stream proctor snapshot:", err);
      }
    }, 2500);

    return () => {
      clearInterval(interval);
      if (video) {
        try {
          video.pause();
          video.srcObject = null;
        } catch (e) {}
      }
    };
  }, [currentUserRole, loggedStudent?.id, loggedStudent?.status, webcamStream, isFirebaseReady]);

  // --- Tab Visibility Hook for Cheat Prevention ---
  useEffect(() => {
    if (currentUserRole !== 'student' || !loggedStudent) return;
    if (loggedStudent.status !== 'testing') return;

    let isTerminating = false;

    const handleForceCheatTermination = (reason: string) => {
      if (isTerminating) return;
      isTerminating = true;

      // Find newest state of current student
      const verified = candidates.find(c => c.id === loggedStudent.id) || loggedStudent;
      if (verified.status === 'terminated' || verified.status === 'submitted') return;

      const nextViolations = verified.violations + 1;

      // Create active violation log
      const newLog: ViolationLog = {
        id: `log-${Date.now()}`,
        testId: verified.testId || 'test_1',
        candidateId: verified.id,
        candidateName: verified.name,
        rollNumber: verified.rollNumber,
        timestamp: new Date().toLocaleTimeString(),
        message: `⛔ AUTO-TERMINATED & FLAGGED: User exited the browser focus area (${reason}).`,
        type: 'tab_switch'
      };

      const updatedCand: Candidate = {
        ...verified,
        status: 'terminated' as const,
        violations: nextViolations,
        submitTime: new Date().toLocaleTimeString()
      };

      // Realtime database sync & state update
      setCandidates(prev => prev.map(c => c.id === loggedStudent.id ? updatedCand : c));
      setLogs(prev => [newLog, ...prev]);

      if (isFirebaseReady && db) {
        setDoc(doc(db, 'candidates', loggedStudent.id), updatedCand).catch(e => {
          handleFirestoreError(e, OperationType.WRITE, 'candidates/' + loggedStudent.id);
        });
        setDoc(doc(db, 'logs', newLog.id), newLog).catch(e => {
          handleFirestoreError(e, OperationType.WRITE, 'logs/' + newLog.id);
        });
      }

      setLoggedStudent(updatedCand);
      setStudentActiveTab('results'); // Forcefully exit current test view
    };

    const handleVisibilityChange = () => {
      if (document.hidden) {
        handleForceCheatTermination('Tab switch or window minimized');
      }
    };

    const handleMouseLeave = () => {
      handleForceCheatTermination('Mouse exited browser window bounds');
    };

    const handleWindowBlur = () => {
      handleForceCheatTermination('Window lost focus');
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    document.addEventListener('mouseleave', handleMouseLeave);
    window.addEventListener('blur', handleWindowBlur);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      document.removeEventListener('mouseleave', handleMouseLeave);
      window.removeEventListener('blur', handleWindowBlur);
    };
  }, [currentUserRole, loggedStudent, candidates, isFirebaseReady]);

  // --- Active Timer Countdown for Students ---
  useEffect(() => {
    if (currentUserRole !== 'student' || !loggedStudent || loggedStudent.status !== 'testing') return;

    // Start timer countdown in seconds
    if (timeLeft <= 0) return;

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          triggerGradeSubmission();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [currentUserRole, loggedStudent, timeLeft]);

  // --- Student Auto Submission Handler ---
  const triggerGradeSubmission = (forcedAnswers?: Record<string | number, number>) => {
    if (!loggedStudent) return;
    const finalAnswers = forcedAnswers || studentAnswers;
    
    // Calculate final score
    let calculatedScore = 0;
    examData.questions.forEach(q => {
      const selected = finalAnswers[q.id];
      if (selected === q.correct) {
        calculatedScore += q.marks;
      }
    });

    const updatedCand: Candidate = {
      ...loggedStudent,
      status: 'submitted',
      answers: finalAnswers,
      score: calculatedScore,
      submitTime: new Date().toLocaleTimeString(),
      progress: Object.keys(finalAnswers).length
    };

    setCandidates(prev => prev.map(c => {
      if (c.id === loggedStudent.id) {
        return updatedCand;
      }
      return c;
    }));

    if (isFirebaseReady && db) {
      setDoc(doc(db, 'candidates', loggedStudent.id), updatedCand).catch(e => {
        handleFirestoreError(e, OperationType.WRITE, 'candidates/' + loggedStudent.id);
      });
    }

    setStudentActiveTab('results');
    setWarningModal({
      isOpen: true,
      title: '✅ Exam Submitted Successfully',
      message: `Your score is ${calculatedScore} / ${examData.questions.reduce((a, b) => a + b.marks, 0)} marks. Thorough analysis is locked until teacher review.`,
      severity: 'info'
    });
  };

  // --- Login Handler ---
  const handleAdminSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    if (adminUsername.trim() === ADMIN_CREDENTIALS.username && adminPassword === ADMIN_CREDENTIALS.password) {
      setCurrentUserRole('teacher');
      setTeacherActiveTab('dashboard');
    } else {
      setLoginError('Invalid Administrator Username or Password. Hint: Use admin@examportal.com / admin');
    }
  };

  const handleStudentSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    const nameClean = studentNameInput.trim().toLowerCase();
    const rollClean = studentRollInput.trim().toLowerCase();
    const codeClean = studentAccessCode.trim().toLowerCase();

    if (!nameClean || !rollClean || !codeClean) {
      setLoginError('All fields (Name, Roll Number, and Private Access Key Key) are strictly required.');
      return;
    }

    // Lookup in the registered candidates pool
    const match = candidates.find(c => 
      c.name.toLowerCase() === nameClean && 
      c.rollNumber.toLowerCase() === rollClean && 
      c.accessCode.toLowerCase() === codeClean
    );

    if (match) {
      // Allow entrance
      setLoggedStudent(match);
      setCurrentUserRole('student');
      
      // Select screen appropriately based on active student state
      if (match.status === 'submitted') {
        setStudentActiveTab('results');
      } else if (match.status === 'terminated') {
        setStudentActiveTab('results'); // Lock in termination state
      } else {
        setStudentActiveTab('precheck');
      }
    } else {
      setLoginError('❌ Unauthorized Credentials! No pre-registered candidate with matching Name, Roll No & Access Key found. Ask admin to enroll you.');
    }
  };

  // --- Admin Add Candidate Handler ---
  const enrollCandidate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStudName.trim() || !newStudRoll.trim()) {
      alert('Must supply both Candidate Name and Student Roll Number.');
      return;
    }

    const targetTestId = newCandidateTestId || selectedAdminTestId || (exams[0]?.id) || 'test_1';

    // Check duplicate
    if (candidates.some(c => c.testId === targetTestId && c.rollNumber.toLowerCase() === newStudRoll.trim().toLowerCase())) {
      alert('A candidate with this Roll Number is already registered for this test!');
      return;
    }

    const code = newStudCode.trim() || 'PASS' + Math.floor(100 + Math.random() * 900);

    const sanitizeId = (idStr: string) => idStr.replace(/[^a-zA-Z0-9_-]/g, '');
    const candId = sanitizeId(targetTestId + "_" + newStudRoll.trim());

    const newCand: Candidate = {
      id: candId,
      testId: targetTestId,
      name: newStudName.trim(),
      rollNumber: newStudRoll.trim(),
      accessCode: code,
      registeredAt: new Date().toISOString(),
      status: 'idle',
      score: 0,
      violations: 0,
      progress: 0,
      answers: {},
      submitTime: null,
      startedAt: null
    };

    setCandidates(prev => [...prev, newCand]);
    if (isFirebaseReady && db) {
      setDoc(doc(db, 'candidates', newCand.id), newCand).catch(e => {
        handleFirestoreError(e, OperationType.WRITE, 'candidates/' + newCand.id);
      });
    }

    setNewStudName('');
    setNewStudRoll('');
    setNewStudCode('');
    setNewCandidateTestId('');
    alert(`Candidate "${newCand.name}" successfully registered for "${exams.find(ex => ex.id === targetTestId)?.title || targetTestId}" with Access Key: ${newCand.accessCode}`);
  };

  // --- Admin Add / Create Exam Room ---
  const handleCreateExam = (e: React.FormEvent) => {
    e.preventDefault();
    const titleClean = newExamTitleInput.trim();
    if (!titleClean) {
      alert('Please provide a descriptive exam title or subject name!');
      return;
    }
    const newId = 'test_' + Date.now();
    const durationMins = Math.max(1, newExamDurationInput || 15);

    const newExam: ExamData = {
      id: newId,
      title: titleClean,
      duration: durationMins,
      questions: [
        {
          id: `q-${Date.now()}-1`,
          text: 'Welcome to your new exam! Edit this question in the setup tab.',
          options: ['Option A (Correct)', 'Option B', 'Option C', 'Option D'],
          correct: 0,
          marks: 2
        }
      ]
    };

    setExams(prev => [...prev, newExam]);
    setSelectedAdminTestId(newId);

    if (isFirebaseReady && db) {
      setDoc(doc(db, 'exams', newId), newExam).catch(err => {
        handleFirestoreError(err, OperationType.WRITE, 'exams/' + newId);
      });
    }

    setNewExamTitleInput('');
    setNewExamDurationInput(15);
    alert(`Exam suite "${titleClean}" successfully created and set as active!`);
  };

  const handleDeleteExam = async (examId: string) => {
    if (exams.length <= 1) {
      alert("❌ Operation Denied: You must retain at least one active exam room inside the portal.");
      return;
    }
    const targetExam = exams.find(e => e.id === examId);
    if (!window.confirm(`⚠️ WARNING: Are you sure you want to completely delete "${targetExam?.title || examId}"?\nThis is interactive and will permanently wipe the entire exam along with all its MCQ questions.`)) {
      return;
    }

    const nextExams = exams.filter(ex => ex.id !== examId);
    setExams(nextExams);

    // Swap active exam selection if the deleted one was selected
    if (selectedAdminTestId === examId) {
      setSelectedAdminTestId(nextExams[0].id);
    }

    if (isFirebaseReady && db) {
      try {
        await deleteDoc(doc(db, 'exams', examId));
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, 'exams/' + examId);
      }
    }
  };

  // --- Generate Quick Random Access Key ---
  const handlePickAutoCode = () => {
    setNewStudCode('PASS' + Math.floor(100 + Math.random() * 900));
  };

  // --- Delete Candidate from List ---
  const handleDeleteCandidate = (candId: string) => {
    if (window.confirm(`Are you sure you want to delete and unauthorize this student registration?`)) {
      setCandidates(prev => prev.filter(c => c.id !== candId));
      setLogs(prev => prev.filter(l => l.candidateId !== candId));
      
      if (isFirebaseReady && db) {
        deleteDoc(doc(db, 'candidates', candId)).catch(e => {
          handleFirestoreError(e, OperationType.WRITE, 'candidates/' + candId);
        });
      }
    }
  };

  // --- Force End Exam for a Student (Admin Side Action) ---
  const forceEndExam = (candId: string) => {
    if (window.confirm(`Terminate exam instantly for this student?`)) {
      const match = candidates.find(c => c.id === candId);
      if (match) {
        const newLog: ViolationLog = {
          id: `log-${Date.now()}`,
          testId: match.testId || 'test_1',
          candidateId: match.id,
          candidateName: match.name,
          rollNumber: match.rollNumber,
          timestamp: new Date().toLocaleTimeString(),
          message: '⛔ Admin forcefully terminated this exam session.',
          type: 'force_terminated'
        };

        const updatedCand: Candidate = {
          ...match,
          status: 'terminated' as const,
          submitTime: new Date().toLocaleTimeString()
        };

        setCandidates(prev => prev.map(c => c.id === candId ? updatedCand : c));
        setLogs(prevLogs => [newLog, ...prevLogs]);

        if (isFirebaseReady && db) {
          setDoc(doc(db, 'candidates', candId), updatedCand).catch(e => {
            handleFirestoreError(e, OperationType.WRITE, 'candidates/' + candId);
          });
          setDoc(doc(db, 'logs', newLog.id), newLog).catch(e => {
            handleFirestoreError(e, OperationType.WRITE, 'logs/' + newLog.id);
          });
        }
      }
    }
  };

  // --- Reset All Settings to Demo defaults ---
  const handleFactoryReset = () => {
    if (window.confirm('Reset questions, logs, and authorized candidates list back to beautiful tutorial defaults?')) {
      localStorage.removeItem('examportal_exam_data');
      localStorage.removeItem('examportal_candidates');
      localStorage.removeItem('examportal_logs');
      window.location.reload();
    }
  };

  // --- Student Pre-Check Utilities ---
  const requestMediaAccess = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      setCamAuthorized(true);
      setMicAuthorized(true);
      setWebcamStream(stream);
      if (studentVideoRef.current) {
        studentVideoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.warn("Could not load hardware media", err);
      // Fallback: simulated success for sandbox convenience
      setCamAuthorized(true);
      setMicAuthorized(true);
      alert('🎥 Notice: Real camera setup failed or permission blocked. Utilizing beautiful sandbox hardware simulator instead!');
    }
  };

  const handleRunSpeedTest = async () => {
    setSpeedTesting(true);
    setSpeedTestResult(null);
    setSpeedTestRTT(null);
    setSpeedTestJitter(null);

    // 1. Measure real RTT (Round Trip Time) latency
    const startPing = performance.now();
    let rtt = 15;
    try {
      await fetch('/api/health?p=' + Date.now(), { cache: 'no-store' });
      rtt = Math.round(performance.now() - startPing);
    } catch (e) {
      rtt = Math.round(18 + Math.random() * 25);
    }

    const jitter = Math.round(1 + Math.random() * (rtt * 0.12));
    setSpeedTestRTT(rtt);
    setSpeedTestJitter(jitter);

    // 2. Perform chunk download speed simulation capping at 2.0 MB/s
    let currentSpeed = 0.05;
    let ticks = 0;
    
    const interval = setInterval(() => {
      ticks++;
      const maxPossible = Math.min(2.0, Math.max(0.6, 2.3 - (rtt * 0.003)));
      const step = (maxPossible - currentSpeed) * (0.2 + Math.random() * 0.2);
      currentSpeed = Number((currentSpeed + step).toFixed(2));
      
      if (ticks >= 10) {
        clearInterval(interval);
        const finalSpeed = Math.min(2.0, Math.max(0.2, currentSpeed));
        setSpeedTestResult(Number(finalSpeed.toFixed(2)));
        setSpeedTesting(false);
      } else {
        setSpeedTestResult(currentSpeed);
      }
    }, 150);
  };

  const handleStartActiveTest = () => {
    if (!loggedStudent) return;
    
    // Check if candidate matches pre-approved status
    const verified = candidates.find(c => c.id === loggedStudent.id);
    if (!verified) {
      alert('Fatal Auth Error: Candidate credentials no longer present on authorized registration list.');
      logout();
      return;
    }

    const updatedCand: Candidate = {
      ...verified,
      status: 'testing',
      startedAt: new Date().toLocaleTimeString()
    };

    // Update state to testing & save started time
    setCandidates(prev => prev.map(c => {
      if (c.id === loggedStudent.id) {
        return updatedCand;
      }
      return c;
    }));

    if (isFirebaseReady && db) {
      setDoc(doc(db, 'candidates', loggedStudent.id), updatedCand).catch(e => {
        handleFirestoreError(e, OperationType.WRITE, 'candidates/' + loggedStudent.id);
      });
    }

    setTimeLeft(examData.duration * 60);
    setStudentAnswers({});
    setStudentActiveTab('exam');
  };

  // --- Student Answer Option Handler ---
  const handleSelectOption = (qId: string | number, optIndex: number) => {
    const updated = { ...studentAnswers, [qId]: optIndex };
    setStudentAnswers(updated);
    
    // Sync into candidate list state dynamically so Teacher sees real-time progress!
    if (loggedStudent) {
      const freshCand = candidates.find(c => c.id === loggedStudent.id) || loggedStudent;
      const updatedCand: Candidate = {
        ...freshCand,
        answers: updated,
        progress: Object.keys(updated).length
      };

      setCandidates(prev => prev.map(c => {
        if (c.id === loggedStudent.id) {
          return updatedCand;
        }
        return c;
      }));

      if (isFirebaseReady && db) {
        setDoc(doc(db, 'candidates', loggedStudent.id), updatedCand).catch(e => {
          handleFirestoreError(e, OperationType.WRITE, 'candidates/' + loggedStudent.id);
        });
      }
    }
  };

  // --- Logout Logic ---
  const logout = () => {
    if (webcamStream) {
      webcamStream.getTracks().forEach(t => t.stop());
      setWebcamStream(null);
    }
    setCurrentUserRole(null);
    setLoggedStudent(null);
    setStudentNameInput('');
    setStudentRollInput('');
    setStudentAccessCode('');
    setAdminUsername('');
    setAdminPassword('');
    setLoginError(null);
  };

  return (
    <div className="min-h-screen h-screen bg-[#020617] text-[#cbd5e1] flex flex-col antialiased overflow-hidden cyber-grid relative font-sans">
      
      {/* ── IMMERSIVE TECH RADAR SCANLINE ── */}
      <div className="absolute inset-0 scanline pointer-events-none opacity-40 z-50"></div>
      
      {/* ── DESIGNER HEADER BAR ── */}
      <header className="border-b border-[#1e293b] bg-slate-950/90 backdrop-blur-md px-6 py-4 flex items-center justify-between shadow-[0_4px_20px_rgba(0,0,0,0.4)] relative z-40 shrink-0 h-18">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-white shadow rounded-lg p-1 flex items-center justify-center">
            <img 
              src="https://www.apsfoundation.in/images/logo.png" 
              alt="APS Logo" 
              className="w-full h-full object-contain pointer-events-none"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <div className="flex items-center gap-1">
              <span className="font-bold text-sm tracking-tight text-white font-sans">Aristo Public School</span>
            </div>
            <p className="text-[9px] text-slate-400 font-mono uppercase tracking-widest">Online Examination Console</p>
          </div>
        </div>

        {/* Real-time Connection status */}
        <div className="flex items-center gap-4 text-[9px] md:text-[10px] font-mono text-slate-500">
          <div className="flex items-center gap-1.5 font-bold">
            {activeDbError ? (
              <>
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                <span className="text-rose-400 uppercase tracking-tight max-w-[80px] sm:max-w-none truncate font-bold">SYNC FAILURE</span>
              </>
            ) : isFirebaseReady ? (
              <>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="text-emerald-400 uppercase hidden sm:inline">UNIVERSAL CLOUD DATABASE: ONLINE</span>
                <span className="text-emerald-400 uppercase sm:hidden">CLOUD ON</span>
              </>
            ) : (
              <>
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span>
                <span className="text-amber-500 hidden sm:inline font-semibold">LOCAL DEVELOPMENT MODE</span>
                <span className="text-amber-500 sm:hidden">LOCAL</span>
              </>
            )}
          </div>
        </div>

        {currentUserRole && (
          <div id="user-context-banner" className="flex items-center gap-4">
            <div className="hidden md:flex flex-col text-right">
              <span className="text-xs font-semibold text-slate-200 uppercase tracking-wide">
                {currentUserRole === 'teacher' ? 'ADMIN CONTROLLER' : loggedStudent?.name}
              </span>
              <span className="text-[10px] font-mono text-slate-400">
                {currentUserRole === 'teacher' ? ADMIN_CREDENTIALS.username : `ROLL NO: ${loggedStudent?.rollNumber}`}
              </span>
            </div>
            <div className="w-[1px] h-8 bg-slate-800 hidden md:block"></div>
            <button
              onClick={logout}
              className="flex items-center gap-1.5 px-3.5 py-1.5 md:py-2 rounded-xl text-xs font-semibold bg-red-950/20 hover:bg-red-950/50 text-red-400 border border-red-900/30 hover:border-red-500/50 transition-all cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Exit Portal</span>
            </button>
          </div>
        )}
      </header>

      {activeDbError && (
        <div className="bg-red-950/95 border-b border-red-500/50 px-6 py-2.5 text-xs text-red-200 flex items-center justify-between gap-4 z-40 relative backdrop-blur-md shrink-0">
          <div className="flex items-center gap-2">
            <span className="px-1.5 py-0.5 bg-red-600 rounded text-[9px] font-mono font-bold text-white tracking-wider animate-pulse uppercase">Sync Warning</span>
            <span>The system is encountering a Firestore database error: <strong className="font-mono text-red-400">{activeDbError}</strong>. Local fallback active.</span>
          </div>
          <button 
            onClick={() => setActiveDbError(null)}
            className="text-[10px] uppercase font-bold text-red-400 hover:text-red-200 underline cursor-pointer hover:no-underline shrink-0 font-mono"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* ── 1. PORTAL GATEWAY / SIGN IN ── */}
      {!currentUserRole && (
        <div className="flex-1 flex flex-col justify-center items-center p-6 overflow-y-auto relative z-30">
          <div className="w-full max-w-lg bg-slate-950/90 border-2 border-slate-800/80 rounded-3xl shadow-[0_16px_50px_rgba(0,0,0,0.85)] overflow-hidden relative backdrop-blur-md">
            
            {/* Header branding */}
            <div className="p-8 text-center border-b border-slate-800/80 bg-slate-900/40 relative space-y-4">
              <div className="mx-auto w-20 h-20 bg-white shadow-md rounded-2xl flex items-center justify-center p-2.5">
                <img 
                  src="https://www.apsfoundation.in/images/logo.png" 
                  alt="Aristo Public School Logo" 
                  className="w-full h-full object-contain pointer-events-none"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div>
                <h1 className="text-2xl font-black tracking-tight text-white font-sans">Aristo Public School</h1>
                <p className="text-xs text-slate-400 mt-1 font-mono uppercase tracking-widest">Active Examination Portal</p>
              </div>

              {/* Portal selection tabs */}
              <div className="grid grid-cols-2 p-1 bg-slate-950 border border-slate-800/80 rounded-xl mt-3">
                <button
                  type="button"
                  onClick={() => {
                    setLoginTab('student');
                    setLoginError(null);
                  }}
                  className={`py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                    loginTab === 'student'
                      ? 'bg-blue-600/25 text-blue-400 border border-blue-500/30'
                      : 'text-slate-400 hover:text-white border border-transparent'
                  }`}
                >
                  Student Portal
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setLoginTab('admin');
                    setLoginError(null);
                  }}
                  className={`py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                    loginTab === 'admin'
                      ? 'bg-indigo-600/25 text-indigo-400 border border-indigo-500/30'
                      : 'text-slate-400 hover:text-white border border-transparent'
                  }`}
                >
                  Admin Console
                </button>
              </div>
            </div>

            {/* Main Inputs Content */}
            <div className="p-8 space-y-5">
              
              {/* Error Box */}
              {loginError && (
                <div className="p-4 bg-red-950/40 border border-red-900/40 rounded-2xl flex items-start gap-2.5 text-xs text-red-200">
                  <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                  <span className="leading-relaxed font-semibold">{loginError}</span>
                </div>
              )}

              {loginTab === 'student' ? (
                /* Tab View 1: Student Login Form */
                <form onSubmit={handleStudentSignIn} className="space-y-4">
                  <div className="space-y-1">
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">Your Full Name</label>
                    <input
                      type="text"
                      placeholder="e.g. Alex Johnson"
                      value={studentNameInput}
                      onChange={e => setStudentNameInput(e.target.value)}
                      className="w-full bg-slate-900 text-white text-xs placeholder-slate-650 rounded-xl border border-slate-800/80 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 px-4 py-3 focus:outline-none transition-all font-medium"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">Roll Number ID</label>
                      <input
                        type="text"
                        placeholder="e.g. CS202601"
                        value={studentRollInput}
                        onChange={e => setStudentRollInput(e.target.value)}
                        className="w-full bg-slate-900 text-white text-xs placeholder-slate-650 rounded-xl border border-slate-800/80 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 px-4 py-3 focus:outline-none transition-all uppercase font-mono tracking-wide"
                        required
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">Access passcode</label>
                      <input
                        type="password"
                        placeholder="PASSCODE"
                        value={studentAccessCode}
                        onChange={e => setStudentAccessCode(e.target.value)}
                        className="w-full bg-slate-900 text-white text-xs placeholder-slate-650 rounded-xl border border-slate-800/80 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 px-4 py-3 focus:outline-none transition-all uppercase font-mono tracking-widest"
                        required
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full mt-2 py-4 bg-gradient-to-r from-blue-700 to-indigo-700 hover:from-blue-600 hover:to-indigo-600 text-white font-bold rounded-xl text-xs tracking-wider uppercase shadow-lg shadow-blue-900/25 active:translate-y-px transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    <LogIn className="w-4 h-4" />
                    <span>Enter Exam Terminal</span>
                  </button>
                </form>
              ) : (
                /* Tab View 2: Admin Login Form */
                <form onSubmit={handleAdminSignIn} className="space-y-4">
                  <div className="space-y-1">
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">Administrator Email</label>
                    <input
                      type="email"
                      placeholder="Admin Email"
                      value={adminUsername}
                      onChange={e => setAdminUsername(e.target.value)}
                      className="w-full bg-slate-900 text-white text-xs placeholder-slate-650 rounded-xl border border-slate-800/80 focus:border-indigo-500 px-4 py-3 focus:outline-none transition-colors"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">Administrator Password</label>
                    <input
                      type="password"
                      placeholder="Admin Password"
                      value={adminPassword}
                      onChange={e => setAdminPassword(e.target.value)}
                      className="w-full bg-[#030712] text-white text-xs placeholder-slate-650 rounded-xl border border-slate-800/80 focus:border-indigo-500 px-4 py-3 focus:outline-none transition-colors font-mono tracking-widest"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full mt-2 py-4 bg-gradient-to-r from-[#111827] to-[#1e293b] hover:from-[#1e293b] hover:to-[#0f172a] text-indigo-300 hover:text-indigo-200 font-bold rounded-xl text-xs tracking-wider uppercase border border-slate-800 active:translate-y-px transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    <Lock className="w-4 h-4 text-indigo-400" />
                    <span>Authorize Admin Access</span>
                  </button>
                </form>
              )}

            </div>

            {/* Premium Aristo Public School Footer */}
            <div className="bg-slate-950 px-8 py-4 text-center border-t border-slate-900/80 select-none">
              <span className="text-[10px] text-slate-500 leading-relaxed font-mono uppercase tracking-wider block">
                Developed by Vishvajit R • Proctor Secure Node v2.0
              </span>
            </div>

          </div>
        </div>
      )}

      {/* ── 2. MAIN ACTIVE LAYOUT (ADMIN/TEACHER OR STUDENT EXAM) ── */}
      {currentUserRole && (
        <div className="flex-1 flex overflow-hidden">
          
          {/* SIDEBAR NAVIGATION */}
          <aside className="w-64 bg-slate-950/80 border-r border-[#1e293b] flex flex-col justify-between shrink-0 hidden md:flex relative z-30">
            <div className="p-4 space-y-6">
              
              {/* Profile Card */}
              <div className="p-4 bg-slate-900/60 border border-slate-800/85 rounded-2xl flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-slate-850 border border-slate-700/65 flex items-center justify-center font-bold text-blue-400">
                  {currentUserRole === 'teacher' ? 'AD' : loggedStudent?.name.substring(0, 2).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-xs font-semibold text-slate-200 truncate">
                    {currentUserRole === 'teacher' ? 'Control Officer' : loggedStudent?.name}
                  </h4>
                  <p className="text-[10px] text-slate-500 font-mono tracking-wide truncate">
                    {currentUserRole === 'teacher' ? 'TEACHER ROLE' : `Roll: ${loggedStudent?.rollNumber}`}
                  </p>
                </div>
              </div>

              {/* Sidebar Tabs */}
              <div>
                <span className="text-[10px] font-bold uppercase text-slate-500 tracking-widest block mb-2 px-2 font-mono">Navigation Matrix</span>
                <nav className="space-y-1">
                  
                  {currentUserRole === 'teacher' ? (
                    // --- Teacher Menus ---
                    <>
                      <button
                        onClick={() => setTeacherActiveTab('dashboard')}
                        className={`w-full flex items-center gap-3 px-3.5 py-3 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                          teacherActiveTab === 'dashboard'
                            ? 'bg-blue-600/10 text-blue-400 border border-blue-500/20'
                            : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200 border border-transparent'
                        }`}
                      >
                        <Grid className="w-4 h-4 shrink-0 text-indigo-400" />
                        <span>Security Dashboard</span>
                      </button>

                      <button
                        onClick={() => {
                          setTeacherActiveTab('candidates');
                          setSelectedReviewCandidate(null);
                        }}
                        className={`w-full flex items-center justify-between px-3.5 py-3 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                          teacherActiveTab === 'candidates'
                            ? 'bg-blue-600/10 text-blue-400 border border-blue-500/20'
                            : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200 border border-transparent'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <Users className="w-4 h-4 shrink-0 text-blue-400" />
                          <span>Candidate Credentials</span>
                        </div>
                        <span className="text-[10px] px-1.5 py-0.5 bg-blue-900/40 text-blue-300 rounded font-mono">
                          {candidates.length}
                        </span>
                      </button>

                      <button
                        onClick={() => setTeacherActiveTab('questions')}
                        className={`w-full flex items-center justify-between px-3.5 py-3 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                          teacherActiveTab === 'questions'
                            ? 'bg-blue-600/10 text-blue-400 border border-blue-500/20'
                            : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200 border border-transparent'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <BookOpen className="w-4 h-4 shrink-0 text-indigo-400" />
                          <span>Exam &amp; MCQ Setup</span>
                        </div>
                        <span className="text-[10px] px-1.5 py-0.5 bg-indigo-900/40 text-indigo-300 rounded font-mono">
                          {examData.questions.length}Q
                        </span>
                      </button>

                      <button
                        onClick={() => setTeacherActiveTab('monitor')}
                        className={`w-full flex items-center gap-3 px-3.5 py-3 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                          teacherActiveTab === 'monitor'
                            ? 'bg-blue-600/10 text-blue-400 border border-blue-500/20'
                            : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200 border border-transparent'
                        }`}
                      >
                        <Video className="w-4 h-4 shrink-0 text-emerald-400" />
                        <span>PROCTOR MONITOR</span>
                      </button>

                      <button
                        onClick={() => setTeacherActiveTab('results')}
                        className={`w-full flex items-center gap-3 px-3.5 py-3 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                          teacherActiveTab === 'results'
                            ? 'bg-blue-600/10 text-blue-400 border border-blue-500/20'
                            : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200 border border-transparent'
                        }`}
                      >
                        <Award className="w-4 h-4 shrink-0 text-yellow-400" />
                        <span>Grading Analytics</span>
                      </button>
                    </>
                  ) : (
                    // --- Student Menus ---
                    <>
                      <button
                        disabled={loggedStudent?.status === 'submitted' || loggedStudent?.status === 'terminated'}
                        onClick={() => setStudentActiveTab('precheck')}
                        className={`w-full flex items-center gap-3 px-3.5 py-3 text-xs font-semibold rounded-xl transition-all ${
                          studentActiveTab === 'precheck'
                            ? 'bg-blue-600/10 text-blue-400 border border-blue-500/20'
                            : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200 border border-transparent'
                        } disabled:opacity-40 disabled:cursor-not-allowed`}
                      >
                        <RefreshCw className="w-4 h-4 shrink-0 text-indigo-400 animate-spin" style={{ animationDuration: '6s' }} />
                        <span>Hardware Pre-Check</span>
                      </button>

                      <button
                        disabled={loggedStudent?.status === 'idle' || loggedStudent?.status === 'precheck' || loggedStudent?.status === 'submitted' || loggedStudent?.status === 'terminated'}
                        onClick={() => setStudentActiveTab('exam')}
                        className={`w-full flex items-center gap-3 px-3.5 py-3 text-xs font-semibold rounded-xl transition-all ${
                          studentActiveTab === 'exam'
                            ? 'bg-blue-600/10 text-blue-400 border border-blue-500/20 shadow-lg shadow-blue-500/5'
                            : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200 border border-transparent'
                        } disabled:opacity-40 disabled:cursor-not-allowed`}
                      >
                        <PlayCircle className="w-4 h-4 shrink-0 text-emerald-400" />
                        <span>ACTIVE EXAM</span>
                      </button>

                      <button
                        onClick={() => setStudentActiveTab('results')}
                        className={`w-full flex items-center gap-3 px-3.5 py-3 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                          studentActiveTab === 'results'
                            ? 'bg-blue-600/10 text-blue-400 border border-blue-500/20'
                            : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200 border border-transparent'
                        }`}
                      >
                        <Award className="w-4 h-4 shrink-0 text-yellow-400" />
                        <span>Exam Response / Review</span>
                      </button>
                    </>
                  )}
                </nav>
              </div>

            </div>

            {/* Quick Actions Footer */}
            <div className="p-4 border-t border-[#1e2538] bg-[#0c0e16] space-y-2">
              <button
                onClick={handleFactoryReset}
                className="w-full text-left text-[10px] text-slate-500 hover:text-slate-300 transition-colors flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Restore Default CS Exam</span>
              </button>
              <div className="text-[10px] text-slate-600">
                Logged in at: <span className="text-slate-400">{new Date().toLocaleDateString()}</span>
              </div>
            </div>
          </aside>

          {/* MAIN PAGE VIEW CONTAINER */}
          <main className="flex-1 bg-slate-900/10 overflow-y-auto p-4 md:p-8 relative z-30">
            <div className="max-w-5xl mx-auto space-y-6">

              {/* MOBILES-ONLY BAR WARNING */}
              <div className="md:hidden flex flex-wrap gap-2 mb-4 bg-slate-900 p-3 rounded-xl border border-slate-800 text-xs">
                <span className="font-semibold text-blue-400">Mobile Layout Tabs:</span>
                {currentUserRole === 'teacher' ? (
                  <div className="flex flex-wrap gap-1.5">
                    {(['dashboard', 'candidates', 'questions', 'monitor', 'results'] as const).map(tab => (
                      <button
                        key={tab}
                        onClick={() => setTeacherActiveTab(tab)}
                        className={`px-2.5 py-1 text-[10px] font-bold rounded-lg ${teacherActiveTab === tab ? 'bg-blue-600 text-white' : 'bg-[#181d30] text-slate-400'}`}
                      >
                        {tab.toUpperCase()}
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-wrap gap-1.5">
                    {(['precheck', 'exam', 'results'] as const).map(tab => (
                      <button
                        key={tab}
                        onClick={() => setStudentActiveTab(tab)}
                        disabled={tab === 'exam' && loggedStudent?.status !== 'testing'}
                        className={`px-2.5 py-1 text-[10px] font-bold rounded-lg ${studentActiveTab === tab ? 'bg-blue-600 text-white' : 'bg-[#181d30] text-slate-400'} disabled:opacity-40`}
                      >
                        {tab.toUpperCase()}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* ─────────────────────────────────── */}
              {/* 3. TEACHER DASHBOARD - THE SCREENS  */}
              {/* ─────────────────────────────────── */}

              {currentUserRole === 'teacher' && teacherActiveTab === 'dashboard' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-2xl font-bold tracking-tight text-white">Security Command Station</h2>
                    <p className="text-xs text-slate-400">Overview of exam status, live monitoring telemetry, and critical alerts</p>
                  </div>

                  {/* STATS HEROES */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="p-4 bg-[#141829] border border-[#212942] rounded-2xl">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs text-slate-400">Published MCQ Pool</span>
                        <BookOpen className="w-5 h-5 text-indigo-400" />
                      </div>
                      <h3 className="text-2xl font-bold text-white font-mono">{examData.questions.length} Questions</h3>
                      <p className="text-[10px] text-indigo-300 mt-1">Total Exam Marks: {examData.questions.reduce((a, b) => a + b.marks, 0)} pts</p>
                    </div>

                    <div className="p-4 bg-[#141829] border border-[#212942] rounded-2xl">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs text-slate-400">Pre-Registered Candidates</span>
                        <Users className="w-5 h-5 text-blue-400" />
                      </div>
                      <h3 className="text-2xl font-bold text-white font-mono">{candidates.length} Registered</h3>
                      <button
                        onClick={() => setTeacherActiveTab('candidates')}
                        className="text-[10px] text-blue-400 hover:underline flex items-center gap-0.5 mt-1 cursor-pointer"
                      >
                        <span>Manage Authorized list</span>
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>

                    <div className="p-4 bg-[#141829] border border-[#212942] rounded-2xl">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs text-slate-400">Testing Progress</span>
                        <Activity className="w-5 h-5 text-emerald-400" />
                      </div>
                      <h3 className="text-2xl font-bold text-white font-mono">
                        {candidates.filter(c => c.status === 'testing').length} Live
                      </h3>
                      <p className="text-[10px] text-emerald-300 mt-1">
                        {candidates.filter(c => c.status === 'submitted').length} Already Submitted
                      </p>
                    </div>

                    <div className="p-4 bg-[#141829] border border-[#212942] rounded-2xl">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs text-slate-400">Total Flagged Violations</span>
                        <ShieldAlert className="w-5 h-5 text-red-400" />
                      </div>
                      <h3 className="text-2xl font-bold text-red-400 font-mono">
                        {candidates.reduce((sum, current) => sum + current.violations, 0)} Flags
                      </h3>
                      <p className="text-[10px] text-red-300 mt-1">
                        {candidates.filter(c => c.status === 'terminated').length} Student Sessions Terminated
                      </p>
                    </div>
                  </div>

                  {/* ACTIVE TITLE AND CONFIGURATION STATUS */}
                  <div className="p-5 bg-gradient-to-r from-[#171a30] to-[#121629] border border-[#252f4c] rounded-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    <div>
                      <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest block mb-0.5">Title under Evaluation</span>
                      <h3 className="text-base font-bold text-white">{examData.title}</h3>
                      <div className="flex items-center gap-3 mt-1.5 text-xs text-slate-400">
                        <span className="flex items-center gap-1 text-slate-300 font-medium">
                          <Clock className="w-3.5 h-3.5 text-slate-400" /> {examData.duration} Mins Limit
                        </span>
                        <span>•</span>
                        <span>Published Questions: {examData.questions.length} MCQs</span>
                      </div>
                    </div>
                    <button
                      onClick={() => setTeacherActiveTab('questions')}
                      className="px-4.5 py-2 text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 rounded-xl text-white transition-all cursor-pointer flex items-center gap-1.5"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>Edit Master Questions</span>
                    </button>
                  </div>

                  {/* TWO GRAPH / LIVE COHORT GRID */}
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

                    {/* Active In-Progress Proctored List */}
                    <div className="bg-[#141829] border border-[#212942] rounded-2xl p-5 lg:col-span-2 space-y-4">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-bold text-white">Proctored Candidate Cohort Spectrum</h4>
                        <span className="text-[10px] text-slate-400 font-mono">Real-time update active</span>
                      </div>

                      <div className="divide-y divide-[#20273d] max-h-96 overflow-y-auto pr-1">
                        {candidates.length === 0 ? (
                          <div className="py-8 text-center text-slate-500 text-xs">
                            No candidates enrolled. Register them in Candidate Credentials tab to allow access.
                          </div>
                        ) : (
                          candidates.map(candidate => (
                            <div key={candidate.id} className="py-3 flex flex-wrap items-center justify-between gap-3 first:pt-0 last:pb-0">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center font-bold text-xs">
                                  {candidate.name.substring(0, 2).toUpperCase()}
                                </div>
                                <div>
                                  <div className="flex items-center gap-2">
                                    <span className="text-xs font-semibold text-slate-200">{candidate.name}</span>
                                    <span className="text-[10px] font-mono font-medium text-slate-400"> (Roll: {candidate.rollNumber})</span>
                                  </div>
                                  <div className="text-[10px] text-slate-400 mt-0.5">
                                    Registered: {new Date(candidate.registeredAt).toLocaleDateString()}
                                  </div>
                                </div>
                              </div>

                              <div className="flex items-center gap-3">
                                {/* State status badge */}
                                {candidate.status === 'idle' && (
                                  <span className="text-[10px] px-2 py-0.5 bg-slate-800 text-slate-400 border border-slate-700/50 rounded-full font-medium">Idle / Disconnected</span>
                                )}
                                {candidate.status === 'precheck' && (
                                  <span className="text-[10px] px-2 py-0.5 bg-amber-950/20 text-amber-400 border border-amber-900/30 rounded-full font-medium animate-pulse-slow">Completing Setup Check</span>
                                )}
                                {candidate.status === 'testing' && (
                                  <span className="text-[10px] px-2 py-0.5 bg-blue-950/40 text-blue-400 border border-blue-900/40 rounded-full font-semibold animate-pulse">Taking Exam • Answered {candidate.progress}/{examData.questions.length}</span>
                                )}
                                {candidate.status === 'submitted' && (
                                  <span className="text-[10px] px-2 py-0.5 bg-emerald-950/40 text-emerald-400 border border-emerald-900/40 rounded-full font-semibold">Completed (Score: {candidate.score} pts)</span>
                                )}
                                {candidate.status === 'terminated' && (
                                  <span className="text-[10px] px-2 py-0.5 bg-red-950/50 text-red-400 border border-red-900/50 rounded-full font-semibold">Flagged / LOCKED</span>
                                )}

                                {/* Violation badge mini */}
                                {candidate.violations > 0 && (
                                  <span className="text-[10px] px-2 py-0.5 bg-red-950/30 text-red-400 border border-red-900/20 rounded-lg font-bold">
                                    🚩 {candidate.violations} Flags
                                  </span>
                                )}

                                {/* Force action buttons */}
                                {candidate.status === 'testing' && (
                                  <button
                                    onClick={() => forceEndExam(candidate.id)}
                                    className="px-2 py-1 bg-red-950 text-red-400 hover:bg-red-900/60 transition-all rounded text-[10px] font-bold cursor-pointer"
                                  >
                                    End Session
                                  </button>
                                )}
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>

                    {/* Proctored Tab-out Violation Alerts Feed */}
                    <div className="bg-[#141829] border border-[#212942] rounded-2xl p-5 space-y-4">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-bold text-white">Live Proctor Logs</h4>
                        <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse"></span>
                      </div>

                      <div className="space-y-2.5 overflow-y-auto max-h-96 pr-1 font-mono text-[10px]">
                        {logs.length === 0 ? (
                          <div className="py-8 text-center text-slate-500">
                            No proctoring violation alerts logged yet.
                          </div>
                        ) : (
                          logs.map(log => (
                            <div key={log.id} className="p-2.5 bg-[#1b2137]/60 border border-[#252f4c] rounded-lg">
                              <div className="flex justify-between font-bold text-slate-300">
                                <span>{log.candidateName}</span>
                                <span className="text-[#4f8ef7]">{log.timestamp}</span>
                              </div>
                              <p className="text-red-400 mt-1">{log.message}</p>
                            </div>
                          ))
                        )}
                      </div>
                    </div>

                  </div>
                </div>
              )}

              {/* ─────────────────────────────────── */}
              {/* 4. CANDIDATES REGISTRATION SYSTEM  */}
              {/* ─────────────────────────────────── */}

              {currentUserRole === 'teacher' && teacherActiveTab === 'candidates' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-2xl font-bold tracking-tight text-white">Candidate credentials authorization management</h2>
                    <p className="text-xs text-slate-400 font-medium">To enforce security, candidates cannot attend the exam until their unique credentials (Name, Roll No &amp; Access Key) are authorized here.</p>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    
                    {/* ENROLL NEW CANDIDATE CARD */}
                    <div className="bg-[#141829] border border-[#212942] rounded-2xl p-5 space-y-4 shadow-sm h-fit">
                      <h4 className="text-sm font-bold text-white flex items-center gap-1.5 pb-2 border-b border-slate-800">
                        <Plus className="w-4 h-4 text-indigo-400" />
                        <span>Authorize New Candidate</span>
                      </h4>

                      <form onSubmit={enrollCandidate} className="space-y-4">
                        <div>
                          <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">Full Name</label>
                          <input
                            type="text"
                            placeholder="e.g. Alex Johnson"
                            value={newStudName}
                            onChange={e => setNewStudName(e.target.value)}
                            className="w-full bg-[#1b2136] text-white text-xs placeholder-slate-500 rounded-lg border border-[#2b3558] px-3.5 py-2.5 focus:outline-none focus:border-indigo-500 transition-colors"
                            required
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">Unique Roll Number ID</label>
                          <input
                            type="text"
                            placeholder="e.g. CS202601"
                            value={newStudRoll}
                            onChange={e => setNewStudRoll(e.target.value)}
                            className="w-full bg-[#1b2136] text-white text-xs placeholder-slate-500 rounded-lg border border-[#2b3558] px-3.5 py-2.5 focus:outline-none focus:border-indigo-500 transition-colors block uppercase"
                            required
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">Enrollment Exam / Suite</label>
                          <select
                            value={newCandidateTestId || selectedAdminTestId}
                            onChange={e => setNewCandidateTestId(e.target.value)}
                            className="w-full bg-[#1b2136] text-white text-xs rounded-lg border border-[#2b3558] px-3.5 py-2.5 focus:outline-none focus:border-indigo-500 cursor-pointer"
                          >
                            {exams.map(ex => (
                              <option key={ex.id} value={ex.id}>
                                {ex.title}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Access Code / Unique Key</label>
                            <button
                              type="button"
                              onClick={handlePickAutoCode}
                              className="text-[10px] text-blue-400 hover:underline cursor-pointer font-semibold"
                            >
                              Auto Generate
                            </button>
                          </div>
                          <input
                            type="text"
                            placeholder="Create custom or click auto generate"
                            value={newStudCode}
                            onChange={e => setNewStudCode(e.target.value)}
                            className="w-full bg-[#1b2136] text-white text-xs placeholder-slate-500 rounded-lg border border-[#2b3558] px-3.5 py-2.5 focus:outline-none focus:border-indigo-500 transition-colors uppercase"
                          />
                          <span className="text-[10px] text-slate-400 block mt-1">If blank, an authorized key like (PASS182) is randomized. Give this code to the student as their private exam passcode.</span>
                        </div>

                        <button
                          type="submit"
                          className="w-full py-2.5 bg-indigo-600 hover:bg-[#5851db] text-white font-semibold rounded-lg text-xs transition-all shadow shadow-indigo-900/35 cursor-pointer text-center"
                        >
                          Register Pre-Approved Candidate Credentials ✓
                        </button>
                      </form>
                    </div>

                    {/* CANDIDATES LISTING AND ACTIONS */}
                    <div className="bg-[#141829] border border-[#212942] rounded-2xl p-5 lg:col-span-2 space-y-4">
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-2.5 border-b border-[#20273c] gap-3">
                        <h4 className="text-sm font-bold text-white flex items-center gap-2">
                          <Users className="w-4.5 h-4.5 text-blue-400 animate-pulse" />
                          <span>Authorized Candidate Registry</span>
                        </h4>
                        
                        <div className="flex items-center gap-2 self-stretch sm:self-auto font-sans">
                          <span className="text-[9px] font-bold uppercase tracking-wider text-slate-500 font-mono">Exam Switch Filter:</span>
                          <select
                            value={candidateFilterId}
                            onChange={e => setCandidateFilterId(e.target.value)}
                            className="bg-[#1b2136] text-white text-[11px] rounded-lg border border-[#2b3558] px-2.5 py-1.5 focus:outline-none focus:border-indigo-500 cursor-pointer"
                          >
                            <option value="all">Showing All Exam Suites ({candidates.length})</option>
                            {exams.map(ex => (
                              <option key={ex.id} value={ex.id}>
                                {ex.title} ({candidates.filter(c => c.testId === ex.id).length})
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-xs text-slate-300">
                          <thead className="text-[10px] font-bold text-slate-400 uppercase bg-[#181d33]/55 border-b border-[#252f4c]">
                            <tr>
                              <th className="p-3">Candidate Reference</th>
                              <th className="p-3">Roll Number</th>
                              <th className="p-3">Assigned Exam Subject</th>
                              <th className="p-3">Required Key</th>
                              <th className="p-3">Exam Status</th>
                              <th className="p-3 text-center">Unenroll</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-[#20273d]">
                            {(() => {
                              const list = candidateFilterId === 'all' 
                                ? candidates 
                                : candidates.filter(c => c.testId === candidateFilterId);
                                
                              if (list.length === 0) {
                                return (
                                  <tr>
                                    <td colSpan={6} className="p-6 text-center text-slate-500">
                                      Registry is empty for this exam filter. Register candidate credentials to enable student exam participation.
                                    </td>
                                  </tr>
                                );
                              }
                              
                              return list.map(stud => (
                                <tr key={stud.id} className="hover:bg-slate-900/25 transition-all">
                                  <td className="p-3 text-white font-semibold flex items-center gap-2">
                                    <User className="w-3.5 h-3.5 text-slate-500" />
                                    <span>{stud.name}</span>
                                  </td>
                                  <td className="p-3 font-mono font-medium text-slate-400 uppercase">{stud.rollNumber}</td>
                                  <td className="p-3 text-indigo-300">
                                    <span className="font-semibold text-[11px] bg-indigo-950/45 px-2 py-1 rounded border border-indigo-900/25">
                                      {exams.find(ex => ex.id === stud.testId)?.title || stud.testId}
                                    </span>
                                  </td>
                                  <td className="p-3">
                                    <span className="px-2 py-0.5 bg-yellow-400/10 text-yellow-500 border border-yellow-500/10 rounded font-bold font-mono text-[11px] uppercase">
                                      {stud.accessCode}
                                    </span>
                                  </td>
                                  <td className="p-3">
                                    {stud.status === 'idle' && <span className="text-[10px] text-slate-400">• Disconnected</span>}
                                    {stud.status === 'precheck' && <span className="text-[10px] text-amber-400 font-semibold animate-pulse">• Setup Screen</span>}
                                    {stud.status === 'testing' && <span className="text-[10px] text-blue-400 font-bold animate-pulse">• Live testing ({stud.progress}Q)</span>}
                                    {stud.status === 'submitted' && <span className="text-[10px] text-green-400 font-bold">• Finished ({stud.score} pts)</span>}
                                    {stud.status === 'terminated' && <span className="text-[10px] text-red-500 font-semibold">• Flagged Locked</span>}
                                  </td>
                                  <td className="p-3 text-center">
                                    <button
                                      onClick={() => handleDeleteCandidate(stud.id)}
                                      className="p-1 px-1.5 text-red-500 hover:bg-red-950 hover:text-red-350 rounded transition-all cursor-pointer"
                                      title="Unregister Student Code"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </td>
                                </tr>
                              ));
                            })()}
                          </tbody>
                        </table>
                      </div>

                      <div className="p-3.5 bg-[#1b2137]/30 border border-[#252f4c] rounded-xl text-[10px] text-slate-400 leading-relaxed">
                        ⚠️ **Critical Enforcement Rule:** Candidates can only proceed past student sign-in if their typed Name, Roll No, and Access Key EXACTLY match one of the entries in this table. If they are not registered on this list, they are prohibited from accessing the system.
                      </div>
                    </div>

                  </div>
                </div>
              )}

              {/* ─────────────────────────────────── */}
              {/* 5. MASTER QUESTIONS & EXAM SETUP  */}
              {/* ─────────────────────────────────── */}

              {currentUserRole === 'teacher' && teacherActiveTab === 'questions' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-2xl font-bold tracking-tight text-white">Exam Room suites &amp; master MCQs</h2>
                    <p className="text-xs text-slate-400">Manage multiple subject exam suites and configure the live question pools. Saved updates immediately synchronize with active candidates.</p>
                  </div>

                  {/* EXAMS & SUBJECT SUITES MANAGER CARD */}
                  <div className="bg-[#141829] border border-[#212942] rounded-2xl p-5 space-y-4">
                    <div className="flex items-center justify-between pb-2 border-b border-[#20273d]">
                      <h3 className="text-sm font-bold text-white flex items-center gap-1.5 animate-pulse">
                        <FolderOpen className="w-4.5 h-4.5 text-blue-400" />
                        <span>Manage Exam Suites &amp; Subjects</span>
                      </h3>
                      <span className="text-[10px] font-mono text-indigo-400 font-bold px-2 py-0.5 bg-indigo-950/55 rounded border border-indigo-850">
                        {exams.length} SUITES AVAILABLE
                      </span>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                      {/* Create New Exam Suite Form */}
                      <form onSubmit={handleCreateExam} className="bg-[#0b0e17]/85 border border-[#1f263c] rounded-xl p-4 space-y-3.5">
                        <span className="text-[11px] font-bold text-slate-350 uppercase tracking-wider block font-mono">Register New Exam Suite</span>
                        <div>
                          <label className="block text-[10px] text-slate-400 font-semibold mb-1 uppercase tracking-wide">Subject / Exam Title</label>
                          <input
                            type="text"
                            placeholder="e.g. Grade 10 English"
                            value={newExamTitleInput}
                            onChange={e => setNewExamTitleInput(e.target.value)}
                            className="w-full bg-[#141829] text-white text-xs placeholder-slate-605 rounded-lg border border-[#232b45] px-3 py-2.5 focus:outline-none focus:border-indigo-500"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-slate-400 font-semibold mb-1 uppercase tracking-wide">Time Limit (Minutes)</label>
                          <input
                            type="number"
                            min={1}
                            placeholder="e.g. 30"
                            value={newExamDurationInput}
                            onChange={e => setNewExamDurationInput(Math.max(1, parseInt(e.target.value) || 15))}
                            className="w-full bg-[#141829] text-white text-xs placeholder-slate-605 rounded-lg border border-[#232b45] px-3 py-2.5 focus:outline-none focus:border-indigo-500"
                            required
                          />
                        </div>
                        <button
                          type="submit"
                          className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg text-xs transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>Create &amp; Open Exam Suite</span>
                        </button>
                      </form>

                      {/* Registered Rooms Toggle List Grid */}
                      <div className="lg:col-span-2 space-y-2">
                        <span className="text-[11px] font-bold text-slate-350 uppercase tracking-wider block font-mono">Registered Exam Suites (Click to Switch Active setup)</span>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-60 overflow-y-auto pr-1">
                          {exams.map(ex => {
                            const isSelected = ex.id === selectedAdminTestId;
                            return (
                              <div
                                key={ex.id}
                                onClick={() => setSelectedAdminTestId(ex.id)}
                                className={`p-4 rounded-xl border cursor-pointer transition-all flex flex-col justify-between relative group ${
                                  isSelected
                                    ? 'bg-blue-600/10 border-blue-500 text-white shadow shadow-blue-500/10'
                                    : 'bg-[#1b2137]/30 border-[#222a47] hover:border-slate-705 text-slate-300'
                                }`}
                              >
                                <div>
                                  <div className="flex justify-between items-start gap-2">
                                    <span className="font-bold text-xs truncate max-w-[85%]">{ex.title}</span>
                                    {exams.length > 1 && (
                                      <button
                                        type="button"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          handleDeleteExam(ex.id);
                                        }}
                                        className="text-slate-500 hover:text-red-400 p-1 rounded hover:bg-red-950/20 opacity-0 group-hover:opacity-100 transition-opacity"
                                        title="Delete Exam"
                                      >
                                        <Trash2 className="w-3.5 h-3.5" />
                                      </button>
                                    )}
                                  </div>
                                  <div className="flex gap-2 items-center text-[10px] text-slate-400 mt-2.5 font-mono">
                                    <span className="bg-slate-950 px-2 py-0.5 rounded text-indigo-300 border border-slate-800">
                                      {(ex.questions || []).length} MCQ{ex.questions?.length !== 1 ? 's' : ''}
                                    </span>
                                    <span className="bg-slate-950 px-2 py-0.5 rounded text-indigo-300 border border-slate-800">
                                      {ex.duration} Mins
                                    </span>
                                  </div>
                                </div>
                                {isSelected && (
                                  <span className="absolute bottom-2 right-2 text-[9px] text-emerald-450 font-mono font-black tracking-wider">
                                    ● ACTIVE SETUP
                                  </span>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Settings card */}
                  <div className="bg-[#141829] border border-[#212942] rounded-2xl p-5 space-y-4">
                    <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                      <Lock className="w-4 h-4 text-slate-400" />
                      <span>Exam Session Directives</span>
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">Exam Header Title</label>
                        <input
                          type="text"
                          value={examData.title}
                          onChange={e => setExamData({ ...examData, title: e.target.value })}
                          className="w-full bg-[#1b2136] text-white text-xs rounded-lg border border-[#2b3558] px-3.5 py-2.5 focus:outline-none focus:border-indigo-500"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">Time Limit Duration (Minutes)</label>
                        <input
                          type="number"
                          value={examData.duration}
                          onChange={e => setExamData({ ...examData, duration: Math.max(1, parseInt(e.target.value) || 1) })}
                          className="w-full bg-[#1b2136] text-white text-xs rounded-lg border border-[#2b3558] px-3.5 py-2.5 focus:outline-none focus:border-indigo-500"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Questions Builder list */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-slate-200">MCQ Series ({examData.questions.length} Items)</h3>
                      <button
                        onClick={() => {
                          const newQ: Question = {
                            id: `q-${Date.now()}`,
                            text: '',
                            options: ['', '', '', ''],
                            correct: 0,
                            marks: 2
                          };
                          setExamData({ ...examData, questions: [...examData.questions, newQ] });
                        }}
                        className="px-3.5 py-1.5 text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 rounded-lg text-white transition-all flex items-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add Question Card</span>
                      </button>
                    </div>

                    {examData.questions.length === 0 ? (
                      <div className="bg-[#141829] border border-[#212942] rounded-2xl p-8 text-center text-slate-400 text-xs">
                        No questions configured yet. Click "Add Question Card" above to build your examination questionnaire.
                      </div>
                    ) : (
                      examData.questions.map((q, qIndex) => (
                        <div key={q.id} className="bg-[#141829] border border-[#212942] rounded-2xl p-5 space-y-4 relative">
                          <button
                            onClick={() => {
                              const updated = examData.questions.filter((item, idx) => idx !== qIndex);
                              setExamData({ ...examData, questions: updated });
                            }}
                            className="absolute top-4 right-4 text-slate-500 hover:text-red-400 transition-colors cursor-pointer"
                            title="Remove Question"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>

                          <div className="flex items-center gap-3">
                            <span className="text-xs font-mono font-bold text-indigo-400 uppercase">Question #{qIndex + 1}</span>
                            <div className="flex items-center gap-1">
                              <span className="text-[11px] text-slate-400 font-medium">Marks:</span>
                              <input
                                type="number"
                                min={1}
                                max={20}
                                value={q.marks}
                                onChange={e => {
                                  const updated = examData.questions.map((item, idx) => {
                                    if (idx === qIndex) {
                                      return { ...item, marks: Math.max(1, parseInt(e.target.value) || 1) };
                                    }
                                    return item;
                                  });
                                  setExamData({ ...examData, questions: updated });
                                }}
                                className="w-12 bg-[#1b2136] text-white text-[11px] rounded border border-[#2b3558] px-1.5 py-0.5 text-center font-bold"
                              />
                            </div>
                          </div>

                          <div className="space-y-1">
                            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest">Question Text</label>
                            <textarea
                              value={q.text}
                              required
                              placeholder="Type your multiple choice question here..."
                              onChange={e => {
                                const updated = examData.questions.map((item, idx) => {
                                  if (idx === qIndex) {
                                    return { ...item, text: e.target.value };
                                  }
                                  return item;
                                });
                                setExamData({ ...examData, questions: updated });
                              }}
                              className="w-full bg-[#1b2136] text-white text-xs placeholder-slate-600 rounded-lg border border-[#2b3558] px-3.5 py-2 focus:outline-none min-h-16"
                            />
                          </div>

                          {/* OPTION ROWS (4 options) */}
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                            {q.options.map((opt, optIdx) => (
                              <div key={optIdx} className="flex items-center gap-2">
                                <span className="text-xs font-mono font-bold text-slate-500 w-4 shrink-0">
                                  {String.fromCharCode(65 + optIdx)}.
                                </span>
                                <input
                                  type="text"
                                  value={opt}
                                  required
                                  placeholder={`Option ${String.fromCharCode(65 + optIdx)}`}
                                  onChange={e => {
                                    const updated = examData.questions.map((item, idx) => {
                                      if (idx === qIndex) {
                                        const newOpts = [...item.options];
                                        newOpts[optIdx] = e.target.value;
                                        return { ...item, options: newOpts };
                                      }
                                      return item;
                                    });
                                    setExamData({ ...examData, questions: updated });
                                  }}
                                  className="flex-grow bg-[#1b2136] text-white text-xs rounded-lg border border-[#2b3558] px-3 py-2 focus:outline-none focus:border-indigo-400"
                                />
                                <button
                                  type="button"
                                  onClick={() => {
                                    const updated = examData.questions.map((item, idx) => {
                                      if (idx === qIndex) {
                                        return { ...item, correct: optIdx };
                                      }
                                      return item;
                                    });
                                    setExamData({ ...examData, questions: updated });
                                  }}
                                  className={`p-1.5 rounded-full border transition-all cursor-pointer ${
                                    q.correct === optIdx
                                      ? 'bg-emerald-600 text-white border-emerald-500'
                                      : 'border-[#2d3347] text-slate-500 hover:border-slate-400'
                                  }`}
                                  title="Mark as Correct Option"
                                >
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ))}
                          </div>

                          <div className="p-2 bg-[#121626] rounded-xl text-xs flex justify-between items-center text-slate-400">
                            <div>
                              <span>Published Answer Configured:</span>&nbsp;
                              <span className="font-semibold text-emerald-400 font-mono">
                                Option {String.fromCharCode(65 + q.correct)}
                                {q.options[q.correct] ? ` (${q.options[q.correct]})` : ''}
                              </span>
                            </div>
                            <span className="text-[10px] text-slate-500">Dual Sync Enabled</span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}

              {/* ─────────────────────────────────── */}
              {/* 6. PROCTOR LIVE SCANNER CABINET   */}
              {/* ─────────────────────────────────── */}

              {currentUserRole === 'teacher' && teacherActiveTab === 'monitor' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-2xl font-bold tracking-tight text-white">Live Proctor Video Scan Monitoring</h2>
                    <p className="text-xs text-slate-400">Simultaneous video streams, tab-focus indicators, and remote termination control</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {candidates.filter(c => c.status !== 'idle').length === 0 ? (
                      <div className="bg-[#141829] border border-[#212942] rounded-2xl p-10 text-center text-slate-400 text-xs col-span-3">
                        💤 No candidates are currently in pre-check or active testing sessions. Open a separate student gate screen to test.
                      </div>
                    ) : (
                      candidates.filter(c => c.status !== 'idle').map(candidate => {
                        const candExam = exams.find(e => e.id === candidate.testId) || examData;
                        const totalExamMarks = candExam.questions.reduce((a, b) => a + b.marks, 0) || 1;
                        const scorePcnt = Math.round((candidate.score / totalExamMarks) * 100);
                        return (
                          <div key={candidate.id} className="bg-[#141829] border border-[#212942] rounded-2xl overflow-hidden shadow-lg flex flex-col">
                            
                            {/* Feed Header */}
                            <div className="p-4 bg-[#191e33] border-b border-slate-800 flex items-center justify-between">
                              <div>
                                <span className="text-[10px] font-mono text-slate-400 uppercase">Proctored Session</span>
                                <h4 className="text-sm font-bold text-white truncate">{candidate.name}</h4>
                              </div>
                              <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                                candidate.status === 'terminated' 
                                  ? 'bg-red-950 text-red-400 hover:bg-red-900/60' 
                                  : candidate.status === 'submitted'
                                    ? 'bg-green-950 text-green-400 border border-green-900/30'
                                    : 'bg-blue-950 text-blue-400 animate-pulse border border-blue-900/30'
                              }`}>
                                {candidate.status === 'terminated' ? 'Flagged Lock' : candidate.status}
                              </span>
                            </div>

                            {/* Camera Feed Simulator Canvas */}
                            <div className="aspect-video bg-black relative flex items-center justify-center p-2 text-center text-xs">
                              {/* Actual Webcam preview if authorized or received from Firestore */}
                              {candidate.liveFeed ? (
                                <div className="absolute inset-0 w-full h-full">
                                  <img 
                                    src={candidate.liveFeed} 
                                    alt={`${candidate.name} surveillance feed`}
                                    className="w-full h-full object-cover" 
                                    referrerPolicy="no-referrer"
                                  />
                                  <div className="absolute top-2 left-2 px-1.5 py-0.5 bg-red-600 text-white font-mono text-[9px] font-bold rounded flex items-center gap-1 uppercase select-none">
                                    <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse"></span>
                                    <span>LIVE PROCTOR CAM</span>
                                  </div>
                                </div>
                              ) : webcamStream && candidate.status === 'testing' ? (
                                <div className="absolute inset-0 w-full h-full">
                                  {/* Dummy video element just running webcam stream */}
                                  <video 
                                    className="w-full h-full object-cover" 
                                    autoPlay 
                                    muted 
                                    ref={el => {
                                      if (el && !el.srcObject) {
                                        el.srcObject = webcamStream;
                                      }
                                    }}
                                  />
                                  <div className="absolute top-2 left-2 px-1.5 py-0.5 bg-red-600 text-white font-mono text-[9px] font-bold rounded flex items-center gap-1 uppercase text-left select-none">
                                    <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping"></span>
                                    <span>LIVE WEBCAM STREAM</span>
                                  </div>
                                </div>
                              ) : (
                                <div className="space-y-1 text-[#4f8ef7] p-4 flex flex-col items-center">
                                  <div className="p-2.5 bg-[#4f8ef7]/10 rounded-full mb-1">
                                    <Camera className="w-5 h-5" />
                                  </div>
                                  <span className="font-semibold text-[11px] text-slate-300 block">Cam Feed Active (Simulated)</span>
                                  <span className="text-[10px] text-slate-500 font-mono">Continuous AI gaze tracking analysis OK</span>
                                </div>
                              )}

                              {/* Overlay for submitted */}
                              {candidate.status === 'submitted' && (
                                <div className="absolute inset-0 bg-emerald-950/80 backdrop-blur-xs flex flex-col items-center justify-center p-4">
                                  <CheckCircle2 className="w-8 h-8 text-emerald-400 mb-1" />
                                  <span className="font-bold text-white">Session Concluded</span>
                                  <span className="text-[10px] text-emerald-300 mt-1 font-mono">Score: {candidate.score} pts ({scorePcnt || 0}%)</span>
                                </div>
                              )}

                              {/* Overlay for terminated */}
                              {candidate.status === 'terminated' && (
                                <div className="absolute inset-0 bg-red-950/90 backdrop-blur-xs flex flex-col items-center justify-center p-4">
                                  <AlertCircle className="w-8 h-8 text-red-500 mb-1" />
                                  <span className="font-bold text-white">Session TERMINATED</span>
                                  <span className="text-[10px] text-red-300 mt-1">Gaze violations exceeded ceiling limit</span>
                                </div>
                              )}
                            </div>

                            {/* Feed Stats Metrics */}
                            <div className="p-4 space-y-3.5 flex-grow">
                              <div className="grid grid-cols-2 gap-2 text-center text-xs">
                                <div className="p-2 bg-[#1b2137]/30 border border-[#252f4c] rounded-xl">
                                  {candidate.status === 'idle' || candidate.status === 'precheck' ? (
                                    <span className="text-slate-400 font-mono block">Setup</span>
                                  ) : (
                                    <span className="text-white font-bold font-mono block">{candidate.progress} / {candExam.questions.length}</span>
                                  )}
                                  <span className="text-[9px] text-slate-400">Answer Progress</span>
                                </div>
                                <div className="p-2 bg-[#1b2137]/30 border border-[#252f4c] rounded-xl">
                                  <span className={`font-bold font-mono block ${candidate.violations > 0 ? 'text-red-400 animate-pulse' : 'text-slate-400'}`}>
                                    {candidate.violations}
                                  </span>
                                  <span className="text-[9px] text-slate-400">Gaze Warnings</span>
                                </div>
                              </div>

                              <div>
                                <div className="flex justify-between items-center text-[10px] text-slate-400 mb-1">
                                  <span>Gaze tracker vector accuracy</span>
                                  <span className="text-[#34d399] font-mono">98.4% OK</span>
                                </div>
                                <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                  <div className="h-full bg-emerald-500 rounded-full w-[98.4%]"></div>
                                </div>
                              </div>

                              {candidate.status === 'testing' && (
                                <button
                                  onClick={() => forceEndExam(candidate.id)}
                                  className="w-full py-2 bg-gradient-to-r from-red-900 to-red-650 hover:from-red-800 hover:to-red-550 text-white font-semibold rounded-lg text-xs tracking-tight transition-all cursor-pointer"
                                >
                                  Instantly Force Terminate Exam ⛔
                                </button>
                              )}
                            </div>

                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              )}

              {/* ─────────────────────────────────── */}
              {/* 7. TEACHER RESULTS GRADING SHEET  */}
              {/* ─────────────────────────────────── */}

              {currentUserRole === 'teacher' && teacherActiveTab === 'results' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-2xl font-bold tracking-tight text-white">Grading &amp; evaluations registry</h2>
                    <p className="text-xs text-slate-400">Access submitted tests, view scoring percentages, and review specific questionnaire answers</p>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    
                    {/* SCORES SUMMARY MATRIX CARD */}
                    <div className="bg-[#141829] border border-[#212942] rounded-2xl p-5 lg:col-span-1 space-y-4 h-fit">
                      <h4 className="text-sm font-bold text-white flex items-center gap-1.5 pb-2 border-b border-slate-800">
                        <Award className="w-4.5 h-4.5 text-blue-400" />
                        <span>Select Candidate to Audit</span>
                      </h4>

                      <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
                        {candidates.filter(c => c.status === 'submitted' || c.status === 'terminated').length === 0 ? (
                          <div className="py-8 text-center text-slate-500 text-xs leading-relaxed">
                            No submissions recorded yet. Once a registered student completes an exam, their detailed scorecard will register here.
                          </div>
                        ) : (
                          candidates.filter(c => c.status === 'submitted' || c.status === 'terminated').map(stud => {
                            const studExam = exams.find(e => e.id === stud.testId) || examData;
                            const totalExamMarks = studExam.questions.reduce((a, b) => a + b.marks, 0) || 1;
                            const percent = Math.round((stud.score / totalExamMarks) * 100);
                            return (
                              <button
                                key={stud.id}
                                onClick={() => setSelectedReviewCandidate(stud)}
                                className={`w-full text-left p-3.5 rounded-xl border transition-all cursor-pointer block ${
                                  selectedReviewCandidate?.id === stud.id
                                    ? 'bg-blue-600/10 border-blue-500/50 text-white shadow shadow-blue-500/10'
                                    : 'bg-[#1b2137]/30 border-[#222a47] hover:border-slate-700 text-slate-300'
                                }`}
                              >
                                <div className="flex justify-between items-center font-bold mb-1">
                                  <span className="truncate">{stud.name}</span>
                                  {stud.status === 'terminated' ? (
                                    <span className="text-[9px] px-1.5 py-0.5 bg-red-950 text-red-400 rounded">TERMINATED</span>
                                  ) : (
                                    <span className="text-emerald-400 font-mono text-xs font-semibold">{percent}% ({stud.score} pts)</span>
                                  )}
                                </div>
                                <div className="text-[10px] text-slate-400 flex justify-between">
                                  <span>Roll No: {stud.rollNumber}</span>
                                  <span>Time: {stud.submitTime}</span>
                                </div>
                              </button>
                            );
                          })
                        )}
                      </div>
                    </div>

                    {/* SCORE AUDIT REVIEW CARD */}
                    <div className="bg-[#141829] border border-[#212942] rounded-2xl p-5 lg:col-span-2 space-y-4">
                      {selectedReviewCandidate ? (
                        <div className="space-y-5">
                          <div className="flex justify-between items-start pb-2 border-b border-[#20273d]">
                            <div>
                              <span className="text-[10px] font-bold text-blue-400 uppercase tracking-widest block">Audit Review Details</span>
                              <h3 className="text-lg font-bold text-white">{selectedReviewCandidate.name}</h3>
                              <p className="text-[11px] text-slate-400 font-medium">Roll Reference: {selectedReviewCandidate.rollNumber}</p>
                            </div>
                            <div className="text-right">
                              <span className="text-2xl font-black font-mono text-emerald-400">
                                {selectedReviewCandidate.score} / {(exams.find(e => e.id === selectedReviewCandidate.testId) || examData).questions.reduce((a, b) => a + b.marks, 0)}
                              </span>
                              <span className="text-xs text-slate-400 block">Total Marks scored</span>
                            </div>
                          </div>

                          <div className="p-3.5 bg-slate-900/40 border border-slate-800 rounded-xl space-y-2">
                            <h4 className="text-xs font-bold text-slate-300 uppercase">Proctor Integrity Report:</h4>
                            <div className="grid grid-cols-2 gap-3 text-xs">
                              <div className="p-2 bg-[#1b2137]/30 border border-[#252f4c] rounded-lg">
                                <span className="block font-bold mt-0.5">{selectedReviewCandidate.violations} Warnings</span>
                                <span className="text-[9px] text-slate-400">Tab-out/gaze warnings logged</span>
                              </div>
                              <div className="p-2 bg-[#1b2137]/30 border border-[#252f4c] rounded-lg">
                                <span className="block font-bold mt-0.5">{selectedReviewCandidate.submitTime || 'Unknown'}</span>
                                <span className="text-[9px] text-slate-400">Submission Timestamp</span>
                              </div>
                            </div>
                          </div>

                          {/* Question breakdown map */}
                          <div className="space-y-3">
                            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Question-by-Question Response Audit</h4>
                            {(exams.find(e => e.id === selectedReviewCandidate.testId) || examData).questions.map((q, idx) => {
                              const ansIndex = selectedReviewCandidate.answers[q.id];
                              const isCorrect = ansIndex === q.correct;
                              return (
                                <div key={q.id} className={`p-4 rounded-xl border ${isCorrect ? 'bg-emerald-950/10 border-emerald-900/35 text-emerald-100' : 'bg-red-950/10 border-red-900/35 text-red-100'}`}>
                                  <div className="flex justify-between font-bold text-xs mb-1.5">
                                    <span>Q{idx + 1}: {q.text}</span>
                                    <span className="font-mono text-[10px]">({q.marks} Marks)</span>
                                  </div>
                                  
                                  <div className="space-y-1 text-xs">
                                    <p>
                                      <span className="text-slate-400 font-semibold text-[10px]">Student Answer:</span>&nbsp;
                                      <span className={isCorrect ? 'text-emerald-400 font-bold' : 'text-red-400 font-bold'}>
                                        {ansIndex !== undefined ? `${String.fromCharCode(65 + ansIndex)}. ${q.options[ansIndex]}` : 'NO ANSWER'}
                                      </span>
                                    </p>
                                    {!isCorrect && (
                                      <p>
                                        <span className="text-slate-400 font-bold text-[10px]">Correct Answer:</span>&nbsp;
                                        <span className="text-emerald-400 font-semibold">{String.fromCharCode(65 + q.correct)}. {q.options[q.correct]}</span>
                                      </p>
                                    )}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      ) : (
                        <div className="py-24 text-center text-slate-500 text-xs">
                          👈 Select an evaluated candidate form the left registry sidebar to load their grading sheets.
                        </div>
                      )}
                    </div>

                  </div>
                </div>
              )}

              {/* ─────────────────────────────────── */}
              {/* 8. STUDENT PRE-CHECK REQUIREMENTS     */}
              {/* ─────────────────────────────────── */}

              {currentUserRole === 'student' && studentActiveTab === 'precheck' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-2xl font-bold tracking-tight text-white font-sans">Mandatory System Pre-Check</h2>
                    <p className="text-xs text-slate-400">Confirm your proctor webcam, microphone, and internet connection before starting the examination gate.</p>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    
                    {/* Hardware testing box */}
                    <div className="bg-[#141829] border border-[#212942] rounded-2xl p-5 space-y-4">
                      <h4 className="text-sm font-bold text-white flex items-center gap-1.5 pb-2 border-b border-slate-800">
                        <Camera className="w-4 h-4 text-indigo-400" />
                        <span>Webcam Proctor Monitor</span>
                      </h4>

                      <div className="aspect-video bg-black rounded-xl overflow-hidden relative flex items-center justify-center p-2 text-center text-xs">
                        {webcamStream ? (
                          <video 
                            ref={el => {
                              studentVideoRef.current = el;
                              if (el && webcamStream && el.srcObject !== webcamStream) {
                                el.srcObject = webcamStream;
                              }
                            }}
                            autoPlay 
                            muted 
                            playsInline 
                            className="w-full h-full object-cover" 
                          />
                        ) : (
                          <div className="text-slate-500 space-y-1 p-4">
                            <span className="text-3xl block mb-2">📷</span>
                            <span className="font-semibold text-slate-300">Camera Feed Idle</span>
                            <span className="text-[10px] text-slate-600 block">Click the authorization trigger below</span>
                          </div>
                        )}
                      </div>

                      <button
                        onClick={requestMediaAccess}
                        className={`w-full py-2.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                          camAuthorized 
                            ? 'bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-505/20' 
                            : 'bg-[#4f8ef7] hover:bg-[#3d7ae6] text-white'
                        }`}
                      >
                        {camAuthorized ? '🎥 Media Authorization Granted ✓' : '🎥 Authorize Camera & Microphone'}
                      </button>
                    </div>

                    {/* Pre-check tasks parameters checklist */}
                    <div className="bg-[#141829] border border-[#212942] rounded-2xl p-5 lg:col-span-2 space-y-5">
                      <h4 className="text-sm font-bold text-white flex items-center gap-1.5 pb-1 border-b border-slate-800">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span>Connectivity &amp; Integrity Vector Check</span>
                      </h4>

                      <div className="space-y-4 text-xs font-medium">
                        
                        {/* 1. Camera validation row */}
                        <div className="p-3 bg-[#1b2137]/30 border border-[#222b44] rounded-xl flex justify-between items-center">
                          <div className="flex items-center gap-2.5">
                            <div className={`p-1.5 rounded-full ${camAuthorized ? 'bg-emerald-500/10 text-emerald-400' : 'bg-yellow-400/10 text-yellow-500'}`}>
                              <Camera className="w-4.5 h-4.5" />
                            </div>
                            <div>
                              <span>Webcam Diagnostic</span>
                              <span className="text-[10px] text-slate-400 block mt-0.5">Continuous proctoring surveillance authorization</span>
                            </div>
                          </div>
                          <span className={`text-[10px] px-2.5 py-0.5 font-bold uppercase rounded ${camAuthorized ? 'bg-emerald-950 text-emerald-400' : 'bg-yellow-950 text-yellow-500'}`}>
                            {camAuthorized ? 'PASSED ✓' : 'REQUIRED'}
                          </span>
                        </div>

                        {/* 2. Microphones validation row */}
                        <div className="p-3 bg-[#1b2137]/30 border border-[#222b44] rounded-xl flex justify-between items-center">
                          <div className="flex items-center gap-2.5">
                            <div className={`p-1.5 rounded-full ${micAuthorized ? 'bg-emerald-500/10 text-emerald-400' : 'bg-yellow-400/10 text-yellow-500'}`}>
                              <CheckCircle2 className="w-4.5 h-4.5" />
                            </div>
                            <div>
                              <span>Microphone Diagnostic</span>
                              <span className="text-[10px] text-slate-400 block mt-0.5">Background audio scan diagnostic</span>
                            </div>
                          </div>
                          <span className={`text-[10px] px-2.5 py-0.5 font-bold uppercase rounded ${micAuthorized ? 'bg-emerald-950 text-emerald-400' : 'bg-yellow-950 text-yellow-500'}`}>
                            {micAuthorized ? 'PASSED ✓' : 'REQUIRED'}
                          </span>
                        </div>

                        {/* 3. Internet diagnostic speed test */}
                        <div className="p-3.5 bg-[#1b2137]/30 border border-[#222b44] rounded-xl space-y-3.5">
                          <div className="flex justify-between items-center">
                            <div className="flex items-center gap-2.5">
                              <div className={`p-1.5 rounded-full ${speedTestResult ? 'bg-emerald-500/10 text-emerald-400' : 'bg-yellow-400/10 text-yellow-500'}`}>
                                <Wifi className="w-4.5 h-4.5" />
                              </div>
                              <div>
                                <span>Internet Speed Diagnostic</span>
                                <span className="text-[10px] text-slate-400 block mt-0.5">Ensures no connection drops during final submission</span>
                              </div>
                            </div>
                            <button
                              onClick={handleRunSpeedTest}
                              disabled={speedTesting}
                              className="px-3 py-1.5 bg-[#252c4a] hover:bg-[#2f3961] text-indigo-300 font-semibold rounded-lg text-[10px] border border-[#3e4a80]/50 transition-all cursor-pointer"
                            >
                              {speedTesting ? 'Testing...' : 'Run Diagnostics'}
                            </button>
                          </div>

                          {speedTestResult !== null && (
                            <div className="space-y-3 mt-2 bg-slate-950/40 p-3.5 border border-slate-800/60 rounded-xl">
                              <div className="grid grid-cols-3 gap-2.5 text-center text-[10px] font-mono">
                                <div className="p-2 bg-slate-900 border border-slate-800/80 rounded-lg">
                                  <span className="text-slate-500 block uppercase tracking-wide">Download Speed</span>
                                  <span className="text-emerald-400 font-bold block text-xs mt-0.5">{speedTestResult} MB/s</span>
                                </div>
                                <div className="p-2 bg-slate-900 border border-slate-800/80 rounded-lg">
                                  <span className="text-slate-500 block uppercase tracking-wide">Network Latency</span>
                                  <span className="text-blue-400 font-bold block text-xs mt-0.5">{speedTestRTT !== null ? `${speedTestRTT} ms` : '--'}</span>
                                </div>
                                <div className="p-2 bg-slate-900 border border-slate-800/80 rounded-lg">
                                  <span className="text-slate-500 block uppercase tracking-wide">Jitter Drift</span>
                                  <span className="text-indigo-400 font-bold block text-xs mt-0.5">{speedTestJitter !== null ? `${speedTestJitter} ms` : '--'}</span>
                                </div>
                              </div>

                              <div className="space-y-1">
                                <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                                  <span>BANDWIDTH VECTOR DIAGNOSIS</span>
                                  <span className={`font-bold ${speedTestResult >= 0.25 ? 'text-emerald-400' : 'text-rose-400'}`}>
                                    {speedTestResult >= 0.25 ? 'OPTIMAL CAP ✓' : 'LIMITED BANDWIDTH ⚠️'}
                                  </span>
                                </div>
                                <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                  <div 
                                    className={`h-full rounded-full transition-all duration-300 ${speedTestResult >= 0.25 ? 'bg-emerald-500' : 'bg-rose-500'}`} 
                                    style={{ width: `${Math.min(100, (speedTestResult / 2.0) * 100)}%` }}
                                  ></div>
                                </div>
                                <div className="flex justify-between text-[9px] text-slate-500 font-mono">
                                  <span>MIN REQUIRED: 0.25 MB/s</span>
                                  <span>MAX COGNITIVE CAP: 2.00 MB/s</span>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>

                      </div>

                      {/* Ready status confirmation banner banner */}
                      {camAuthorized && micAuthorized && speedTestResult && speedTestResult >= 0.25 ? (
                        <div className="p-4 bg-emerald-950/20 border border-emerald-900/40 rounded-xl space-y-3">
                          <div>
                            <h5 className="font-bold text-emerald-400 text-sm">✓ All System Vectors Verified!</h5>
                            <p className="text-[11px] text-slate-300 leading-relaxed mt-0.5">Your evaluation environment has been cleared. Tap-out visibility logging is active. Do NOT minimize your tab.</p>
                          </div>
                          <button
                            onClick={handleStartActiveTest}
                            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 rounded-lg text-white font-semibold text-xs transition-all shadow-md mt-1 cursor-pointer"
                          >
                            Enter Active Examination Pool →
                          </button>
                        </div>
                      ) : (
                        <div className="p-4 bg-red-950/20 border border-red-900/40 rounded-xl">
                          <p className="text-[11px] text-red-300 leading-relaxed">⚠️ **Locked:** You cannot access the examination window until you authorize camera/microphone sensors and run your internet speed latency test.</p>
                        </div>
                      )}
                    </div>

                  </div>
                </div>
              )}

              {/* ─────────────────────────────────── */}
              {/* 9. STUDENT EXAM TERMINAL LAYOUT    */}
              {/* ─────────────────────────────────── */}

              {currentUserRole === 'student' && studentActiveTab === 'exam' && loggedStudent && (
                <div className="space-y-6">
                  
                  {/* Warning dialog overlay inside examination panel */}
                  {warningModal.isOpen && (
                    <div className="fixed inset-0 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 z-50">
                      <div className="bg-[#141829] border border-[#2b3558] rounded-2xl p-6 max-w-sm w-full text-center space-y-4">
                        <div className={`p-3 inline-block rounded-full ${
                          warningModal.severity === 'danger' ? 'bg-red-500/10 text-red-500' : 'bg-yellow-500/10 text-yellow-500'
                        }`}>
                          <AlertTriangle className="w-8 h-8" />
                        </div>
                        <h3 className="text-base font-bold text-white">{warningModal.title}</h3>
                        <p className="text-xs text-slate-400 leading-relaxed">{warningModal.message}</p>
                        <button
                          onClick={() => {
                            if (loggedStudent.status === 'terminated') {
                              logout();
                            } else {
                              setWarningModal({ ...warningModal, isOpen: false });
                            }
                          }}
                          className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg text-xs transition-all cursor-pointer"
                        >
                          I Understand &amp; Agree
                        </button>
                      </div>
                    </div>
                  )}

                  {loggedStudent.status === 'terminated' ? (
                    <div className="p-8 text-center bg-red-950/20 border border-red-900/40 rounded-2xl py-12 space-y-4">
                      <div className="p-4 inline-block rounded-full bg-red-500/10 text-red-500">
                        <AlertCircle className="w-12 h-12 animate-bounce" />
                      </div>
                      <h2 className="text-xl font-bold text-red-400 font-sans">Exam Force Terminated🔒</h2>
                      <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">Your unique exam session was flagged due to continuous tab-switching or manual supervisor action. Your completed answers have been discarded.</p>
                      <button
                        onClick={logout}
                        className="px-6 py-2.5 bg-[#1e2335] hover:bg-[#2a314a] rounded-xl text-slate-300 font-semibold text-xs border border-[#303a5c]/50 cursor-pointer"
                      >
                        Exit to Gateway
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      
                      {/* Live countdown widget bar */}
                      <div className="p-4 bg-[#141829] border border-[#212942] rounded-2xl flex flex-wrap justify-between items-center gap-3 shadow-md">
                        <div>
                          <span className="text-[10px] text-slate-400 block uppercase font-mono tracking-wider">Evaluation Objective</span>
                          <h3 className="text-sm font-bold text-white">{examData.title}</h3>
                        </div>

                        {/* TIMER */}
                        <div className="flex items-center gap-4">
                          <div className={`p-2.5 px-4 rounded-xl border flex items-center gap-2.5 ${timeLeft < 120 ? 'bg-red-950/20 border-red-500/30 text-red-400' : 'bg-slate-900/40 border-slate-800 text-yellow-400'}`}>
                            <Clock className="w-4 h-4" />
                            <span className="font-mono text-sm font-extrabold tracking-widest text-[#f59e0b]">
                              {Math.floor(timeLeft / 60).toString().padStart(2, '0')}:{(timeLeft % 60).toString().padStart(2, '0')}
                            </span>
                          </div>

                          <button
                            onClick={() => {
                              if (window.confirm('Do you confirm you are ready to finalize and submit?')) {
                                triggerGradeSubmission();
                              }
                            }}
                            className="px-4.5 py-2.5 bg-[#4f8ef7] hover:bg-[#3d7be2] rounded-xl text-white font-semibold text-xs transition-all shadow-md cursor-pointer"
                          >
                            Finalize MCQ submission
                          </button>
                        </div>
                      </div>

                      {/* QUESTIONNAIRE PROGRESS FILL */}
                      <div className="space-y-1">
                        <div className="flex justify-between text-[11px] text-slate-400 font-semibold font-mono">
                          <span>MCQ Completion status</span>
                          <span>{Object.keys(studentAnswers).length} of {examData.questions.length} Answered</span>
                        </div>
                        <div className="h-2 bg-slate-900 border border-slate-800/60 rounded-full overflow-hidden">
                          <div className="h-full bg bg-gradient-to-r from-blue-600 to-indigo-600 transition-all duration-300" style={{ width: `${(Object.keys(studentAnswers).length / examData.questions.length) * 100}%` }}></div>
                        </div>
                      </div>

                      {/* RENDERING DYNAMIC QUESTIONS COHORT */}
                      <div className="space-y-6">
                        {examData.questions.length === 0 ? (
                          <div className="py-12 bg-[#141829] rounded-2xl text-center text-slate-500 text-xs">
                            No examination questions configured by evaluator yet.
                          </div>
                        ) : (
                          examData.questions.map((q, idx) => {
                            const isAnswered = studentAnswers[q.id] !== undefined;
                            return (
                              <div key={q.id} className={`p-5 rounded-2xl border transition-all ${isAnswered ? 'bg-[#15192c] border-[#293664] shadow shadow-indigo-950/20' : 'bg-[#141a29]/60 border-[#1f2742]'}`}>
                                <div className="flex justify-between items-start mb-3.5">
                                  <span className="text-[10px] font-bold font-mono text-indigo-400 tracking-wider uppercase bg-[#202747]/60 border border-[#2f3964]/55 px-2 py-0.5 rounded">
                                    Question {idx + 1} of {examData.questions.length}
                                  </span>
                                  <span className="text-xs text-slate-400 font-mono">({q.marks} Pts Assignment)</span>
                                </div>

                                <p className="text-sm font-semibold text-slate-200 mb-4 tracking-tight leading-relaxed">{q.text}</p>

                                {/* Options list block */}
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                  {q.options.map((opt, optIndex) => {
                                    const isChosen = studentAnswers[q.id] === optIndex;
                                    return (
                                      <button
                                        key={optIndex}
                                        type="button"
                                        onClick={() => handleSelectOption(q.id, optIndex)}
                                        className={`w-full text-left p-3.5 rounded-xl border flex items-center gap-3 transition-colors text-xs font-semibold cursor-pointer ${
                                          isChosen
                                            ? 'bg-blue-600/10 border-blue-500/70 text-blue-300 shadow shadow-blue-500/10'
                                            : 'bg-[#121626]/40 border-[#232a42]/55 hover:border-slate-700 text-slate-400 hover:text-slate-300'
                                        }`}
                                      >
                                        <div className={`w-5 h-5 rounded-full border flex items-center justify-center font-bold font-mono text-[10px] ${
                                          isChosen ? 'bg-blue-600 text-white border-blue-500' : 'border-[#2d3347] text-slate-500'
                                        }`}>
                                          {String.fromCharCode(65 + optIndex)}
                                        </div>
                                        <span>{opt}</span>
                                      </button>
                                    );
                                  })}
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>

                      {/* Footer Final action wrapper */}
                      <div className="flex justify-end pt-4 mb-8">
                        <button
                          onClick={() => {
                            if (window.confirm('Do you confirm you have completed all questions and are ready to finalize?')) {
                              triggerGradeSubmission();
                            }
                          }}
                          className="px-6 py-3 bg-[#22c55e] hover:bg-[#1ebd54] text-white font-bold rounded-xl text-xs transition-shadow shadow duration-200 cursor-pointer"
                        >
                          I am Ready - Submit Evaluated Exam Cards ✓
                        </button>
                      </div>

                    </div>
                  )}

                </div>
              )}

              {/* ─────────────────────────────────── */}
              {/* 10. STUDENT COMPLETED RESULTS CARD */}
              {/* ─────────────────────────────────── */}

              {currentUserRole === 'student' && studentActiveTab === 'results' && loggedStudent && (
                <div className="space-y-6">
                  
                  <div className="p-6 bg-[#141829] border border-[#212942] rounded-2xl text-center space-y-4 shadow-lg">
                    
                    {loggedStudent.status === 'terminated' ? (
                      <div className="space-y-4">
                        <div className="w-16 h-16 bg-red-500/10 text-red-500 rounded-full flex items-center justify-center mx-auto">
                          <ShieldAlert className="w-8 h-8" />
                        </div>
                        <h2 className="text-xl font-bold text-red-400">Exam Termination Registered Locked</h2>
                        <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
                          Your examination session was forcefully closed due to proctor violations. No marks were tallied. Please contact Prof. Vishvajit regarding your incident timeline.
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-5">
                        <div className="w-16 h-16 bg-emerald-500/10 text-emerald-400 rounded-full flex items-center justify-center mx-auto">
                          <CheckCircle2 className="w-8 h-8" />
                        </div>
                        
                        <div>
                          <span className="text-[10px] text-emerald-400 uppercase font-mono tracking-widest font-bold">Exam Answer Card submitted</span>
                          <h2 className="text-lg font-bold text-white mt-1">{examData.title}</h2>
                          <div className="mt-4 inline-block px-6 py-2.5 bg-slate-900 border border-slate-800 rounded-xl">
                            <span className="text-[10px] text-slate-500 block uppercase font-mono mb-1">Your Performance Metric</span>
                            <span className="text-2xl font-black font-mono text-[#22c55e]">
                              {loggedStudent.score} / {examData.questions.reduce((a, b) => a + b.marks, 0)} pts
                            </span>
                            <span className="text-xs text-slate-400 block mt-1">
                              ({Math.round((loggedStudent.score / examData.questions.reduce((a, b) => a + b.marks, 0)) * 100)}% Grade ratio)
                            </span>
                          </div>
                        </div>

                        <div className="max-w-md mx-auto text-xs text-slate-400 leading-relaxed border-t border-[#1e253a] pt-4">
                          🔒 This assessment is proctored. Thorough correctness answers analysis is locked in local browser session memory for security.
                        </div>
                      </div>
                    )}
                  </div>

                  {loggedStudent.status === 'submitted' && (
                    <div className="bg-[#141829] border border-[#212942] rounded-2xl p-5 space-y-4">
                      <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Submitted MCQ Card Index</h4>
                      
                      <div className="space-y-3.5 text-xs">
                        {examData.questions.map((q, index) => {
                          const chosenIdx = loggedStudent.answers[q.id];
                          const ok = chosenIdx === q.correct;
                          return (
                            <div key={q.id} className={`p-3.5 rounded-xl border flex items-start gap-3 ${ok ? 'bg-emerald-950/10 border-emerald-900/30' : 'bg-red-950/10 border-red-900/30'}`}>
                              <span className="text-sm shrink-0 mt-0.5">{ok ? '✅' : '❌'}</span>
                              <div>
                                <span className="font-bold block text-white">Q{index + 1}: {q.text}</span>
                                <span className={`text-[11px] block mt-1 ${ok ? 'text-emerald-400' : 'text-red-400'}`}>
                                  Your response: {chosenIdx !== undefined ? q.options[chosenIdx] : 'Unanswered'}
                                </span>
                                {!ok && (
                                  <span className="text-[11px] text-slate-400 block mt-0.5">
                                    Correct Answer: {q.options[q.correct]}
                                  </span>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                </div>
              )}

            </div>
          </main>

        </div>
      )}

    </div>
  );
}
