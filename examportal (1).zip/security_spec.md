# Security Specification & Threat Model (ExamPortal)

## Data Invariants

1. **Exams**:
   - Only admin operators can create, update, or delete exam data.
   - Candidates can read the active exam.

2. **Candidates**:
   - Anyone can search for a roll code / check registration.
   - Candidates can only update their own progress, status, score, violations, answers, and submit times.
   - Admin can view, create, update, or delete all candidates.
   - A candidate cannot modify critical administrative fields or another candidate's document.

3. **Violation Logs**:
   - Creating a log is authorized for public/students if it references their own candidate session (authenticated checks).
   - Once a log is written, it is immutable and cannot be modified or deleted.
   - Admins can query and read all logs.

---

## The "Dirty Dozen" Threat Payloads

All the following malicious payloads must be blocked and return `PERMISSION_DENIED`:

1. **Self-Elevated Admin Role**: An unauthenticated or standard student user attempting to overwrite `/exams/main`.
2. **Accessing Another Candidate's Answers**: An authenticated candidate trying to read `/candidates/other_id`.
3. **Impersonated Field Write**: Trying to register a candidate under `candidateId` of "alice" with `id` of "bob".
4. **Altering Another's Answers**: Updating `/candidates/alice` answers array from bob's browser session.
5. **Score Injection**: Changing own score on `/candidates/self` directly via Client SDK without the grading service or correct client checks. (Since this is a client-side layout for grading, standard updates are allowed, but we validate structure to prevent script injection).
6. **Deleting Logs**: A candidate tries to delete a tab-switch violation log at `/logs/log_1` to erase evidence.
7. **Modifying Existing Logs**: Trying to overwrite `/logs/log_1` to say "precheck_pass" instead of "tab_switch".
8. **Exam Leak**: Trying to download all available exams if there were other unpublished exams (strictly check query bounds/allow lists).
9. **Poisoned Document ID Injection**: Attempting to create a document with a junk ID or massive characters string to run a Denial of Wallet attack.
10. **State Shortcutting / State Reversion**: Attempting to set candidate status back to "idle" once they have already submitted or terminated.
11. **Negative Value / Overflow Injection**: Injecting negative scores or violations (e.g. `violations: -999`).
12. **System Invariant Manipulation**: Overwriting candidate `registeredAt` or `accessCode` after creation.
