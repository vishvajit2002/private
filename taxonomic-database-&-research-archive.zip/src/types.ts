/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface MessageChannel {
  /** The single, one-time active secret message payload */
  lastMessage: string;
  /** Server timestamp of the update */
  updatedAt: any; // Using Firestore timestamp
  /** Plain text typing indicator status (no animations, just true/false) */
  isTyping: boolean;
  /** Flag to determine whether the message must be wiped after a single reading session */
  selfDestruct: boolean;
  /** Anonymous sender ID to identify if the current user authored the active note */
  senderSessionId: string;
}

export interface AcademicArticleData {
  title: string;
  subtitle: string;
  sections: {
    id: string;
    heading: string;
    content: string[];
  }[];
  infobox: {
    scientificName: string;
    kingdom: string;
    division: string;
    class: string;
    order: string;
    family: string;
    genus: string;
    species: string;
    conservationStatus: string;
  };
}
