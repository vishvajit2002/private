/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { initializeApp } from 'firebase/app';
import { 
  getFirestore, 
  doc, 
  getDocFromServer, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  serverTimestamp 
} from 'firebase/firestore';

// Load our workspace Firebase configuration credentials
import firebaseConfig from '../firebase-applet-config.json';
import { AcademicArticle } from './components/AcademicArticle';
import { ConfidentialLog } from './components/ConfidentialLog';
import { MessageChannel } from './types';

// Let's configure Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

// Core operation typing for error telemetry
enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
  };
}

// Global Firebase Error Handler matching system skills exactly
function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: 'anonymous_or_public'
    },
    operationType,
    path
  };
  console.error('Firestore Error Payload: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export default function App() {
  const [channelId, setChannelId] = useState<string>(() => {
    return localStorage.getItem('active_academic_accession_key') || '';
  });
  const [searchCode, setSearchCode] = useState<string>('');
  const [channelData, setChannelData] = useState<MessageChannel | null>(null);
  const [isChannelLoading, setIsChannelLoading] = useState<boolean>(false);
  const [sessionId] = useState<string>(() => {
    // Ephemeral dual-client tracking id so a sender knows if they composed the active message or not
    let sId = sessionStorage.getItem('academic_session_id');
    if (!sId) {
      sId = 'ref_sess_' + Math.random().toString(36).substring(2, 11);
      sessionStorage.setItem('academic_session_id', sId);
    }
    return sId;
  });

  // Mandatory Connection Validation upon boot
  useEffect(() => {
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test', 'handshake_connection'));
      } catch (error) {
        if (error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please verify that your Firebase configuration is valid and that you have an internet connection.");
        }
      }
    }
    testConnection();
  }, []);

  // Listen to the active channel in real-time
  useEffect(() => {
    if (!channelId) {
      setChannelData(null);
      setIsChannelLoading(false);
      return;
    }

    setIsChannelLoading(true);
    const pathForSync = `channels/${channelId}`;
    const docRef = doc(db, 'channels', channelId);

    // Subscribe to snapshot updates for the active channel
    const unsubscribe = onSnapshot(
      docRef,
      async (snapshot) => {
        if (snapshot.exists()) {
          setChannelData(snapshot.data() as MessageChannel);
          setIsChannelLoading(false);
        } else {
          // If a new OTP/passcode is used, automatically initialize a clear record
          try {
            const initialPayload = {
              lastMessage: '',
              isTyping: false,
              selfDestruct: false,
              senderSessionId: '',
              updatedAt: serverTimestamp(),
            };
            await setDoc(docRef, initialPayload);
          } catch (error) {
            handleFirestoreError(error, OperationType.WRITE, pathForSync);
          }
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, pathForSync);
        setIsChannelLoading(false);
      }
    );

    return () => {
      unsubscribe();
    };
  }, [channelId]);

  // Handle Loading a passcode/OTP
  const handleLoadChannel = (code: string) => {
    // Sanitize passcode to prevent characters that violate search rules matches
    const sanitized = code.trim().replace(/[^a-zA-Z0-9_\-]/g, '');
    if (sanitized && sanitized.length >= 4) {
      localStorage.setItem('active_academic_accession_key', sanitized);
      setChannelId(sanitized);
    } else {
      alert("Invalid Accession Code format. Please use at least 4 alphanumeric/dash characters.");
    }
  };

  // Handle Clearing/Disconnecting a passcode
  const handleClearChannel = () => {
    localStorage.removeItem('active_academic_accession_key');
    setChannelId('');
    setSearchCode('');
  };

  // Handle message updates / replacement
  const handleUpdateMessage = async (text: string, isSelfDestruct: boolean) => {
    if (!channelId) return;
    const pathForWrite = `channels/${channelId}`;
    try {
      const docRef = doc(db, 'channels', channelId);
      await setDoc(docRef, {
        lastMessage: text,
        updatedAt: serverTimestamp(),
        isTyping: false,
        selfDestruct: isSelfDestruct,
        senderSessionId: sessionId,
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, pathForWrite);
    }
  };

  // Handle burning/clearing the message (wipe)
  const handleClearMessage = async () => {
    if (!channelId) return;
    const pathForWrite = `channels/${channelId}`;
    try {
      const docRef = doc(db, 'channels', channelId);
      await setDoc(docRef, {
        lastMessage: '',
        updatedAt: serverTimestamp(),
        isTyping: false,
        selfDestruct: false,
        senderSessionId: '',
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, pathForWrite);
    }
  };

  // Set local typing status on Firestore
  const handleSetTyping = async (isCurrentlyTyping: boolean) => {
    if (!channelId) return;
    const pathForUpdate = `channels/${channelId}`;
    try {
      const docRef = doc(db, 'channels', channelId);
      await updateDoc(docRef, {
        isTyping: isCurrentlyTyping,
        senderSessionId: sessionId // Update session ID to show who is typing/not typing
      });
    } catch (error) {
      // Avoid throwing on simple blur typing events to prevent user disruption
      console.warn("Telemetry update failed: ", error);
    }
  };

  return (
    <AcademicArticle
      channelId={channelId}
      searchCode={searchCode}
      setSearchCode={setSearchCode}
      onLoadChannel={handleLoadChannel}
      onClearChannel={handleClearChannel}
    >
      <ConfidentialLog
        channelData={channelData}
        isLoading={isChannelLoading}
        onUpdateMessage={handleUpdateMessage}
        onClearMessage={handleClearMessage}
        onSetTyping={handleSetTyping}
        currentSessionId={sessionId}
      />
    </AcademicArticle>
  );
}
