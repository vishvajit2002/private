/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { MessageChannel } from '../types';
import { RefreshCw, Trash2, ShieldAlert, Sparkles } from 'lucide-react';

interface ConfidentialLogProps {
  channelData: MessageChannel | null;
  isLoading: boolean;
  onUpdateMessage: (text: string, isSelfDestruct: boolean) => Promise<void>;
  onClearMessage: () => Promise<void>;
  onSetTyping: (typing: boolean) => Promise<void>;
  currentSessionId: string;
}

export const ConfidentialLog: React.FC<ConfidentialLogProps> = ({
  channelData,
  isLoading,
  onUpdateMessage,
  onClearMessage,
  onSetTyping,
  currentSessionId,
}) => {
  const [inputText, setInputText] = useState('');
  const [selfDestructChecked, setSelfDestructChecked] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [destructCountdown, setDestructCountdown] = useState<number | null>(null);
  
  const countdownIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const isDestructTriggeredRef = useRef(false);

  // Check if active message is from co-author & marked selfDestruct
  const isMessageFromCoAuthor = channelData 
    ? channelData.senderSessionId !== currentSessionId && channelData.lastMessage.trim().length > 0 
    : false;

  const hasActiveMessage = channelData && channelData.lastMessage.trim().length > 0;

  // Handle self-destruct logic (one-time seen option)
  useEffect(() => {
    // If there is an active self-destruct message from co-author, start the timer
    if (channelData && channelData.selfDestruct && isMessageFromCoAuthor && hasActiveMessage) {
      if (!isDestructTriggeredRef.current) {
        isDestructTriggeredRef.current = true;
        setDestructCountdown(15); // 15 seconds to burn
      }
    } else {
      // Reset if message is gone or we are the author
      isDestructTriggeredRef.current = false;
      setDestructCountdown(null);
      if (countdownIntervalRef.current) {
        clearInterval(countdownIntervalRef.current);
        countdownIntervalRef.current = null;
      }
    }

    return () => {
      if (countdownIntervalRef.current) {
        clearInterval(countdownIntervalRef.current);
      }
    };
  }, [channelData?.lastMessage, channelData?.selfDestruct, isMessageFromCoAuthor, hasActiveMessage]);

  // Handle Countdown Decrement
  useEffect(() => {
    if (destructCountdown !== null) {
      if (destructCountdown > 0) {
        countdownIntervalRef.current = setTimeout(() => {
          setDestructCountdown(prev => (prev !== null ? prev - 1 : null));
        }, 1000);
      } else {
        // Countdown hit 0, automatically burn/wipe the message
        handleTriggerBurn();
      }
    }
    return () => {
      if (countdownIntervalRef.current) {
        clearTimeout(countdownIntervalRef.current);
      }
    };
  }, [destructCountdown]);

  const handleTriggerBurn = async () => {
    try {
      await onClearMessage();
      setDestructCountdown(null);
      isDestructTriggeredRef.current = false;
    } catch (err) {
      console.error("Burn failed", err);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    try {
      setErrorMessage('');
      // Set typing to false before writing the message
      await onSetTyping(false);
      await onUpdateMessage(inputText, selfDestructChecked);
      setInputText('');
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Database submission rejected.');
    }
  };

  const handleFocus = () => {
    onSetTyping(true);
  };

  const handleBlur = () => {
    onSetTyping(false);
  };

  // If loading metadata
  if (isLoading) {
    return (
      <div className="bg-[#f8f9fa] border border-[#a2a9b1] p-4 text-xs font-sans text-gray-500 rounded-xs flex items-center justify-center space-x-2 select-none">
        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
        <span>Updating editorial citation references...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6" id="secret-messaging-panel">
      {/* Decrypted Message Disguised perfectly as an Academic Blockquote/Citation Box */}
      <div className="space-y-2">
        {hasActiveMessage ? (
          <div className="my-6">
            <span className="text-[11px] uppercase font-sans tracking-wide text-[#72777d] block font-semibold select-none mb-2">
              Addendum Observation Excerpt:
            </span>
            <div className="p-6 bg-[#f8f9fa] border-l-4 border-[#c8ccd1] text-base md:text-lg text-black font-normal font-serif leading-relaxed italic break-words relative group">
              &ldquo;{channelData.lastMessage}&rdquo;
              
              <div className="mt-4 pt-3 border-t border-[#eaecf0] md:flex items-center justify-between text-[11px] text-[#72777d] font-sans not-italic">
                <span className="block mb-2 md:mb-0 select-none">
                  Registered addendum reference, synchronized {channelData.updatedAt?.toDate ? channelData.updatedAt.toDate().toLocaleTimeString() : 'just now'}.
                </span>
                <button
                  onClick={handleTriggerBurn}
                  className="text-[#a20000] hover:underline cursor-pointer bg-transparent border-none p-0 inline-flex items-center gap-1 font-semibold"
                  title="Wipe proposed excerpt"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>Expunge Excerpt</span>
                </button>
              </div>

              {/* Self-Destruct Warning Banner disguised as standard wiki citation alert */}
              {destructCountdown !== null ? (
                <div className="mt-4 bg-[#fff3cd] border border-[#ffe0b2] p-3 text-xs flex items-center justify-between text-[#856404] font-sans rounded-xs not-italic">
                  <div className="flex items-center space-x-2 font-medium">
                    <ShieldAlert className="w-4 h-4 text-[#ffc107] shrink-0" />
                    <span>Single-access reference. Automated archival cleanup triggers in {destructCountdown}s.</span>
                  </div>
                  <button
                    onClick={handleTriggerBurn}
                    className="text-white bg-[#dc3545] hover:bg-[#c82333] px-2.5 py-1 text-[10px] rounded-xs font-sans font-bold cursor-pointer transition-colors"
                  >
                    Expunge Now
                  </button>
                </div>
              ) : channelData.selfDestruct && channelData.senderSessionId === currentSessionId ? (
                <div className="mt-3 text-[11px] text-[#856404] font-sans not-italic bg-[#fffcf0] border border-[#fef0d0] p-2 leading-relaxed select-none">
                  * Note flagged for single-view destruction. It will be wiped automatically from the registry once loaded by the remote reader.
                </div>
              ) : null}
            </div>
          </div>
        ) : (
          <div className="my-4 p-4 bg-[#f8f9fa] border border-[#a2a9b1] text-xs text-[#72777d] font-sans italic rounded-xs select-none leading-relaxed">
            There is currently no active proposed excerpt in this log. Composing a contribution below will register a new single active blockquote citation.
          </div>
        )}
      </div>

      {/* Typing status (Static text line, no interactive animation) */}
      {channelData?.isTyping && channelData.senderSessionId !== currentSessionId && (
        <div className="text-[11px] font-sans text-gray-500 italic select-none" id="wiki-typing-status">
          [A verified co-editor is currently typing comments in the reference workspace...]
        </div>
      )}

      {/* Low-key, natural Wikipedia section editing panel */}
      <form onSubmit={handleSubmit} className="border border-[#a2a9b1] bg-[#f8f9fa] p-5 rounded-sm space-y-4 font-sans">
        <div className="border-b border-[#a2a9b1] pb-1.5">
          <h4 className="text-xs font-bold uppercase tracking-wide text-[#202122] select-none">
            Propose Observation Addendum / Draft Section Content
          </h4>
        </div>
        
        <div className="space-y-1">
          <label htmlFor="log-draft" className="sr-only">Edit box</label>
          <textarea
            id="log-draft"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onFocus={handleFocus}
            onBlur={handleBlur}
            placeholder="Type your new proposal here. Sending this will replace the current active citation block above."
            className="w-full h-24 bg-white p-3 text-xs font-sans border border-[#a2a9b1] outline-hidden text-[#202122] placeholder-gray-400 focus:border-[#3366cc]"
            maxLength={8000}
          />
        </div>

        {/* Inputs Alignment */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-xs">
          {/* One-time view option */}
          <label className="flex items-center space-x-2 text-[11px] text-gray-600 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={selfDestructChecked}
              onChange={(e) => setSelfDestructChecked(e.target.checked)}
              className="accent-[#3366cc]"
            />
            <span className="font-sans leading-tight">Enable Single View (Wipe automatically 15s after recipient loads message)</span>
          </label>

          <div className="flex space-x-2 self-end font-sans">
            <button
              type="button"
              onClick={() => {
                setInputText('');
                setErrorMessage('');
              }}
              className="px-3 py-1.5 bg-white border border-[#a2a9b1] text-[#202122] hover:bg-[#eaecf0] cursor-pointer text-xs"
            >
              Reset Edit
            </button>
            <button
              type="submit"
              disabled={!inputText.trim()}
              className={`px-4 py-1.5 border border-[#c8ccd1] text-xs font-bold cursor-pointer transition-colors ${
                inputText.trim() 
                  ? 'bg-[#eaecf0] hover:bg-[#e0e2e5] text-black' 
                  : 'bg-gray-100 text-gray-400 cursor-not-allowed border-gray-200'
              }`}
            >
              Submit Contribution
            </button>
          </div>
        </div>

        {errorMessage && (
          <p className="text-xs text-red-700 font-mono italic mt-1 bg-red-50 p-2.5 border border-red-200">
            Submission failed: {errorMessage}
          </p>
        )}
      </form>
    </div>
  );
};
