/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BookOpen, Search, HelpCircle, FileText, Globe, Award, Database, RefreshCw, Layers } from 'lucide-react';

interface AcademicArticleProps {
  channelId: string;
  searchCode: string;
  setSearchCode: (val: string) => void;
  onLoadChannel: (code: string) => void;
  onClearChannel: () => void;
  children: React.ReactNode;
}

export const AcademicArticle: React.FC<AcademicArticleProps> = ({
  channelId,
  searchCode,
  setSearchCode,
  onLoadChannel,
  onClearChannel,
  children,
}) => {
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchCode.trim()) {
      onLoadChannel(searchCode.trim());
    }
  };

  return (
    <div className="min-h-screen bg-[#ffffff] text-[#202122] font-serif selection:bg-[#3366cc]/20 selection:text-black flex flex-col">
      {/* Wikipedia-style Global Top Bar - Editorial Aesthetic */}
      <header className="h-12 border-b border-[#a2a9b1] flex items-center justify-between px-4 bg-white flex-shrink-0 sticky top-0 z-50 shadow-xs" id="wiki-top-bar">
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2 cursor-pointer select-none group" onClick={onClearChannel}>
            <div className="flex flex-col leading-none">
              <span className="text-[10px] font-sans font-bold uppercase tracking-tighter text-[#54595d]">The Free Encyclopedia</span>
              <span className="text-xl font-serif font-extrabold tracking-tight text-[#000000]">WIKIPEDIA</span>
            </div>
          </div>
          <nav className="hidden md:flex space-x-4 text-xs font-sans text-[#0645ad] font-semibold">
            <span className="cursor-pointer hover:underline text-black">Article</span>
            <span className="cursor-pointer hover:underline">Discussion</span>
            <span className="cursor-pointer hover:underline">View source</span>
            <span className="cursor-pointer hover:underline">History</span>
          </nav>
        </div>

        <div className="flex items-center space-x-4">
          {/* Unassuming search bar is actually the entrance field! */}
          <form onSubmit={handleSearchSubmit} className="relative flex items-center border border-[#a2a9b1] px-2.5 py-1 bg-[#f8f9fa] h-8 rounded-sm">
            <label htmlFor="accession-search" className="sr-only">Search Wikipedia</label>
            <input
              id="accession-search"
              type="text"
              placeholder="Search Wikipedia"
              value={searchCode}
              onChange={(e) => setSearchCode(e.target.value)}
              className="bg-transparent text-xs font-sans w-48 sm:w-64 outline-hidden border-none text-[#202122] placeholder-[#72777d]"
              maxLength={40}
            />
            <button type="submit" className="bg-transparent border-hidden cursor-pointer p-0 ml-1">
              <Search className="w-3.5 h-3.5 text-[#72777d] hover:text-[#0645ad]" />
            </button>
          </form>

          <div className="hidden sm:flex items-center space-x-2 text-xs font-sans text-[#0645ad]">
            <span className="cursor-pointer hover:underline">Visitor Session</span>
            <span className="text-[#a2a9b1]">|</span>
            <span className="cursor-pointer hover:underline">Contributions</span>
            <span className="text-[#a2a9b1]">|</span>
            <span className="cursor-pointer hover:underline underline">Log in</span>
          </div>
        </div>
      </header>

      {/* Main Structural Layout */}
      <div className="flex flex-1 overflow-hidden" id="wiki-main-container">
        {/* Left Navigation Rails */}
        <aside className="hidden md:flex flex-col w-40 border-r border-[#a2a9b1] p-4 flex-shrink-0 bg-white text-[11px] font-sans text-[#0645ad] space-y-6" id="wiki-nav-rail">
          <div className="flex flex-col gap-1.5">
            <h5 className="font-bold text-[#54595d] border-b border-[#eaecf0] pb-0.5 mb-1 select-none">Navigation</h5>
            <span className="hover:underline cursor-pointer">Main page</span>
            <span className="hover:underline cursor-pointer">Contents</span>
            <span className="hover:underline cursor-pointer">Current events</span>
            <span className="hover:underline cursor-pointer text-black font-semibold">Random article</span>
            <span className="hover:underline cursor-pointer">About WikiSource</span>
            <span className="hover:underline cursor-pointer">Contact us</span>
          </div>

          <div className="flex flex-col gap-1.5">
            <h5 className="font-bold text-[#54595d] border-b border-[#eaecf0] pb-0.5 mb-1 select-none">Contribute</h5>
            <span className="hover:underline cursor-pointer">Help</span>
            <span className="hover:underline cursor-pointer">Learn to edit</span>
            <span className="hover:underline cursor-pointer">Community portal</span>
            <span className="hover:underline cursor-pointer">Recent changes</span>
            <span className="hover:underline cursor-pointer">Upload file</span>
          </div>

          <div className="bg-[#f8f9fa] p-2.5 border border-[#c8ccd1] rounded-xs text-center flex flex-col gap-1.5 font-sans">
            <p className="text-[10px] text-gray-600 leading-relaxed italic">
              Connect reference archives using credential keys.
            </p>
            <input
              type="text"
              placeholder="Registry Code..."
              value={searchCode}
              onChange={(e) => setSearchCode(e.target.value)}
              className="w-full bg-white px-1.5 py-1 text-[11px] border border-[#a2a9b1] outline-hidden"
            />
            <button
              onClick={() => {
                if (searchCode.trim()) onLoadChannel(searchCode.trim());
              }}
              className="w-full bg-[#f8f9fa] hover:bg-[#eaecf0] border border-[#a2a9b1] text-black font-semibold py-1 rounded-xs cursor-pointer text-[10px]"
            >
              Go to Reference
            </button>
          </div>

          <div className="flex flex-col gap-1.5">
            <h5 className="font-bold text-[#54595d] border-b border-[#eaecf0] pb-0.5 mb-1 select-none">Tools</h5>
            <span className="hover:underline cursor-pointer text-black font-bold">What links here</span>
            <span className="hover:underline cursor-pointer">Related changes</span>
            <span className="hover:underline cursor-pointer">Special pages</span>
            <span className="hover:underline cursor-pointer">Permanent link</span>
            <span className="hover:underline cursor-pointer">Page information</span>
          </div>
        </aside>

        {/* Article Content Container */}
        <main className="flex-1 p-6 sm:p-8 md:p-10 bg-white overflow-y-auto" id="wiki-main-content">
          <div className="max-w-[760px] mx-auto">
            {/* Article Header */}
            <div className="border-b border-[#a2a9b1] pb-2 mb-2">
              <h1 className="font-serif text-3xl text-black font-normal leading-tight tracking-normal">
                Syntrichia caninervis (Desert Moss) desiccation survival physiology
              </h1>
            </div>
            <div className="flex items-center gap-2 text-xs font-sans text-[#72777d] mb-4 italic select-none">
              From Wikipedia, the free encyclopedia
            </div>

            {/* Quick Notice Banner - Classic Neutral wiki alert */}
            <div className="bg-[#f8f9fa] border-l-4 border-[#3366cc] p-3 text-xs mb-6 flex items-start space-x-3 text-gray-700 font-sans">
              <Layers className="w-4 h-4 text-[#3366cc] shrink-0 mt-0.5" />
              <div>
                <strong>Peer-Reviewed Research Document:</strong> This abstract is fully registered with international databases. Verified editors can append real-time field observation records securely using their shared <strong>Accession Codes</strong> to keep tracking logs updated.
              </div>
            </div>

            {/* Core Content Grid (Article + Sidebar) */}
            <div className="lg:grid lg:grid-cols-12 lg:gap-8 items-start">
              {/* Left Column: Actual scientific text */}
              <div className="lg:col-span-8 space-y-6 text-[14px] text-[#202122] leading-relaxed text-justify font-serif" id="wiki-paragraphs">
                <p>
                  <em className="font-bold">Syntrichia caninervis</em> Mitt. is a prominent species of pioneer moss occurring predominantly in arid and hyper-arid desert regions around the globe. Widely cited for its unprecedented capacity to survive extreme desiccation, this bryophyte serves as an important ecological model organism for researchers studying vegetative resilience, environmental limits, and astrobiological survival strategies.
                </p>

                {/* Table of Contents */}
                <div className="bg-[#f8f9fa] border border-[#a2a9b1] p-3 rounded-xs max-w-xs text-xs inline-block font-sans" id="wiki-toc">
                  <div className="font-bold text-center mb-2">Contents</div>
                  <ol className="list-decimal list-inside space-y-1 text-[#0645ad] font-semibold">
                    <li><a href="#taxonomy" className="hover:underline">Scientific Classification</a></li>
                    <li><a href="#morphology" className="hover:underline">Morphological Adaptations</a></li>
                    <li><a href="#desiccation" className="hover:underline">Desiccation Tolerance</a></li>
                    {channelId && (
                      <li><a href="#addendum" className="font-bold text-[#e02020] hover:underline">Addendum: Research Log ({channelId})</a></li>
                    )}
                    <li><a href="#astrobiology" className="hover:underline">Astrobiological Feasibility</a></li>
                    <li><a href="#references" className="hover:underline">References</a></li>
                  </ol>
                </div>

                <h2 id="morphology" className="font-serif text-xl text-black border-b border-[#a2a9b1] pb-1 pt-4 font-normal">
                  1. Morphological Adaptations
                </h2>
                <p>
                  The extreme environment of arid deserts requires complex morphological traits to prevent structural damage during long hydration-desiccation cycles. <em className="font-bold">S. caninervis</em> features closely packed leaf structures with dense costal tissues. Additionally, each leaf terminates in a distinctive translucent hairpoint (awn) that reflects solar radiation, lowers temperature, and assists in fog and dew collection via micron-scale structures.
                </p>

                <h2 id="desiccation" className="font-serif text-xl text-black border-b border-[#a2a9b1] pb-1 pt-4 font-normal">
                  2. Physiological Desiccation Tolerance
                </h2>
                <p>
                  Unlike standard agricultural crops, desiccation-tolerant bryophytes undergo complete glass-like cellular vitrification upon water loss. During drying, metabolic activity is arrested, and the organism stabilizes cellular membranes with highly accumulated sucrose and protective proteins (such as dehydrins and late embryogenesis abundant, or LEA, proteins). Rehydration triggers rapid reactivation of respiration and photosystem repair processes.
                </p>

                {/* Embedded Secret Portal section is positioned right here inside the scientific text where it belongs! */}
                {channelId ? (
                  <div id="addendum" className="transition-all duration-300">
                    <h2 className="font-serif text-lg text-black border-b border-[#a2a9b1] pb-1 pt-6 font-semibold flex items-center justify-between font-sans">
                      <span className="flex items-center text-[#202122] font-serif text-base font-normal italic">
                        <FileText className="w-4 h-4 text-[#72777d] mr-2" />
                        Addendum 7: Ecological Observation Log (Ref: {channelId})
                      </span>
                      <button
                        onClick={onClearChannel}
                        className="text-xs bg-[#f8f9fa] hover:bg-[#eaecf0] border border-[#a2a9b1] text-[#a20000] px-2 py-0.5 rounded-xs font-sans font-medium cursor-pointer"
                      >
                        Disconnect Database
                      </button>
                    </h2>
                    <div className="mt-4 font-sans">
                      {/* The nested confidential terminal message display and controls */}
                      {children}
                    </div>
                  </div>
                ) : (
                  <div className="bg-[#f8f9fa] p-4 rounded-xs border border-dashed border-[#a2a9b1] text-xs text-slate-600 font-sans leading-relaxed my-6">
                    <p className="font-semibold mb-1 text-slate-800">Addendum 7: Ecological Field Log Lock</p>
                    <p>
                      The private co-author log is archived for Accession ID holders. Enter your designated 4-to-12 char passcode or numeric OTP in the top-right <strong>Search Wikipedia</strong> input box to reveal or compose observation updates in this section.
                    </p>
                  </div>
                )}

                <h2 id="astrobiology" className="font-serif text-xl text-black border-b border-[#a2a9b1] pb-1 pt-4 font-normal">
                  3. Astrobiological Feasibility Analysis
                </h2>
                <p>
                  Due to its extreme survival profile, <em className="font-bold">S. caninervis</em> was recently subjected to simulated Martian environments containing sub-zero temperatures, hypoxic atmospheric gases, and intense ultraviolet flux. Research published in 2024 validated that the specimen retains total cellular viability and can regenerate after extensive vacuum-exposure, positioning it as an ideal candidate for Martian colonizing and terraforming studies.
                </p>

                {/* References Section */}
                <h2 id="references" className="font-serif text-base text-gray-700 border-b border-[#eaecf0] pb-1 pt-6 font-normal">
                  References & Citations
                </h2>
                <ol className="list-decimal list-inside text-xs text-gray-500 space-y-1.5 leading-relaxed font-sans">
                  <li>Li, X. et al. (2024). "Extreme environmental survival limits of desert bryophytes: Mars simulation models." <em className="italic">Science & Astrobiology</em>, 54(12), 481-499.</li>
                  <li>Zhang, L. & Wood, A. J. (2018). "Vitrification, sugar transport, and physiological recovery in Syntrichia caninervis." <em className="italic">Plant Physiology Review</em>, 114, 212-225.</li>
                  <li>Mitten, W. (1859). "Musci Indiae Orientalis; an enumeration of the species." <em className="italic">Journal of the Proceedings of the Linnean Society</em>, 1(Suppl), 1-171.</li>
                </ol>
              </div>

              {/* Right Column: Classic Taxonomy Sidebar (Infobox) */}
              <div className="lg:col-span-4 mt-8 lg:mt-0 font-sans" id="wiki-infobox">
                <div className="bg-[#f8f9fa] border border-[#a2a9b1] p-3 rounded-xs text-xs space-y-4">
                  <div className="font-serif text-center text-sm font-bold bg-[#eaecf0] py-1 border-b border-[#a2a9b1]">
                    Syntrichia caninervis
                  </div>
                  
                  {/* Simulated Specimen Image */}
                  <div className="flex flex-col items-center justify-center p-2 border border-[#eaecf0] bg-white rounded-xs">
                    <div className="w-full h-32 bg-[#e0ffd1] border border-[#a8dfa0] rounded-xs flex flex-col items-center justify-center text-center p-3 select-none">
                      <Database className="w-8 h-8 text-[#519d43] mb-1.5" />
                      <span className="font-serif font-bold text-[11px] text-emerald-950">Specimen S. caninervis Mitt.</span>
                      <span className="text-[9px] text-[#519d43] font-mono leading-none">Accession ID Active</span>
                    </div>
                  </div>

                  {/* Taxonomy Table */}
                  <table className="w-full text-[11px] border-collapse">
                    <tbody>
                      <tr className="border-b border-[#eaecf0]">
                        <td className="py-1 font-bold text-[#54595d] w-1/3">Kingdom:</td>
                        <td className="py-1 text-black">Plantae</td>
                      </tr>
                      <tr className="border-b border-[#eaecf0]">
                        <td className="py-1 font-bold text-[#54595d]">Division:</td>
                        <td className="py-1 text-black">Bryophyta</td>
                      </tr>
                      <tr className="border-b border-[#eaecf0]">
                        <td className="py-1 font-bold text-[#54595d]">Class:</td>
                        <td className="py-1 text-black">Bryopsida</td>
                      </tr>
                      <tr className="border-b border-[#eaecf0]">
                        <td className="py-1 font-bold text-[#54595d]">Order:</td>
                        <td className="py-1 text-black">Pottiales</td>
                      </tr>
                      <tr className="border-b border-[#eaecf0]">
                        <td className="py-1 font-bold text-[#54595d]">Family:</td>
                        <td className="py-1 text-black">Pottiaceae</td>
                      </tr>
                      <tr className="border-b border-[#eaecf0]">
                        <td className="py-1 font-bold text-[#54595d]">Genus:</td>
                        <td className="py-1 text-black">
                          <em className="italic">Syntrichia</em>
                        </td>
                      </tr>
                      <tr className="border-b border-[#eaecf0]">
                        <td className="py-1 font-bold text-[#54595d]">Species:</td>
                        <td className="py-1 italic text-black">S. caninervis</td>
                      </tr>
                      <tr className="border-b border-[#eaecf0] bg-[#eaecf0]/40">
                        <td className="py-1.5 font-bold text-gray-700">Conservation:</td>
                        <td className="py-1.5 text-[#008000] font-bold">Stable (LC)</td>
                      </tr>
                    </tbody>
                  </table>

                  {/* Database Registry Codes */}
                  <div className="bg-white p-2.5 border border-[#eaecf0] rounded-xs font-mono text-[10px] space-y-1.5">
                    <div className="font-sans font-bold border-b border-[#eaecf0] pb-0.5 mb-1 text-gray-700">RECORD REGISTRY</div>
                    <div><span className="font-bold">GRID UUID:</span> 9cbf8-88b1-a901</div>
                    <div><span className="font-bold">STATUS:</span> {channelId ? `CONNECTED` : `READY`}</div>
                    <div><span className="font-bold">CHANNEL:</span> {channelId ? channelId : `NONE`}</div>
                    <div><span className="font-bold">IP SEC:</span> TLS_1.3_GCM</div>
                  </div>

                  {channelId && (
                    <div className="pt-1 text-center font-sans">
                      <button
                        onClick={onClearChannel}
                        className="w-full text-center text-xs bg-[#fee] hover:bg-[#fdd] text-[#e02020] border border-[#fcc] py-1.5 rounded-xs block cursor-pointer transition-colors"
                      >
                        Clear Active Accession Key
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Wikipedia-style bottom footer status indicator bars */}
      <footer className="h-6 bg-[#eaecf0] border-t border-[#a2a9b1] px-4 flex items-center justify-between flex-shrink-0 text-[10px] font-sans text-[#72777d] select-none" id="wiki-footer">
        <div>
          Verification Token: <span className="text-black font-semibold">95C9-DEC-4</span>
        </div>
        <div className="flex items-center gap-4">
          <span>Cookie Statement</span>
          <span>Terms of Use</span>
          <span>Desktop Mode</span>
        </div>
      </footer>
    </div>
  );
};
