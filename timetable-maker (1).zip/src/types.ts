export interface ClassInfo {
  id: string;
  name: string; // e.g. "XI - A2", "XII - A2"
}

export interface TeacherInfo {
  id: string;
  name: string; // e.g. "Mr. Ramesh"
  subject: string; // e.g. "Physics"
}

export interface SlotInfo {
  id: string; // e.g. "MORNING_CLASS", "PERIOD_1"
  name: string; // e.g. "Morning class", "1ST PERIOD"
  time: string; // e.g. "7:45-8:45", "9:15 - 10:15"
  isBreak: boolean;
  breakLabel?: string; // e.g. "(MORNING PRAYER)", "(BREAK)"
}

export interface Assignment {
  id: string;
  classId: string;
  teacherId: string;
  day: string; // "MONDAY", "TUESDAY", etc.
  periodId: string; // matches SlotInfo.id (non-breaks)
  subject: string; // stores subject (copied from teacher or customized)
}

export const DAYS = ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"];

export const TIMETABLE_SLOTS: SlotInfo[] = [
  { id: "MORNING_CLASS", name: "Morning class", time: "7:45-8:45", isBreak: false },
  { id: "PRAYER", name: "Prayer", time: "8:45 - 9", isBreak: true, breakLabel: "(MORNING PRAYER)" },
  { id: "BREAK_1", name: "Break 1", time: "9 - 9:15", isBreak: true, breakLabel: "(BREAK)" },
  { id: "PERIOD_1", name: "1ST PERIOD", time: "9:15 - 10:15", isBreak: false },
  { id: "PERIOD_2", name: "2ND PERIOD", time: "10:15 - 11:15", isBreak: false },
  { id: "BREAK_2", name: "Break 2", time: "11:15 - 11:30", isBreak: true, breakLabel: "(BREAK)" },
  { id: "PERIOD_3", name: "3RD PERIOD", time: "11:30 - 12:30", isBreak: false },
  { id: "BREAK_3", name: "Break 3", time: "12:30 - 1:15", isBreak: true, breakLabel: "(BREAK)" },
  { id: "PERIOD_4", name: "4TH PERIOD", time: "1:15 - 2:15", isBreak: false },
  { id: "PERIOD_5", name: "5TH PERIOD", time: "2:15 - 3:15", isBreak: false },
  { id: "BREAK_4", name: "Break 4", time: "3:15 - 3:30", isBreak: true, breakLabel: "(BREAK)" },
  { id: "SLIP_TEST", name: "SLIP TEST", time: "3:30 - 4:00", isBreak: false },
  { id: "EVENING_CLASS_1", name: "EVENING CLASS 1", time: "4:00 - 5:00", isBreak: false },
  { id: "EVENING_CLASS_2", name: "EVENING CLASS 2", time: "5:00 - 6:00", isBreak: false },
];
