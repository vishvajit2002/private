import React, { useState, useEffect } from "react";
import { Users, GraduationCap, AlertTriangle, HelpCircle, CheckCircle2 } from "lucide-react";
import { ClassInfo, TeacherInfo, Assignment, SlotInfo } from "./types";
import Header from "./components/Header";
import ClassManager from "./components/ClassManager";
import TeacherManager from "./components/TeacherManager";
import TimetableGrid from "./components/TimetableGrid";
import AssignmentModal from "./components/AssignmentModal";

export default function App() {
  // --- Persistent Local Database State ---
  const [classes, setClasses] = useState<ClassInfo[]>(() => {
    try {
      const saved = localStorage.getItem("tt_classes");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.some((c: any) => c.id && c.id.includes("sample"))) {
          localStorage.removeItem("tt_classes");
          localStorage.removeItem("tt_teachers");
          localStorage.removeItem("tt_assignments");
          return [];
        }
        return parsed;
      }
      return [];
    } catch {
      return [];
    }
  });

  const [teachers, setTeachers] = useState<TeacherInfo[]>(() => {
    try {
      const saved = localStorage.getItem("tt_teachers");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.some((t: any) => t.id && t.id.includes("sample"))) {
          return [];
        }
        return parsed;
      }
      return [];
    } catch {
      return [];
    }
  });

  const [assignments, setAssignments] = useState<Assignment[]>(() => {
    try {
      const saved = localStorage.getItem("tt_assignments");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.some((a: any) => a.id && a.id.includes("sample"))) {
          return [];
        }
        return parsed;
      }
      return [];
    } catch {
      return [];
    }
  });

  // Active View Target Selection
  const [viewType, setViewType] = useState<"class" | "teacher">("class");
  const [selectedClassId, setSelectedClassId] = useState<string | null>(null);
  const [selectedTeacherId, setSelectedTeacherId] = useState<string | null>(null);

  // Assignment Modal Controls
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [activeDay, setActiveDay] = useState("");
  const [activeSlot, setActiveSlot] = useState<SlotInfo | null>(null);

  // --- Synchronization Effects ---
  useEffect(() => {
    localStorage.setItem("tt_classes", JSON.stringify(classes));
    // If selected class got deleted, clear selection
    if (selectedClassId && !classes.some((c) => c.id === selectedClassId)) {
      setSelectedClassId(classes[0]?.id || null);
    }
    // Auto design selection if none
    if (!selectedClassId && classes.length > 0) {
      setSelectedClassId(classes[0].id);
    }
  }, [classes, selectedClassId]);

  useEffect(() => {
    localStorage.setItem("tt_teachers", JSON.stringify(teachers));
    // If selected teacher got deleted, clear selection
    if (selectedTeacherId && !teachers.some((t) => t.id === selectedTeacherId)) {
      setSelectedTeacherId(teachers[0]?.id || null);
    }
    // Auto design selection if none
    if (!selectedTeacherId && teachers.length > 0) {
      setSelectedTeacherId(teachers[0].id);
    }
  }, [teachers, selectedTeacherId]);

  useEffect(() => {
    localStorage.setItem("tt_assignments", JSON.stringify(assignments));
  }, [assignments]);

  // --- Database Action Handlers ---
  const handleAddClass = (name: string) => {
    // Basic duplicates protection
    if (classes.some((c) => c.name.toLowerCase() === name.toLowerCase())) {
      alert(`Class "${name}" is already registered!`);
      return;
    }
    const newClass: ClassInfo = {
      id: "cls-" + Math.random().toString(36).substring(2, 9),
      name,
    };
    setClasses((prev) => [...prev, newClass]);
    // Set as active instantly
    setSelectedClassId(newClass.id);
    setViewType("class");
  };

  const handleDeleteClass = (id: string) => {
    // Delete class, but also scrub its assignments corresponding to instructions
    setClasses((prev) => prev.filter((c) => c.id !== id));
    setAssignments((prev) => prev.filter((a) => a.classId !== id));
  };

  const handleAddTeacher = (name: string, subject: string) => {
    const newTeacher: TeacherInfo = {
      id: "tchr-" + Math.random().toString(36).substring(2, 9),
      name,
      subject,
    };
    setTeachers((prev) => [...prev, newTeacher]);
    // Set as active instantly
    setSelectedTeacherId(newTeacher.id);
    setViewType("teacher");
  };

  const handleDeleteTeacher = (id: string) => {
    // Delete teacher, scrub assignments corresponding to instructions
    setTeachers((prev) => prev.filter((t) => t.id !== id));
    setAssignments((prev) => prev.filter((a) => a.teacherId !== id));
  };

  // Assign or update a slot
  const handleAssignPeriod = (teacherId: string, classId: string, subject: string) => {
    if (!activeDay || !activeSlot) return;

    // Filter out existing cell assignment if replacing
    setAssignments((prev) => {
      // Find and remove any old assignment in this exact cell for this current ViewType context
      const filtered = prev.filter((a) => {
        if (viewType === "class") {
          // If we are in Class timetable: filter any element in this cell for this class
          return !(a.classId === classId && a.day === activeDay && a.periodId === activeSlot.id);
        } else {
          // If we are in Teacher timetable: filter any element in this cell for this teacher
          return !(a.teacherId === teacherId && a.day === activeDay && a.periodId === activeSlot.id);
        }
      });

      // Insert new/updated assignment
      const newAssign: Assignment = {
        id: "ast-" + Math.random().toString(36).substring(2, 9),
        classId,
        teacherId,
        day: activeDay,
        periodId: activeSlot.id,
        subject,
      };

      return [...filtered, newAssign];
    });
  };

  // Remove assignment
  const handleDeletePeriod = () => {
    if (!activeDay || !activeSlot) return;
    const targetId = viewType === "class" ? selectedClassId : selectedTeacherId;
    if (!targetId) return;

    setAssignments((prev) =>
      prev.filter((a) => {
        if (viewType === "class") {
          return !(a.classId === targetId && a.day === activeDay && a.periodId === activeSlot.id);
        } else {
          return !(a.teacherId === targetId && a.day === activeDay && a.periodId === activeSlot.id);
        }
      })
    );
  };

  // CELL CLICK trigger
  const handleCellClick = (day: string, slot: SlotInfo) => {
    // Save target info and open Assignment modal
    setActiveDay(day);
    setActiveSlot(slot);
    setIsModalOpen(true);
  };

  // --- Backup Handlers ---
  const handleImportBackup = (data: { classes: ClassInfo[]; teachers: TeacherInfo[]; assignments: Assignment[] }) => {
    setClasses(data.classes || []);
    setTeachers(data.teachers || []);
    setAssignments(data.assignments || []);
    if (data.classes?.length > 0) setSelectedClassId(data.classes[0].id);
    if (data.teachers?.length > 0) setSelectedTeacherId(data.teachers[0].id);
  };

  const handleClearAll = () => {
    setClasses([]);
    setTeachers([]);
    setAssignments([]);
    setSelectedClassId(null);
    setSelectedTeacherId(null);
  };

  // Specimen sample datasets to match user screenshot values!
  const handleLoadStudentsSample = () => {
    const sampleClasses: ClassInfo[] = [
      { id: "cls-sample-1", name: "XI - A2" },
      { id: "cls-sample-2", name: "XII - A2" },
      { id: "cls-sample-3", name: "X - B" },
    ];

    const sampleTeachers: TeacherInfo[] = [
      { id: "t-sample-1", name: "Mr. David", subject: "Maths" },
      { id: "t-sample-2", name: "Mrs. Sarah", subject: "Physics" },
      { id: "t-sample-3", name: "Dr. Radhakrishnan", subject: "Chemistry" },
      { id: "t-sample-4", name: "Miss Priya", subject: "English" },
    ];

    // Align with screenshot!
    const sampleAssignments: Assignment[] = [];

    // XI-A2 assigned in class slot
    // 1. Saturday MORNING_CLASS (7:45 - 8:45) is assigned to "XI - A2"
    sampleAssignments.push({
      id: "ast-s1",
      classId: "cls-sample-1",
      teacherId: "t-sample-1", // Mr. David teaching
      day: "SATURDAY",
      periodId: "MORNING_CLASS",
      subject: "Maths",
    });

    // 2. Monday to Friday/Saturday 4th Period is "XI - A2" (Physics taught by Mrs. Sarah)
    const daysArr = ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"];
    daysArr.forEach((d, idx) => {
      sampleAssignments.push({
        id: `ast-s2-${idx}`,
        classId: "cls-sample-1",
        teacherId: "t-sample-2", // Mrs. Sarah teaching
        day: d,
        periodId: "PERIOD_4",
        subject: "Physics",
      });
    });

    // 3. Friday evening class 2 (5:00 - 6:00) is "XI - A2"
    sampleAssignments.push({
      id: "ast-s3",
      classId: "cls-sample-1",
      teacherId: "t-sample-3", // Chemistry
      day: "FRIDAY",
      periodId: "EVENING_CLASS_2",
      subject: "Chemistry",
    });

    // XII-A2 assigned in SATURDAY/Mon Slip Test (3:30 - 4:00)
    daysArr.forEach((d, idx) => {
      sampleAssignments.push({
        id: `ast-s4-${idx}`,
        classId: "cls-sample-2",
        teacherId: "t-sample-4", // Miss Priya
        day: d,
        periodId: "SLIP_TEST",
        subject: "Slip Test",
      });
    });

    // Load sample data
    setClasses(sampleClasses);
    setTeachers(sampleTeachers);
    setAssignments(sampleAssignments);
    setSelectedClassId("cls-sample-1");
    setSelectedTeacherId("t-sample-1");
    setViewType("class");
    alert("Sample datasets loaded! We have automatically structured Class XI-A2 and XII-A2 matching your exact spreadsheet sample!");
  };

  // Get active selected ID based on viewType
  const activeSelectedId = viewType === "class" ? selectedClassId : selectedTeacherId;

  // Scan and gather all clashes to show in the sidebar alert panel
  const getClashesCount = () => {
    let count = 0;
    const teacherSlotBookings: { [key: string]: string[] } = {}; // Key: "DAY_PERIOD", Value: list of teacher ids

    // Let's count teacher clashes. Match day + period + teacherId
    assignments.forEach((ast) => {
      const key = `${ast.day}_${ast.periodId}_${ast.teacherId}`;
      if (!teacherSlotBookings[key]) {
        teacherSlotBookings[key] = [];
      }
      teacherSlotBookings[key].push(ast.classId);
    });

    Object.values(teacherSlotBookings).forEach((list) => {
      if (list.length > 1) count++;
    });

    return count;
  };

  const totalClashes = getClashesCount();

  return (
    <div className="min-h-screen bg-slate-100 font-sans print:bg-white text-slate-900 pb-12 pt-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Branding section */}
        <Header
          classes={classes}
          teachers={teachers}
          assignments={assignments}
          onImportBackup={handleImportBackup}
          onClearAll={handleClearAll}
          onLoadStudentsSample={handleLoadStudentsSample}
        />

        {/* Master Workspace Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* LEFT COLUMN: Sidebar controllers (4 cols) */}
          <div className="lg:col-span-4 space-y-6 print:hidden">
            
            {/* View Type Switcher */}
            <div className="bg-white rounded-3xl border border-slate-200 p-2 shadow-sm flex gap-1.5">
              <button
                type="button"
                onClick={() => setViewType("class")}
                className={`flex-1 py-2.5 text-xs font-bold rounded-2xl transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  viewType === "class"
                    ? "bg-indigo-650 text-white shadow-xs"
                    : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                }`}
              >
                <Users className="h-4 w-4" />
                Student Class View
              </button>
              <button
                type="button"
                onClick={() => setViewType("teacher")}
                className={`flex-1 py-2.5 text-xs font-bold rounded-2xl transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  viewType === "teacher"
                    ? "bg-emerald-650 text-white shadow-xs"
                    : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                }`}
              >
                <GraduationCap className="h-4 w-4" />
                Teacher Assigned View
              </button>
            </div>

            {/* Class Registration manager */}
            <ClassManager
              classes={classes}
              selectedClassId={viewType === "class" ? selectedClassId : null}
              onSelectClass={(id) => {
                setSelectedClassId(id);
                setViewType("class");
              }}
              onAddClass={handleAddClass}
              onDeleteClass={handleDeleteClass}
            />

            {/* Teacher and Subject Registration manager */}
            <TeacherManager
              teachers={teachers}
              selectedTeacherId={viewType === "teacher" ? selectedTeacherId : null}
              onSelectTeacher={(id) => {
                setSelectedTeacherId(id);
                setViewType("teacher");
              }}
              onAddTeacher={handleAddTeacher}
              onDeleteTeacher={handleDeleteTeacher}
            />

            {/* Collision warning system */}
            {totalClashes > 0 ? (
              <div className="bg-red-50 rounded-3xl border border-red-200 p-5 shadow-sm">
                <div className="flex items-start gap-3">
                  <div className="rounded-xl bg-red-100 p-2 text-red-600 shrink-0">
                    <AlertTriangle className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-red-950">Dynamic Clashing Detected</h4>
                    <p className="text-xs text-red-700/90 leading-relaxed mt-1">
                      Currently tracking <strong className="font-extrabold">{totalClashes} double-bookings</strong>! Check the red outline cells in the timetable below or modify periods to correct these.
                    </p>
                  </div>
                </div>
              </div>
            ) : classes.length > 0 ? (
              <div className="bg-slate-900 text-white rounded-3xl p-5 border border-slate-850 shadow-sm flex items-center gap-3">
                <div className="rounded-full bg-emerald-500/20 p-2 text-emerald-450 shrink-0">
                  <span className="relative flex h-2.5 w-2.5">
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-450 animate-pulse"></span>
                  </span>
                </div>
                <div>
                  <h4 className="text-xs font-bold font-mono tracking-wider text-emerald-450 uppercase">Clash Checking system</h4>
                  <p className="text-xs text-slate-450 mt-0.5 leading-none">Schedule is verified. No double-bookings! ✅</p>
                </div>
              </div>
            ) : null}

          </div>

          {/* RIGHT COLUMN: Timetable visual grid (8 cols) */}
          <div className="lg:col-span-8 print:w-full">
            <TimetableGrid
              viewType={viewType}
              targetId={activeSelectedId}
              classes={classes}
              teachers={teachers}
              assignments={assignments}
              onCellClick={handleCellClick}
            />
          </div>

        </div>

        {/* Small Aristo Footer Details */}
        <footer className="mt-8 pt-4 border-t border-slate-200 pb-2">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-[10px] text-slate-400 font-bold font-mono tracking-widest uppercase">
            <span>VICE PRINCIPAL: Mrs. Meenakshi</span>
            <span>Developed by Vishvajit R</span>
          </div>
        </footer>

      </div>

      {/* Persistent Period Editing and assignment Modal */}
      {activeSlot && (
        <AssignmentModal
          isOpen={isModalOpen}
          viewType={viewType}
          targetId={activeSelectedId || ""}
          day={activeDay}
          slot={activeSlot}
          classes={classes}
          teachers={teachers}
          assignments={assignments}
          onClose={() => setIsModalOpen(false)}
          onAssign={handleAssignPeriod}
          onDelete={handleDeletePeriod}
        />
      )}
    </div>
  );
}
