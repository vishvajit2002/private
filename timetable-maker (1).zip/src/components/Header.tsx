import React, { useRef, useState } from "react";
import { FolderUp, FolderDown, FileSpreadsheet, Trash2, HelpCircle, AlertOctagon } from "lucide-react";
import { ClassInfo, TeacherInfo, Assignment, TIMETABLE_SLOTS } from "../types";
import ConfirmModal from "./ConfirmModal";

interface HeaderProps {
  classes: ClassInfo[];
  teachers: TeacherInfo[];
  assignments: Assignment[];
  onImportBackup: (data: { classes: ClassInfo[]; teachers: TeacherInfo[]; assignments: Assignment[] }) => void;
  onClearAll: () => void;
  onLoadStudentsSample: () => void;
}

export default function Header({
  classes,
  teachers,
  assignments,
  onImportBackup,
  onClearAll,
  onLoadStudentsSample,
}: HeaderProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  // Download backup handler
  const handleExportBackup = () => {
    const backupData = {
      classes,
      teachers,
      assignments,
      exportedAt: new Date().toISOString(),
    };
    
    const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(
      JSON.stringify(backupData, null, 2)
    )}`;
    
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", jsonString);
    downloadAnchor.setAttribute("download", `timetable_backup_${new Date().toISOString().slice(0,10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    document.body.removeChild(downloadAnchor);
  };

  // Upload backup handler
  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed && Array.isArray(parsed.classes) && Array.isArray(parsed.teachers) && Array.isArray(parsed.assignments)) {
          onImportBackup({
            classes: parsed.classes,
            teachers: parsed.teachers,
            assignments: parsed.assignments,
          });
          alert("Backup uploaded successfully! Timetable has been synchronised.");
        } else {
          alert("Invalid file structure. Make sure you are uploading a valid timetable backup (.json) file.");
        }
      } catch (err) {
        alert("File parsing error. The file is corrupted or not in JSON format.");
      }
    };
    reader.readAsText(file);
    // Reset file input value so same file can be uploaded again
    e.target.value = "";
  };

  // Export Master Spreadsheet of all assignments
  const handleExportMasterCSV = () => {
    let csvContent = "data:text/csv;charset=utf-8,";
    
    // Headers
    csvContent += "Class,Day,Period,Period Time,Teacher Name,Subject\r\n";

    // Loop through all registered classes and assign data
    classes.forEach(cls => {
      TIMETABLE_SLOTS.filter(s => !s.isBreak).forEach(slot => {
        const daysCollection = ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"];
        daysCollection.forEach(day => {
          const ast = assignments.find(a => a.classId === cls.id && a.day === day && a.periodId === slot.id);
          if (ast) {
            const t = teachers.find(tr => tr.id === ast.teacherId);
            csvContent += `"${cls.name}","${day}","${slot.name}","${slot.time}","${t?.name || "Unassigned"}","${ast.subject}"\r\n`;
          }
        });
      });
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Master_School_Timetable_Record.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <header className="bg-white text-slate-800 rounded-3xl border border-slate-200 p-6 shadow-xs mb-6 relative overflow-hidden print:hidden">
      {/* Subtle modern top decorative gradients */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -top-10 -left-10 w-40 h-40 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
        {/* Branding Title with Logo */}
        <div className="flex items-center gap-4">
          <div className="bg-slate-50 p-2 rounded-2xl border border-slate-100 flex items-center justify-center shrink-0 shadow-xs">
            <img 
              src="https://www.apsfoundation.in/images/logo.png" 
              alt="Aristo Public School Logo" 
              className="h-16 w-auto object-contain" 
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight text-slate-900">
              Aristo Public School
            </h1>
            <p className="text-xs md:text-sm font-bold tracking-wider text-indigo-600 uppercase mt-1">
              Education for Enlightenment
            </p>
          </div>
        </div>

        {/* Global Sync and Utility tools panel in a clean, compact toolbar */}
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {/* Master Excel/CSV Export */}
          <button
            onClick={handleExportMasterCSV}
            disabled={true}
            className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 px-3 py-2 text-xs font-bold text-slate-700 transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed shadow-xs"
            title="Export absolute full database record as a spreadsheet"
          >
            <FileSpreadsheet className="h-3.5 w-3.5 text-emerald-600" />
            Export Master CSV
          </button>

          {/* Download JSON Backup */}
          <button
            onClick={handleExportBackup}
            className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 px-3 py-2 text-xs font-bold text-slate-700 transition-all cursor-pointer shadow-xs"
            title="Download JSON master sync data"
          >
            <FolderDown className="h-3.5 w-3.5 text-indigo-600" />
            Download
          </button>

          {/* Upload JSON Backup */}
          <button
            onClick={handleImportClick}
            className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 px-3 py-2 text-xs font-bold text-slate-700 transition-all cursor-pointer shadow-xs"
            title="Restore and import previous JSON timetables"
          >
            <FolderUp className="h-3.5 w-3.5 text-sky-600" />
            Upload Backup
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".json,application/json"
            className="hidden"
          />

          {/* Reset button */}
          <button
            onClick={() => setShowClearConfirm(true)}
            className="p-2 rounded-xl border border-red-200 bg-red-50 text-red-650 hover:bg-red-100 transition-colors cursor-pointer shadow-xs"
            title="Reset active working memory"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Database Deletion Master Prompt */}
      <ConfirmModal
        isOpen={showClearConfirm}
        title="Clear All Work memory?"
        message="Are you sure you want to completely format and reset the database? This deletes all registered classes, teacher names, subjects, and periods instantly. Download a master backup file first if you wish to restore it later!"
        confirmText="Yes, Factory Reset"
        onConfirm={() => {
          onClearAll();
          setShowClearConfirm(false);
        }}
        onCancel={() => setShowClearConfirm(false)}
      />
    </header>
  );
}
