import React, { useState } from "react";
import { Plus, Trash2, GraduationCap, Check } from "lucide-react";
import { TeacherInfo } from "../types";
import ConfirmModal from "./ConfirmModal";

interface TeacherManagerProps {
  teachers: TeacherInfo[];
  selectedTeacherId: string | null;
  onSelectTeacher: (id: string) => void;
  onAddTeacher: (name: string, subject: string) => void;
  onDeleteTeacher: (id: string) => void;
}

export default function TeacherManager({
  teachers,
  selectedTeacherId,
  onSelectTeacher,
  onAddTeacher,
  onDeleteTeacher,
}: TeacherManagerProps) {
  const [name, setName] = useState("");
  const [subject, setSubject] = useState("");
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !subject.trim()) return;
    onAddTeacher(name.trim(), subject.trim());
    setName("");
    setSubject("");
  };

  const handleDeleteTrigger = (id: string, e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent choosing when clicking delete button
    setDeleteId(id);
  };

  const handleDeleteConfirm = () => {
    if (deleteId) {
      onDeleteTeacher(deleteId);
      setDeleteId(null);
    }
  };

  const getDeleteTeacherInfo = () => {
    return teachers.find(t => t.id === deleteId);
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm flex flex-col h-full min-h-[320px]">
      <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
            <GraduationCap className="h-4 w-4 text-emerald-600" />
            Faculty Members
          </h2>
          <p className="text-[11px] text-slate-500 mt-0.5">Register staff members and their subjects.</p>
        </div>
      </div>

      <div className="flex-1 flex flex-col justify-between">
        <div>
          {/* Teacher Entry Form */}
          <form onSubmit={handleSubmit} className="space-y-2">
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Name (e.g. Mr. David)"
                className="flex-1 min-w-0 rounded-xl border border-slate-200 px-3 py-2 text-sm placeholder-slate-400 focus:border-emerald-500 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 transition-colors bg-slate-50/50"
              />
              <input
                type="text"
                required
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Subject (e.g. Physics)"
                className="flex-1 min-w-0 rounded-xl border border-slate-200 px-3 py-2 text-sm placeholder-slate-400 focus:border-emerald-500 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 transition-colors bg-slate-50/50"
              />
              <button
                type="submit"
                className="inline-flex items-center justify-center rounded-xl bg-emerald-600 p-2.5 text-white hover:bg-emerald-700 hover:scale-[1.02] active:scale-95 transition-all cursor-pointer shrink-0 shadow-xs"
                title="Register Teacher"
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>
          </form>

          {/* Teachers List */}
          <div className="mt-4 space-y-1.5 max-h-56 overflow-y-auto pr-1">
            {teachers.length === 0 ? (
              <div className="text-center py-6 text-xs text-slate-400 italic bg-slate-50/40 rounded-2xl border border-dashed border-slate-200">
                No teachers registered yet.
              </div>
            ) : (
              teachers.map((teacher) => {
                const isSelected = selectedTeacherId === teacher.id;
                return (
                  <div
                    key={teacher.id}
                    onClick={() => onSelectTeacher(teacher.id)}
                    className={`group flex items-center justify-between px-3.5 py-2.5 rounded-2xl cursor-pointer transition-all border ${
                      isSelected
                        ? "bg-emerald-600 border-emerald-700 text-white font-semibold shadow-xs"
                        : "bg-slate-50 hover:bg-slate-100 border-transparent text-slate-700"
                    }`}
                  >
                    <div className="flex-1 truncate pr-2">
                      <div className="text-sm font-semibold leading-none truncate">{teacher.name}</div>
                      <div className={`text-[10px] mt-1 font-mono transition-colors ${
                        isSelected ? "text-white/80" : "text-slate-500"
                      }`}>{teacher.subject}</div>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0 bg-transparent">
                      {isSelected ? (
                        <span className="inline-flex items-center justify-center rounded-full bg-white/20 p-0.5 text-white">
                          <Check className="h-3 w-3" />
                        </span>
                      ) : null}
                      <button
                        type="button"
                        onClick={(e) => handleDeleteTrigger(teacher.id, e)}
                        className={`p-1 rounded-md transition-all cursor-pointer ${
                          isSelected
                            ? "hover:bg-white/10 text-white/75 hover:text-white"
                            : "opacity-0 group-hover:opacity-100 hover:text-red-650 text-slate-400 hover:bg-slate-200"
                        }`}
                        title="Delete Teacher"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={deleteId !== null}
        title="Delete Teacher?"
        message={`Are you sure you want to delete the teacher "${getDeleteTeacherInfo()?.name || ""}"? This will permanently remove all timetable periods and scheduling assigned to this teacher across all classes.`}
        confirmText="Yes, Delete Teacher"
        onConfirm={handleDeleteConfirm}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}
