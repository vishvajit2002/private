import React, { useState } from "react";
import { Plus, Trash2, Users, Check } from "lucide-react";
import { ClassInfo } from "../types";
import ConfirmModal from "./ConfirmModal";

interface ClassManagerProps {
  classes: ClassInfo[];
  selectedClassId: string | null;
  onSelectClass: (id: string) => void;
  onAddClass: (name: string) => void;
  onDeleteClass: (id: string) => void;
}

export default function ClassManager({
  classes,
  selectedClassId,
  onSelectClass,
  onAddClass,
  onDeleteClass,
}: ClassManagerProps) {
  const [newClassName, setNewClassName] = useState("");
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClassName.trim()) return;
    onAddClass(newClassName.trim());
    setNewClassName("");
  };

  const handleDeleteTrigger = (id: string, e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent choosing the class when clicking its delete button
    setDeleteId(id);
  };

  const handleDeleteConfirm = () => {
    if (deleteId) {
      onDeleteClass(deleteId);
      setDeleteId(null);
    }
  };

  const getDeleteClassInfo = () => {
    return classes.find(c => c.id === deleteId);
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm flex flex-col h-full min-h-[320px]">
      <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
            <Users className="h-4 w-4 text-indigo-600" />
            Classes Registry
          </h2>
          <p className="text-[11px] text-slate-500 mt-0.5">Register classes to create their schedules.</p>
        </div>
      </div>

      <div className="flex-1 flex flex-col justify-between">
        <div>
          {/* Class Form */}
          <form onSubmit={handleSubmit} className="flex gap-2">
            <input
              type="text"
              required
              value={newClassName}
              onChange={(e) => setNewClassName(e.target.value)}
              placeholder="e.g. XI - A2"
              className="flex-1 min-w-0 rounded-xl border border-slate-200 px-3 py-2 text-sm placeholder-slate-400 focus:border-indigo-500 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 transition-colors bg-slate-50/50"
            />
            <button
              type="submit"
              className="inline-flex items-center justify-center rounded-xl bg-indigo-600 p-2.5 text-white hover:bg-indigo-700 hover:scale-[1.02] active:scale-95 transition-all cursor-pointer shadow-xs"
              title="Register Class"
            >
              <Plus className="h-4 w-4" />
            </button>
          </form>

          {/* Classes List */}
          <div className="mt-4 space-y-1.5 max-h-56 overflow-y-auto pr-1">
            {classes.length === 0 ? (
              <div className="text-center py-6 text-xs text-slate-400 italic bg-slate-50/40 rounded-2xl border border-dashed border-slate-200">
                No classes registered yet.
              </div>
            ) : (
              classes.map((cls) => {
                const isSelected = selectedClassId === cls.id;
                return (
                  <div
                    key={cls.id}
                    onClick={() => onSelectClass(cls.id)}
                    className={`group flex items-center justify-between px-3.5 py-2.5 rounded-2xl cursor-pointer transition-all border ${
                      isSelected
                        ? "bg-indigo-600 border-indigo-700 text-white font-semibold shadow-xs"
                        : "bg-slate-50 hover:bg-slate-100 border-transparent text-slate-700"
                    }`}
                  >
                    <span className="text-sm truncate pr-2">{cls.name}</span>
                    <div className="flex items-center gap-1.5 shrink-0">
                      {isSelected ? (
                        <span className="inline-flex items-center justify-center rounded-full bg-white/20 p-0.5 text-white">
                          <Check className="h-3 w-3" />
                        </span>
                      ) : null}
                      <button
                        type="button"
                        onClick={(e) => handleDeleteTrigger(cls.id, e)}
                        className={`p-1 rounded-md transition-all cursor-pointer ${
                          isSelected
                            ? "hover:bg-white/10 text-white/75 hover:text-white"
                            : "opacity-0 group-hover:opacity-100 hover:text-red-650 text-slate-400 hover:bg-slate-200"
                        }`}
                        title="Delete Class"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={deleteId !== null}
        title="Delete Class?"
        message={`Are you sure you want to delete the class "${getDeleteClassInfo()?.name || ""}"? This will permanently remove all timetable periods and scheduling assigned to this class.`}
        confirmText="Yes, Delete Class"
        onConfirm={handleDeleteConfirm}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}
