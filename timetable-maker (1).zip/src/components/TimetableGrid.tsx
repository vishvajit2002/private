import React from "react";
import { Printer, Download, AlertCircle, Sparkles, User, Users } from "lucide-react";
import { ClassInfo, TeacherInfo, Assignment, TIMETABLE_SLOTS, DAYS, SlotInfo } from "../types";

// Helper of Tailwind colors for different teachers/classes to match visual picture
// Helper of Tailwind colors for different teachers/classes to match visual picture
const PASTEL_PALETTE = [
  { bg: "bg-emerald-50", text: "text-emerald-950", border: "border-emerald-200", tagBg: "bg-emerald-100 text-emerald-850" },
  { bg: "bg-amber-50", text: "text-amber-950", border: "border-amber-200", tagBg: "bg-amber-100 text-amber-850" },
  { bg: "bg-sky-50", text: "text-sky-950", border: "border-sky-200", tagBg: "bg-sky-100 text-sky-850" },
  { bg: "bg-violet-50", text: "text-violet-950", border: "border-violet-200", tagBg: "bg-violet-100 text-violet-850" },
  { bg: "bg-indigo-50", text: "text-indigo-950", border: "border-indigo-200", tagBg: "bg-indigo-100 text-indigo-850" },
  { bg: "bg-rose-50", text: "text-rose-950", border: "border-rose-200", tagBg: "bg-rose-100 text-rose-850" },
  { bg: "bg-teal-50", text: "text-teal-950", border: "border-teal-200", tagBg: "bg-teal-100 text-teal-850" },
  { bg: "bg-orange-50", text: "text-orange-950", border: "border-orange-200", tagBg: "bg-orange-100 text-orange-850" },
  { bg: "bg-fuchsia-50", text: "text-fuchsia-950", border: "border-fuchsia-200", tagBg: "bg-fuchsia-100 text-fuchsia-850" },
];

function stringToColorClass(str: string) {
  if (!str) return PASTEL_PALETTE[0];
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  const index = Math.abs(hash) % PASTEL_PALETTE.length;
  return PASTEL_PALETTE[index];
}

interface TimetableGridProps {
  viewType: "class" | "teacher";
  targetId: string | null;
  classes: ClassInfo[];
  teachers: TeacherInfo[];
  assignments: Assignment[];
  onCellClick: (day: string, slot: SlotInfo) => void;
}

export default function TimetableGrid({
  viewType,
  targetId,
  classes,
  teachers,
  assignments,
  onCellClick,
}: TimetableGridProps) {
  // If no target is selected
  const activeClass = viewType === "class" ? classes.find((c) => c.id === targetId) : null;
  const activeTeacher = viewType === "teacher" ? teachers.find((t) => t.id === targetId) : null;

  if (!targetId) {
    return (
      <div className="flex flex-col items-center justify-center py-16 px-4 bg-white rounded-2xl border border-slate-200 border-dashed text-center">
        <div className="h-12 w-12 rounded-full bg-slate-50 flex items-center justify-center text-slate-400 mb-4 animate-bounce">
          {viewType === "class" ? <Users className="h-6 w-6" /> : <User className="h-6 w-6" />}
        </div>
        <h3 className="text-base font-semibold text-slate-800">
          No {viewType === "class" ? "Class" : "Teacher"} Selected
        </h3>
        <p className="text-sm text-slate-500 mt-1 max-w-sm">
          Please select or register a {viewType === "class" ? "class" : "teacher"} from the sidebar list to see and design their interactive weekly timetable in real-time.
        </p>
      </div>
    );
  }

  // Find all clashes in the entire program for high-fidelity rendering
  const getCollisionStatus = (ast: Assignment) => {
    // A teacher is clashed if they have other assignments at the same day/period
    const teacherClashes = assignments.filter(
      (a) => a.teacherId === ast.teacherId && a.day === ast.day && a.periodId === ast.periodId && a.id !== ast.id
    );

    // A class is clashed if they have other assignments at the same day/period
    const classClashes = assignments.filter(
      (a) => a.classId === ast.classId && a.day === ast.day && a.periodId === ast.periodId && a.id !== ast.id
    );

    return {
      isTeacherClashed: teacherClashes.length > 0,
      isClassClashed: classClashes.length > 0,
      teacherClashesWith: teacherClashes.map(tc => classes.find(c => c.id === tc.classId)?.name || "Unknown"),
      classClashesWith: classClashes.map(cc => teachers.find(t => t.id === cc.teacherId)?.name || "Unknown"),
    };
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadCSV = () => {
    const targetName = activeClass ? activeClass.name : activeTeacher ? activeTeacher.name : "timetable";
    let csvContent = "data:text/csv;charset=utf-8,";
    
    // Headers
    // Filter non-break slots to write data clearly
    const activeHeaderSlots = TIMETABLE_SLOTS.filter(s => !s.isBreak);
    const headers = ["Day", ...activeHeaderSlots.map(s => `"${s.name} (${s.time})"` )];
    csvContent += headers.join(",") + "\r\n";

    // Rows
    DAYS.forEach(day => {
      const row = [day];
      activeHeaderSlots.forEach(slot => {
        // Find assignment
        const ast = assignments.find(a => {
          if (viewType === "class") {
            return a.classId === targetId && a.day === day && a.periodId === slot.id;
          } else {
            return a.teacherId === targetId && a.day === day && a.periodId === slot.id;
          }
        });

        if (ast) {
          if (viewType === "class") {
            const tr = teachers.find(t => t.id === ast.teacherId);
            row.push(`"${tr?.name || ""} (${ast.subject})"` );
          } else {
            const cl = classes.find(c => c.id === ast.classId);
            row.push(`"${cl?.name || ""} (${ast.subject})"` );
          }
        } else {
          row.push('""');
        }
      });
      csvContent += row.join(",") + "\r\n";
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Timetable_${targetName.replace(/\s+/g, "_")}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4">
      {/* Action Toolbar above Timetable Grid */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-5 rounded-3xl border border-slate-200 shadow-sm print:hidden">
        <div className="flex items-center gap-3">
          <div className={`p-3 rounded-2xl ${viewType === "class" ? "bg-indigo-50 text-indigo-700" : "bg-emerald-50 text-emerald-700"}`}>
            {viewType === "class" ? <Users className="h-5 w-5" /> : <User className="h-5 w-5" />}
          </div>
          <div>
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest leading-none block">
              {viewType === "class" ? "Student Class View" : "Teacher Assigned View"}
            </span>
            <h2 className="text-xl font-bold text-slate-800 mt-1 pb-0.5 leading-none">
              {activeClass ? activeClass.name : activeTeacher ? activeTeacher.name : ""}
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={handleDownloadCSV}
            className="inline-flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-2.5 text-xs font-bold text-slate-700 bg-white hover:bg-slate-50 active:scale-97 transition-all cursor-pointer hover:border-slate-300"
            title="Download this specific timetable as CSV"
          >
            <Download className="h-4 w-4 text-slate-500" />
            Download CSV
          </button>
          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-2 rounded-xl bg-slate-900 border border-slate-900 px-4 py-2.5 text-xs font-bold text-white hover:bg-slate-850 active:scale-97 transition-all cursor-pointer shadow-xs"
            title="Print or Save this timetable as PDF"
          >
            <Printer className="h-4 w-4" />
            Print / PDF
          </button>
        </div>
      </div>

      {/* Printable Sheet Wrapper */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden print:border-0 print:shadow-none print:p-0 print:overflow-visible">
        
        {/* Printable Only Header */}
        <div className="hidden print:block text-center mb-6">
          <h1 className="text-2xl font-bold text-slate-900 uppercase">
            {activeClass ? `Class Timetable - ${activeClass.name}` : `Teacher Schedule - ${activeTeacher?.name}`}
          </h1>
          {activeTeacher && (
            <p className="text-sm font-mono text-slate-600 mt-1 uppercase">
              Subject area: {activeTeacher.subject}
            </p>
          )}
          <p className="text-xs text-slate-400 mt-1">Generated and Printed via school Timetable Maker</p>
        </div>

        {/* Horizontal scroll container for the 15-column layout */}
        <div className="overflow-x-auto w-full print:overflow-visible">
          <table className="w-full min-w-[1200px] border-collapse text-left print:min-w-0 print:w-full table-fixed print:overflow-visible">
            <thead>
              <tr className="bg-slate-100 border-b border-slate-200 print:bg-slate-50">
                {/* Day Header */}
                <th className="p-3 print:p-1 text-xs print:text-[9.5px] font-bold text-slate-800 border-r border-slate-250 w-[100px] print:w-[65px] bg-slate-150 sticky left-0 z-10 print:bg-slate-100 uppercase">
                  Day
                </th>
                
                {/* Slot Headers */}
                {TIMETABLE_SLOTS.map((slot) => {
                  if (slot.isBreak) {
                    return (
                      <th
                        key={slot.id}
                        className="p-1 border-r border-slate-250 bg-blue-50/50 w-[55px] print:w-[22px] text-center"
                      >
                        {/* Empty in header as break info is rendered vertically */}
                      </th>
                    );
                  }
                  
                  return (
                    <th
                      key={slot.id}
                      className="p-3 print:p-1 text-xs print:text-[8.5px] font-bold border-r border-slate-250 text-slate-700 min-w-[130px] w-[140px] print:min-w-0 print:w-[75px] text-center animate-none"
                    >
                      <div className="text-[11px] print:text-[8.5px] font-bold tracking-tight text-slate-900 leading-tight">{slot.name}</div>
                      <div className="text-[10px] print:text-[7.5px] text-slate-500 font-mono mt-0.5 print:mt-0 leading-tight">{slot.time}</div>
                    </th>
                  );
                })}
              </tr>
            </thead>
            
            <tbody>
              {DAYS.map((day) => (
                <tr key={day} className="border-b border-slate-200 hover:bg-slate-50/40 group/row last:border-b-0">
                  {/* Day Label Cell */}
                  <td className="p-3 print:p-1 text-xs print:text-[9.5px] font-bold text-slate-800 bg-slate-100 border-r border-slate-250 sticky left-0 z-10 font-mono group-hover/row:bg-slate-150 transition-colors uppercase">
                    {day}
                  </td>
                  
                  {/* Slots Rendering */}
                  {TIMETABLE_SLOTS.map((slot) => {
                    // Render Fixed Break Columns
                    if (slot.isBreak) {
                      return (
                        <td
                          key={slot.id}
                          style={{ writingMode: "vertical-lr" }}
                          className="bg-[#b9c9eb] text-center font-bold tracking-widest text-[9px] print:text-[7px] text-[#2c3d5a] uppercase font-sans border-r border-slate-250 leading-none select-none py-4 print:py-1 align-middle h-24 print:h-[72px] print:bg-indigo-100/60 print:text-indigo-900"
                        >
                          <div className="rotate-180 inline-block py-2 print:py-0">
                            {slot.time} {slot.breakLabel}
                          </div>
                        </td>
                      );
                    }

                    // Render Assignable Cell Slots
                    // Find active assignment
                    const ast = assignments.find((a) => {
                      if (viewType === "class") {
                        return a.classId === targetId && a.day === day && a.periodId === slot.id;
                      } else {
                        return a.teacherId === targetId && a.day === day && a.periodId === slot.id;
                      }
                    });

                    // Check for clashes
                    let hasClash = false;
                    let clashMsg = "";
                    if (ast) {
                      const collision = getCollisionStatus(ast);
                      if (viewType === "class" && collision.isTeacherClashed) {
                        hasClash = true;
                        clashMsg = `Double Booked: ${teachers.find(t => t.id === ast.teacherId)?.name} is teaching ${collision.teacherClashesWith.join(" & ")} at this exact time!`;
                      } else if (viewType === "teacher" && collision.isClassClashed) {
                        hasClash = true;
                        clashMsg = `Double Booked: Class ${classes.find(c => c.id === ast.classId)?.name} also has ${collision.classClashesWith.join(" & ")} assigned at this time!`;
                      }
                    }

                    return (
                      <td
                        key={slot.id}
                        onClick={() => onCellClick(day, slot)}
                        className={`p-1.5 print:p-0.5 border-r border-slate-250 text-center h-24 print:h-[72px] align-middle relative cursor-pointer group transition-all select-none ${
                          hasClash 
                            ? "bg-red-50 border-2 border-red-400 z-10 hover:bg-red-100/60" 
                            : "hover:bg-slate-50/50"
                        }`}
                      >
                        {ast ? (
                          /* Render Assigned Card */
                          (() => {
                            const teacher = teachers.find((t) => t.id === ast.teacherId);
                            const cls = classes.find((c) => c.id === ast.classId);
                            const displayLabel = viewType === "class" ? (teacher?.name || "Unassigned") : (cls?.name || "Unassigned");
                            const colorPalette = stringToColorClass(viewType === "class" ? ast.teacherId : ast.classId);

                            return (
                              <div
                                className={`h-full w-full rounded-xl print:rounded-md p-2.5 print:p-1 flex flex-col justify-between border transition-all text-left shadow-xs ${
                                  hasClash
                                    ? "bg-red-600 border-red-700 text-white"
                                    : `${colorPalette.bg} ${colorPalette.text} ${colorPalette.border} hover:brightness-95`
                                }`}
                              >
                                <div>
                                  <div className="text-xs print:text-[8.5px] font-bold truncate leading-tight">
                                    {displayLabel}
                                  </div>
                                  <div className={`text-[9px] print:text-[7px] uppercase font-bold tracking-tight mt-1 print:mt-0.5 inline-block px-1.5 print:px-1 py-0.5 print:py-0 rounded-md ${
                                    hasClash ? "bg-red-800/80 text-white" : colorPalette.tagBg
                                  }`}>
                                    {ast.subject}
                                  </div>
                                </div>
                                
                                <div className={`flex items-center justify-between mt-1 print:mt-0.5 pt-1 print:pt-0.5 border-t text-[9px] print:text-[6.5px] ${
                                  hasClash ? "border-white/20 text-white/95" : "border-slate-200/50 text-slate-500"
                                }`}>
                                  <span className="font-mono truncate max-w-[80%] print:max-w-[100%]">
                                    {viewType === "class" ? "Staff assigned" : "Class period"}
                                  </span>
                                  {hasClash ? (
                                    <span 
                                      className="rounded-full bg-white p-0.5 text-red-650 block animate-pulse"
                                      title={clashMsg}
                                    >
                                      <AlertCircle className="h-3.3 w-3.3 print:h-2 print:w-2" />
                                    </span>
                                  ) : (
                                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 print:w-1 print:h-1" />
                                  )}
                                </div>
                              </div>
                            );
                          })()
                        ) : (
                          /* Render Empty Spot */
                          <div className="h-full w-full rounded-xl print:rounded-md flex flex-col items-center justify-center border border-dashed border-slate-200 text-slate-300 group-hover:border-slate-400 group-hover:text-slate-400 transition-all bg-slate-50/20 hover:bg-slate-50/65 print:border-none print:bg-slate-50/5">
                            <span className="text-[10px] font-bold tracking-wide opacity-0 group-hover:opacity-100 transition-opacity print:hidden">
                              + ASSIGN Slot
                            </span>
                          </div>
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
