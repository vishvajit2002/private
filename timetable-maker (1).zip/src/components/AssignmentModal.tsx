import React, { useState, useEffect } from "react";
import { X, AlertTriangle, Trash2, Check, Sparkles, Search } from "lucide-react";
import { ClassInfo, TeacherInfo, Assignment, SlotInfo } from "../types";

interface AssignmentModalProps {
  isOpen: boolean;
  viewType: "class" | "teacher";
  targetId: string; // The active class ID or teacher ID
  day: string;
  slot: SlotInfo;
  classes: ClassInfo[];
  teachers: TeacherInfo[];
  assignments: Assignment[];
  onClose: () => void;
  onAssign: (teacherId: string, classId: string, subject: string) => void;
  onDelete: () => void;
}

export default function AssignmentModal({
  isOpen,
  viewType,
  targetId,
  day,
  slot,
  classes,
  teachers,
  assignments,
  onClose,
  onAssign,
  onDelete,
}: AssignmentModalProps) {
  const [selectedEntityId, setSelectedEntityId] = useState("");
  const [customSubject, setCustomSubject] = useState("");
  const [clashWarning, setClashWarning] = useState<string | null>(null);
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  // Look up existing assignment for today at this period
  const existingAssignment = assignments.find((ast) => {
    if (viewType === "class") {
      return ast.classId === targetId && ast.day === day && ast.periodId === slot.id;
    } else {
      return ast.teacherId === targetId && ast.day === day && ast.periodId === slot.id;
    }
  });

  // Get active targets
  const activeClass = viewType === "class" ? classes.find((c) => c.id === targetId) : null;
  const activeTeacher = viewType === "teacher" ? teachers.find((t) => t.id === targetId) : null;

  // Initialize form options
  useEffect(() => {
    if (isOpen) {
      setShowConfirmDelete(false);
      setClashWarning(null);
      setSearchTerm("");
      if (existingAssignment) {
        if (viewType === "class") {
          setSelectedEntityId(existingAssignment.teacherId);
        } else {
          setSelectedEntityId(existingAssignment.classId);
        }
        setCustomSubject(existingAssignment.subject);
      } else {
        setSelectedEntityId("");
        if (viewType === "teacher" && activeTeacher) {
          setCustomSubject(activeTeacher.subject);
        } else {
          setCustomSubject("");
        }
      }
    }
  }, [isOpen, existingAssignment, viewType, targetId, activeTeacher]);

  // Run real-time clash checking based on form values
  useEffect(() => {
    if (!selectedEntityId) {
      setClashWarning(null);
      return;
    }

    if (viewType === "class") {
      // We are assigning a Teacher to this Class
      // Check if the selected Teacher matches any assignments on this Day & Period Slot for other classes
      const matchedTeacher = teachers.find((t) => t.id === selectedEntityId);
      if (matchedTeacher) {
        // Find other classes that have this teacher in this slot
        const otherBooking = assignments.find(
          (ast) =>
            ast.teacherId === selectedEntityId &&
            ast.day === day &&
            ast.periodId === slot.id &&
            ast.classId !== targetId // don't count itself if we are editing
        );
        if (otherBooking) {
          const otherClass = classes.find((c) => c.id === otherBooking.classId);
          setClashWarning(
            `⚠️ CLASH: ${matchedTeacher.name} is already assigned to "${otherClass?.name || "another class"}" at ${day} during ${slot.name} (${slot.time})!`
          );
        } else {
          setClashWarning(null);
        }
      }
    } else {
      // We are assigning a Class to this Teacher
      // Check if the selected Class has another teacher in this slot
      const matchedClass = classes.find((c) => c.id === selectedEntityId);
      if (matchedClass) {
        const otherBooking = assignments.find(
          (ast) =>
            ast.classId === selectedEntityId &&
            ast.day === day &&
            ast.periodId === slot.id &&
            ast.teacherId !== targetId
        );
        if (otherBooking) {
          const otherTeacher = teachers.find((t) => t.id === otherBooking.teacherId);
          setClashWarning(
            `⚠️ CLASH: Class "${matchedClass.name}" already has ${otherTeacher?.name || "another teacher"} (${otherBooking.subject}) assigned at ${day} during ${slot.name} (${slot.time})!`
          );
        } else {
          setClashWarning(null);
        }
      }
    }
  }, [selectedEntityId, viewType, targetId, day, slot, assignments, classes, teachers]);

  // Handle entity change, auto-populating subject if viewType === class
  const handleEntityChange = (id: string) => {
    setSelectedEntityId(id);
    if (viewType === "class") {
      const selectedTeacher = teachers.find((t) => t.id === id);
      if (selectedTeacher) {
        setCustomSubject(selectedTeacher.subject);
      }
    }
  };

  // Filter search matches
  const filteredTeachers = teachers.filter((t) => {
    const isSelected = t.id === selectedEntityId;
    if (!searchTerm.trim()) {
      return isSelected;
    }
    const matchesSearch =
      t.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.subject.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch || isSelected;
  });

  const filteredClasses = classes.filter((c) => {
    const isSelected = c.id === selectedEntityId;
    if (!searchTerm.trim()) {
      return isSelected;
    }
    const matchesSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch || isSelected;
  });

  const handleSave = () => {
    if (!selectedEntityId) return;

    const teacherId = viewType === "class" ? selectedEntityId : targetId;
    const classId = viewType === "class" ? targetId : selectedEntityId;
    const resolvedSubject = customSubject.trim() || "General";

    onAssign(teacherId, classId, resolvedSubject);
    onClose();
  };

  const handleDeleteTrigger = () => {
    setShowConfirmDelete(true);
  };

  const handleDeleteConfirm = () => {
    onDelete();
    setShowConfirmDelete(false);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs" onClick={onClose} />

      {/* Modal Container */}
      <div className="relative w-full max-w-lg overflow-hidden rounded-xl bg-white shadow-2xl border border-slate-100 transition-all">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 px-6 py-4 bg-slate-50/80">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-amber-500" />
              Configure Period Assignment
            </h3>
            <p className="text-xs text-slate-500 mt-1 uppercase tracking-wider font-semibold font-mono">
              {day} • {slot.name} ({slot.time})
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-150 hover:text-slate-700 transition-all cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Info panel */}
        <div className="bg-indigo-50/40 px-6 py-3 border-b border-indigo-50/50 flex items-center gap-1.5 text-sm text-indigo-950 font-medium">
          {viewType === "class" ? (
            <span>
              Targeting Class: <strong className="text-indigo-900 font-bold">{activeClass?.name}</strong>
            </span>
          ) : (
            <span>
              Targeting Teacher: <strong className="text-emerald-900 font-bold">{activeTeacher?.name}</strong>{" "}
              <span className="text-xs text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full font-mono">
                {activeTeacher?.subject}
              </span>
            </span>
          )}
        </div>

        {/* Content body */}
        <div className="p-6 space-y-4">
          {showConfirmDelete ? (
            /* Delete Confirmation Sub-Form */
            <div className="bg-red-50/60 rounded-xl p-4 border border-red-100 text-center space-y-3">
              <div className="flex h-10 w-10 mx-auto items-center justify-center rounded-full bg-red-100 text-red-600">
                <AlertTriangle className="h-5 w-5" />
              </div>
              <p className="text-sm text-slate-800 font-medium">
                Are you sure you want to delete this period assignment?
              </p>
              <p className="text-xs text-slate-500"> This action cannot be undone.</p>
              <div className="flex justify-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowConfirmDelete(false)}
                  className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleDeleteConfirm}
                  className="rounded-lg bg-red-600 px-4 py-2 text-xs font-semibold text-white hover:bg-red-700 cursor-pointer shadow-xs"
                >
                  Yes, Remove
                </button>
              </div>
            </div>
          ) : (
            /* Main Assignment Form */
            <>
              {/* Entity Selector element with Search Bar */}
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-slate-700">
                  {viewType === "class" ? "Select Teacher" : "Select Class"}
                </label>

                {/* Inline Search Bar */}
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <Search className="h-4 w-4 text-slate-400" />
                  </span>
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder={
                      viewType === "class"
                        ? "Search teacher by name or subject..."
                        : "Search class..."
                    }
                    className="w-full pl-9 pr-8 py-2 text-sm rounded-lg border border-slate-200 bg-slate-50 focus:bg-white focus:border-indigo-500 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 placeholder-slate-400 transition-all text-slate-800"
                  />
                  {searchTerm && (
                    <button
                      type="button"
                      onClick={() => setSearchTerm("")}
                      className="absolute inset-y-0 right-0 flex items-center pr-3 text-slate-400 hover:text-slate-600 font-bold text-sm cursor-pointer"
                    >
                      ×
                    </button>
                  )}
                </div>

                {/* Modern Interactive Search List - No Select Dropdowns Needed! */}
                <div className="border border-slate-200 rounded-lg overflow-hidden bg-slate-50/50">
                  <div className="max-h-48 overflow-y-auto divide-y divide-slate-150">
                    {viewType === "class" ? (
                      teachers.length === 0 ? (
                        <div className="p-4 text-center text-xs text-red-500 italic">
                          No teachers registered. Please register teachers in the sidebar first.
                        </div>
                      ) : !searchTerm.trim() && !selectedEntityId ? (
                        <div className="p-5 text-center text-xs text-slate-500 font-medium">
                          Please type in the search box above to search and find a teacher
                        </div>
                      ) : filteredTeachers.length === 0 ? (
                        <div className="p-4 text-center text-xs text-slate-500 italic">
                          No matching teachers found for "{searchTerm}"
                        </div>
                      ) : (
                        filteredTeachers.map((t) => {
                          const isSelected = selectedEntityId === t.id;
                          return (
                            <button
                              key={t.id}
                              type="button"
                              onClick={() => handleEntityChange(t.id)}
                              className={`w-full text-left px-4 py-2.5 text-sm flex items-center justify-between transition-colors cursor-pointer ${
                                isSelected 
                                  ? "bg-indigo-50 hover:bg-indigo-100/80 text-indigo-900 font-semibold" 
                                  : "bg-white hover:bg-slate-50 text-slate-700"
                              }`}
                            >
                              <div className="min-w-0 pr-2">
                                <div className="font-semibold truncate">{t.name}</div>
                                <div className={`text-[10.5px] font-medium ${isSelected ? "text-indigo-600" : "text-slate-500"}`}>
                                  {t.subject}
                                </div>
                              </div>
                              {isSelected && (
                                <Check className="h-4 w-4 text-indigo-600 shrink-0" />
                              )}
                            </button>
                          );
                        })
                      )
                    ) : (
                      classes.length === 0 ? (
                        <div className="p-4 text-center text-xs text-red-500 italic">
                          No classes registered. Please register classes in the sidebar first.
                        </div>
                      ) : !searchTerm.trim() && !selectedEntityId ? (
                        <div className="p-5 text-center text-xs text-slate-500 font-medium">
                          Please type in the search box above to search and find a class
                        </div>
                      ) : filteredClasses.length === 0 ? (
                        <div className="p-4 text-center text-xs text-slate-500 italic">
                          No matching classes found for "{searchTerm}"
                        </div>
                      ) : (
                        filteredClasses.map((c) => {
                          const isSelected = selectedEntityId === c.id;
                          return (
                            <button
                              key={c.id}
                              type="button"
                              onClick={() => handleEntityChange(c.id)}
                              className={`w-full text-left px-4 py-2.5 text-sm flex items-center justify-between transition-colors cursor-pointer ${
                                isSelected 
                                  ? "bg-emerald-50 hover:bg-emerald-100/80 text-emerald-900 font-semibold" 
                                  : "bg-white hover:bg-slate-50 text-slate-700"
                              }`}
                            >
                              <span className="font-semibold truncate">{c.name}</span>
                              {isSelected && (
                                <Check className="h-4 w-4 text-emerald-600 shrink-0" />
                              )}
                            </button>
                          );
                        })
                      )
                    )}
                  </div>
                </div>
              </div>

              {/* Subject modifier (Only visible if we have a valid selection) */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-700">
                  Subject for Period
                </label>
                <input
                  type="text"
                  value={customSubject}
                  onChange={(e) => setCustomSubject(e.target.value)}
                  placeholder="e.g. Physics, Math Lab, Slip Test"
                  disabled={!selectedEntityId}
                  className="w-full rounded-lg border border-slate-250 bg-white px-3 py-2 text-sm text-slate-800 placeholder-slate-400 focus:border-indigo-500 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 disabled:bg-slate-50 disabled:text-slate-400"
                />
              </div>

              {/* Real-time Clash warning area */}
              {clashWarning && (
                <div className="rounded-lg bg-amber-50 p-3 border border-amber-200 text-amber-800 text-xs flex items-start gap-2 leading-relaxed animate-pulse">
                  <AlertTriangle className="h-4 w-4 shrink-0 text-amber-600 mt-0.5" />
                  <span>{clashWarning}</span>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                <div>
                  {existingAssignment && (
                    <button
                      type="button"
                      onClick={handleDeleteTrigger}
                      className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      Remove Assignment
                    </button>
                  )}
                </div>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="rounded-lg border border-slate-250 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleSave}
                    disabled={!selectedEntityId}
                    className={`rounded-lg px-4 py-2 text-sm font-medium text-white transition-all shadow-xs cursor-pointer ${
                      selectedEntityId
                        ? "bg-slate-900 hover:bg-slate-800 active:scale-95"
                        : "bg-slate-250 text-slate-400 cursor-not-allowed"
                    }`}
                  >
                    {existingAssignment ? "Update Assignment" : "Assign Period"}
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
